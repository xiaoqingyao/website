﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WoExpress.ZBGL
{
    public class ZBGLAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "ZBGL";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "ZBGL_default",
                "ZBGL/{controller}/{action}/{id}",
                new { action = "Index", id = "" }
            );
            context.MapRoute(
                "ZBGL_default1",
                "ZBGL/{controller}/{action}/{id}/{sOperate}",
                new { action = "Index", id = "", sOperate = "" }
            );

            context.MapRoute(
             "ZBGL_default2",
               "ZBGL/{controller}/{action}/{id}/{sOperate}/{jdid}",
             new { action = "Index", id = "", operate = "" }
         );
        }
    }
}
