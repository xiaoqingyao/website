﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WoExpress.DataEntity.Models;
using WoExpress.ZBGL.Models;
using WoExpress.Core.Data;
using System.Data;
using WoExpress.Core.Page;
using WoExpress.Core.Utility;
using WoExpress.PUBLIC.Controllers;

namespace WoExpress.ZBGL.Controllers
{
    public class BBGLController : Controller
    {
        #region 查询统计

        private IList<TZTBJBXX> lstTZTBJBXX = null;

        public ActionResult XMCX()
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            ViewData["LBList"] = entity.ZBXMLB.Where(p => p.ZBXMLB_ID > 0);
            return View();
        }

        public ActionResult XMCXList(int iPageNo, string sLb, string sXMMC, string sDWMC,string skbsj,string ekbsj)
        {
            lstTZTBJBXX = GetList();
            var T = lstTZTBJBXX.Where(p => p.ID > 0);
            if (!String.IsNullOrEmpty(sLb))
            {
                T = T.Where(p => p.ZBXMXX_LB == sLb);
            }
            if (!String.IsNullOrEmpty(sXMMC.Trim()))
            {
                T = T.Where(p => p.ZBXMXX_XMMC.Contains(sXMMC.Trim()));
            }
            if (!String.IsNullOrEmpty(sDWMC.Trim()))
            {
                T = T.Where(p => p.Unit_JSDWName.Contains(sDWMC.Trim()));
            }
            if (!String.IsNullOrEmpty(skbsj.Trim()))
            {
                T = T.Where(p => p.ZTBGG_KBSJ >=DateTime.Parse(skbsj));
            }
            if (!String.IsNullOrEmpty(ekbsj))
                T = T.Where(p => p.ZTBGG_KBSJ <= DateTime.Parse(ekbsj));
            return View(TPageWizard.GetData<TZTBJBXX>(13, iPageNo, T.ToList()));

        }

        #endregion

        #region 按建设单位统计

        public static List<TTJData> listDWTJFX = new List<TTJData>();
        public static List<TTJData> listDWTJFZR = new List<TTJData>();
        public ActionResult DWTJ()
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            ViewData["LBList"] = entity.ZBXMLB.Where(p => p.ZBXMLB_ID > 0);
            ViewData["FZRList"] = entity.ZBDLXZ.Where(p=>p.ZBDLXZ_ID>0);
            ViewData["AutoCompStr"] = PUBLICController.GetAllPersonints();
            ViewData["AutoCompStrJSDW"] = PUBLICController.GetAllUnitHints("XT03");
            ViewData["AutoCompStrZBDW"] = PUBLICController.GetAllUnitHints("XT02");
            return View();
        }

        public ActionResult DWTJList(int iPageNo, string sDWMC, string sRQS, string sRQE, string sLBID, string sRYXM, string ZBR, string ZBJ1, string ZBJ2)
        {
            listDWTJFX = DWTJDataList(sDWMC, sRQS, sRQE, sLBID);
            if (!String.IsNullOrEmpty(sRYXM.Trim()))
                listDWTJFX = listDWTJFX.Where(p=>p.sFZRXM==sRYXM).ToList();
            if (!String.IsNullOrEmpty(ZBR.Trim()))
                listDWTJFX = listDWTJFX.Where(p => p.sZBDW == ZBR).ToList();
            DataEntityDataContext entity = new DataEntityDataContext();
            ViewData["TJS"] = entity.ZBXMBD.Where(p=>p.ZBXMBD_ID!=0).ToList().Count;
            if (!string.IsNullOrEmpty(ZBJ1))
                listDWTJFX = listDWTJFX.Where(p => p.dZBJE >= int.Parse(ZBJ1)).ToList();
            if (!string.IsNullOrEmpty(ZBJ2))
                listDWTJFX = listDWTJFX.Where(p => p.dZBJE <= int.Parse(ZBJ2)).ToList();
            return View(TPageWizard.GetData<TTJData>(15, iPageNo, listDWTJFX));
        }

        public List<TTJData> DWTJDataList(string sDWMC, string sRQS, string sRQE, string sLBID)
        {
            List<TTJData> listDWTJ = new List<TTJData>();
            DBHelper oDBHelper = null;
            try
            {
                oDBHelper = new DBHelper();
                string sCondition = "";
                if (!String.IsNullOrEmpty(sDWMC.Trim()))
                    sCondition = " and d.Unit_Name like'%" + sDWMC.Trim() + "%' ";
                if (!String.IsNullOrEmpty(sRQS))
                    sCondition += " and ZBXMBD_KBSJ>='" + DateTime.Parse(sRQS) + "' ";
                if (!String.IsNullOrEmpty(sRQE))
                    sCondition += " and ZBXMBD_KBSJ<'" + DateTime.Parse(sRQE).AddDays(1) + "' ";
                if (sLBID != "0")
                    sCondition += " and ZBXMXX_XMLB='" + int.Parse(sLBID) + "' ";
                string sql = "";
                sql = "select convert(float, 0) as PX1, convert(float, 0) as PX2,"
                    + "  d.Unit_Name JSDW, ZBXMBD_ID,ZBXMBD_XMID, ZBXMBD_FBNR, Person_Name, ZBXMBD_KBSJ, "
                    + "  ZBXMBD_FBFS, b.ZBXMLB_MC, e.Unit_Name ZBDW, "
                    + "  isnull(ZBXMBD_ZBJG, 0) ZBXMBD_ZBJG, "
                    + "  isnull(ZBXMBD_YSJE, 0) ZBXMBD_YSJE,  "
                    + "  isnull(ZBXMBD_ZFJE, 0) ZBXMBD_ZFJE, "
                    + "  isnull(ZBXMBD_JE, 0) ZBXMBD_JE, "
                    + "  case when a.ZBXMBD_JE!=0 then (isnull(a.ZBXMBD_JE, 0)- isnull(ZBXMBD_ZFJE, 0)) else (isnull(a.ZBXMBD_YSJE, 0)- isnull(ZBXMBD_ZFJE, 0)) end  as  SQJE "
                    + "from ZBXMBD a  "
                    + "  left join ZBXMXX f on f.ZBXMXX_ID=a.ZBXMBD_XMID "
                    + "  left join ZBXMLB b on b.ZBXMLB_ID=f.ZBXMXX_XMLB "
                    + " left join Person c on c.Person_ID=f.ZBXMXX_FZR  "
                    + "  left join Unit d on d.Unit_ID=f.ZBXMXX_JSDW  "
                    + " left join Unit e on e.Unit_ID=a.ZBXMBD_ZBDW "
                    + "where 1=1 ";
                sql += sCondition;
                sql += "union all "
                    + "select convert(float, 1) as PX1, convert(float, 0) as PX2, "
                    + "isnull(d.Unit_Name, '')+'(小计)' as JSDW,'' as ZBXMBD_ID, '' as ZBXMBD_XMID, '' as ZBXMBD_FBNR, "
                    + "'' as Person_Name, null as ZBXMBD_KBSJ,  '' as ZBXMBD_FBFS, '' as ZBXMLB_MC, '' as ZBDW, "
                    + " isnull(sum(isnull(ZBXMBD_ZBJG, 0)), 0) as ZBXMBD_ZBJG, "
                    + " isnull(sum(isnull(ZBXMBD_YSJE, 0)), 0) as ZBXMBD_YSJE,  "
                    + " isnull(sum(isnull(ZBXMBD_ZFJE, 0)), 0) as ZBXMBD_ZFJE, "
                    + " isnull(sum(isnull(ZBXMBD_JE, 0)), 0) as ZBXMBD_JE, "
                    + "  (isnull(sum(isnull(case when ZBXMBD_JE!=0 then ZBXMBD_JE  else ZBXMBD_YSJE end, 0)), 0)- isnull(sum(isnull(ZBXMBD_ZFJE, 0)), 0)) SQJE  "
                    + "from ZBXMBD "
                    + "left join ZBXMXX f on f.ZBXMXX_ID=ZBXMBD_XMID "
                    + "left join Unit d on d.Unit_ID=f.ZBXMXX_JSDW "
                    + "where 1=1 ";
                sql += sCondition;
                sql += "group by Unit_Name "
                    + "union all "
                    + "select convert(float, 1) as PX1, convert(float, 1) as PX2, "
                    + "  '总计' as JSDW, '' as ZBXMBD_ID, '' as ZBXMBD_XMID, '' as ZBXMBD_FBNR, "
                    + "  '' as Person_Name, null as ZBXMBD_KBSJ,  '' as ZBXMBD_FBFS, '' as ZBXMLB_MC, '' as ZBDW, "
                    + " isnull(sum(isnull(ZBXMBD_ZBJG, 0)), 0) as ZBXMBD_ZBJG, "
                    + "  isnull(sum(isnull(ZBXMBD_YSJE, 0)), 0) as ZBXMBD_YSJE, "
                    + "  isnull(sum(isnull(ZBXMBD_ZFJE, 0)), 0) as ZBXMBD_ZFJE, "
                    + " isnull(sum(isnull(ZBXMBD_JE, 0)), 0) as ZBXMBD_JE, "
                    + " (isnull(sum(isnull(case when ZBXMBD_JE!=0 then ZBXMBD_JE  else ZBXMBD_YSJE end, 0)), 0)- isnull(sum(isnull(ZBXMBD_ZFJE, 0)), 0)) SQJE  "
                    + "from ZBXMBD "
                    + "left join ZBXMXX f on f.ZBXMXX_ID=ZBXMBD_XMID "
                    + " left join Unit d on d.Unit_ID=f.ZBXMXX_JSDW "
                    + " where 1=1 ";
                sql += sCondition;
                sql += "order by PX2, JSDW, ZBXMBD_ID, PX1";
                using (IDataReader dr = oDBHelper.ExecuteReader(CommandType.Text, sql))
                {
                    while (dr.Read())
                    {
                        TTJData oTTJData = new TTJData();
                        oTTJData.fPX1 = float.Parse(dr["PX1"].ToString());
                        oTTJData.fPX2 = float.Parse(dr["PX2"].ToString());
                        oTTJData.sJSDW = dr["JSDW"].ToString();
                        oTTJData.iXMID = int.Parse(dr["ZBXMBD_ID"].ToString());
                        oTTJData.sXMMC = dr["ZBXMBD_FBNR"].ToString();
                        oTTJData.sFZRXM = dr["Person_Name"].ToString();
                        oTTJData.sZBFS = dr["ZBXMBD_FBFS"].ToString();
                        oTTJData.sXMLB = dr["ZBXMLB_MC"].ToString();
                        oTTJData.sZBDW = dr["ZBDW"].ToString();
                        oTTJData.dBGJE = decimal.Parse(dr["ZBXMBD_JE"].ToString());
                        oTTJData.dZBJE = decimal.Parse(dr["ZBXMBD_ZBJG"].ToString());
                        oTTJData.dYSJE = decimal.Parse(dr["ZBXMBD_YSJE"].ToString());
                        oTTJData.dZFJE = decimal.Parse(dr["ZBXMBD_ZFJE"].ToString());
                        oTTJData.dSQJE = decimal.Parse(dr["SQJE"].ToString());
                        if (dr["ZBXMBD_KBSJ"].ToString() != "" && dr["ZBXMBD_KBSJ"].ToString() != null)
                            oTTJData.sKBSJ = DateTime.Parse(dr["ZBXMBD_KBSJ"].ToString());
                        listDWTJ.Add(oTTJData);
                    }
                }
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                oDBHelper = null;
            }
            return listDWTJ;
        }

        public ActionResult DWTJCreateTable()
        {
            return View( listDWTJFX);
        }
        #endregion

        #region 按负责人统计
        public ActionResult FZRTJ()
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            ViewData["LBList"] = entity.ZBXMLB.Where(p => p.ZBXMLB_ID > 0);
            return View();
        }

        public ActionResult FZRTJList(int iPageNo, string sRYXM, string sRQS, string sRQE, string sLBID,string ZBR,string ZBJ1,string ZBJ2)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            listDWTJFZR = FZRTJDataList(sRYXM, sRQS, sRQE, sLBID);
            if (!String.IsNullOrEmpty(ZBR.Trim()))
                listDWTJFZR = listDWTJFZR.Where(p => p.sZBDW == ZBR).ToList();
            if(!string.IsNullOrEmpty(ZBJ1))
                listDWTJFZR = listDWTJFZR.Where(p => p.dZBJE >= int.Parse(ZBJ1)).ToList();
            if (!string.IsNullOrEmpty(ZBJ2))
                listDWTJFZR = listDWTJFZR.Where(p => p.dZBJE <= int.Parse(ZBJ2)).ToList();
            ViewData["TJS"] = entity.ZBXMBD.Where(p => p.ZBXMBD_ID != 0).ToList().Count;
            return View(TPageWizard.GetData<TTJData>(15, iPageNo, listDWTJFZR));

        }

        public List<TTJData> FZRTJDataList(string sRYXM, string sRQS, string sRQE, string sLBID)
        {
            List<TTJData> listFZRTJ = new List<TTJData>();
            DBHelper oDBHelper = null;
            try
            {
                oDBHelper = new DBHelper();
                string sCondition = "";
                if (!String.IsNullOrEmpty(sRYXM.Trim()))
                    sCondition = " and c.Person_Name like'%" + sRYXM.Trim() + "%' ";
                if (!String.IsNullOrEmpty(sRQS))
                    sCondition += " and ZBXMXX_PBSJ>='" + DateTime.Parse(sRQS) + "' ";
                if (!String.IsNullOrEmpty(sRQE))
                    sCondition += " and ZBXMXX_PBSJ<'" + DateTime.Parse(sRQE).AddDays(1) + "' ";
                if (sLBID != "0")
                    sCondition += " and ZBXMXX_XMLB='" + int.Parse(sLBID) + "' ";
                string sql = "";
                sql = "select convert(float, 0) as PX1, convert(float, 0) as PX2, "
                    + "  d.Unit_Name JSDW, ZBXMXX_ID,f.ZBXMBD_FBNR, c.Person_Name as FZR,isnull(g.Person_Name,'') as JSDWLXR, isnull(g.Person_DH,'') as DH,  "
                    + "  f.ZBXMBD_FBFS, ZBXMLB_MC, isnull(e.Unit_Name,'') as ZBDW,isnull(f.ZBXMBD_KBSJ,'') as KBSJ ,"
                    + "  isnull(f.ZBXMBD_ZBJG, 0) ZBXMBD_ZBJG, "
                    + "  isnull(f.ZBXMBD_YSJE, 0) ZBXMBD_YSJE, "
                    + "  isnull(f.ZBXMBD_ZFJE, 0) ZBXMBD_ZFJE, "
                    + "  isnull(f.ZBXMBD_JE, 0) ZBXMBD_JE, "
                    + "  case when f.ZBXMBD_JE!=0 then (isnull(f.ZBXMBD_JE, 0)- isnull(ZBXMBD_ZFJE, 0)) else (isnull(f.ZBXMBD_YSJE, 0)- isnull(ZBXMBD_ZFJE, 0)) end  as  SQJE  "
                    + "from ZBXMXX a "
                    + " left join ZBXMBD f on f.ZBXMBD_XMID=a.ZBXMXX_ID "
                    + "  left join ZBXMLB b on b.ZBXMLB_ID=a.ZBXMXX_XMLB "
                    + "  left join Person c on c.Person_ID=a.ZBXMXX_FZR "
                    + "  left join Person g on g.Person_ID=a.ZBXMXX_JSDWLXR    "
                    + "  left join Unit d on d.Unit_ID=a.ZBXMXX_JSDW "
                    + "  left join Unit e on e.Unit_ID=a.ZBXMXX_ZBDW "
                    + "where 1=1 ";
                sql += sCondition;
                sql += "union all "
                    + "select convert(float, 1) as PX1, convert(float, 0) as PX2, "
                    + "  '' as JSDW, '' as ZBXMXX_ID, '' as ZBXMBD_FBNR,  "
                    + "  isnull(c.Person_Name,'')+'(小计)' as Person_Name,'' as JSDWLXR,'' as DH, '' as ZBXMBD_FBFS, '' as ZBXMLB_MC, '' as ZBDW,'' as ZBXMBD_KBSJ, "
                    + "  isnull(sum(isnull(ZBXMBD_ZBJG, 0)), 0) as ZBXMBD_ZBJG, "
                    + "  isnull(sum(isnull(ZBXMBD_YSJE, 0)), 0) as ZBXMBD_YSJE, "
                    + " isnull(sum(isnull(ZBXMBD_ZFJE, 0)), 0) as ZBXMBD_ZFJE, "
                    + " isnull(sum(isnull(ZBXMBD_JE, 0)), 0) as ZBXMBD_JE, "
                    + "  (isnull(sum(isnull(case when ZBXMBD_JE!=0 then ZBXMBD_JE  else ZBXMBD_YSJE end, 0)), 0)- isnull(sum(isnull(ZBXMBD_ZFJE, 0)), 0)) SQJE "
                    + "from ZBXMXX "
                    + " left join ZBXMBD f on f.ZBXMBD_XMID=ZBXMXX_ID "
                    + "  left join Person c on c.Person_ID=ZBXMXX_FZR "
                    + " left join Person g on g.Person_ID=ZBXMXX_JSDWLXR  "
                    + "where 1=1 ";
                sql += sCondition;
                sql += "group by c.Person_Name "
                    + "union all "
                    + "select convert(float, 1) as PX1, convert(float, 1) as PX2, "
                    + "  '' as JSDW, '' as ZBXMXX_ID, '' as ZBXMBD_FBNR, "
                    + "  '总计' as Person_Name,'' as JSDWLXR,'' as DH, '' as ZBXMBD_FBFS, '' as ZBXMLB_MC, '' as ZBDW,'' as ZBXMBD_KBSJ, "
                   + "  isnull(sum(isnull(ZBXMBD_ZBJG, 0)), 0) as ZBXMBD_ZBJG, "
                    + "  isnull(sum(isnull(ZBXMBD_YSJE, 0)), 0) as ZBXMBD_YSJE, "
                    + " isnull(sum(isnull(ZBXMBD_ZFJE, 0)), 0) as ZBXMBD_ZFJE, "
                    + " isnull(sum(isnull(ZBXMBD_JE, 0)), 0) as ZBXMBD_JE,  "
                    + "  (isnull(sum(isnull(case when ZBXMBD_JE!=0 then ZBXMBD_JE  else ZBXMBD_YSJE end, 0)), 0)- isnull(sum(isnull(ZBXMBD_ZFJE, 0)), 0)) SQJE "
                    + "from ZBXMXX "
                     + " left join ZBXMBD f on f.ZBXMBD_XMID=ZBXMXX_ID "
                    + "  left join Person c on c.Person_ID=ZBXMXX_FZR "
                    + " left join Person g on g.Person_ID=ZBXMXX_JSDWLXR  "
                    + " where 1=1 ";
                sql += sCondition;
                sql += "order by PX2, c.Person_Name, ZBXMXX_ID, PX1 ";
                using (IDataReader dr = oDBHelper.ExecuteReader(CommandType.Text, sql))
                {
                    while (dr.Read())
                    {
                        TTJData oTTJData = new TTJData();
                        oTTJData.fPX1 = float.Parse(dr["PX1"].ToString());
                        oTTJData.fPX2 = float.Parse(dr["PX2"].ToString());
                        oTTJData.sJSDW = dr["JSDW"].ToString();
                        oTTJData.iXMID = int.Parse(dr["ZBXMXX_ID"].ToString());
                        oTTJData.sXMMC = dr["ZBXMBD_FBNR"].ToString();
                        oTTJData.sFZRXM = dr["FZR"].ToString();
                        oTTJData.sZBFS = dr["ZBXMBD_FBFS"].ToString();
                        oTTJData.sXMLB = dr["ZBXMLB_MC"].ToString();
                        oTTJData.sZBDW = dr["ZBDW"].ToString();
                        oTTJData.JSDWLXR = dr["JSDWLXR"].ToString();
                        oTTJData.DH = dr["DH"].ToString();
                        oTTJData.sKBSJ = DateTime.Parse(dr["KBSJ"].ToString());
                        oTTJData.dZBJE = decimal.Parse(dr["ZBXMBD_ZBJG"].ToString());
                        oTTJData.dYSJE = decimal.Parse(dr["ZBXMBD_YSJE"].ToString());
                        oTTJData.dZFJE = decimal.Parse(dr["ZBXMBD_ZFJE"].ToString());
                        oTTJData.dBGJE = decimal.Parse(dr["ZBXMBD_JE"].ToString());
                        oTTJData.dSQJE = decimal.Parse(dr["SQJE"].ToString());
                        listFZRTJ.Add(oTTJData);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDBHelper = null;
            }
            return listFZRTJ;
        }

        public ActionResult FZRTJCreateTable()
        {
            return View(listDWTJFZR);
        }
        #endregion

        #region 获取数据源

        private IList<TZTBJBXX> GetList()
        {
            lstTZTBJBXX = new List<TZTBJBXX>();
            DBHelper oDBHelper = null;
            try
            {
                oDBHelper = new DBHelper();
                string sSql = "select isnull(A.ZBXMXX_ID,0) as id, isnull(f.ZBXMBD_FBNR,'') as xmmc,isnull(A.ZBXMXX_XMBH,'') as xmbh,isnull(f.ZBXMBD_KBSJ,'') as kbsj,isnull(f.ZBXMBD_FBFS,'') as zbfs,isnull(D.Unit_Name,'') as jsdwmc,isnull(E.Unit_Name,'') as zbdwmc,isnull(f.ZBXMBD_ZBJG,0) as zbjg,isnull(A.ZBXMXX_SMZBJ,'') as smzbj,isnull(f.ZBXMBD_YSJE,0) as ysje,isnull(f.ZBXMBD_ZFJE,0) as zfje, isnull(B.ZBXMLB_MC,'') as xmlb,isnull(C.Person_Name,'') as fzr from ZBXMXX as A inner join ZBXMLB as B on A.ZBXMXX_XMLB=B.ZBXMLB_ID left join ZBXMBD f on f.ZBXMBD_XMID=a.ZBXMXX_ID left join Person as C on A.ZBXMXX_FZR=C.Person_ID left join Unit as D on A.ZBXMXX_JSDW=D.Unit_ID left join Unit as E on A.ZBXMXX_ZBDW=E.Unit_ID order by f.ZBXMBD_WHSJ desc";
                using (IDataReader dr = oDBHelper.ExecuteReader(CommandType.Text, sSql))
                {
                    while (dr.Read())
                    {
                        TZTBJBXX oTZTBJBXX = new TZTBJBXX();
                        if (!string.IsNullOrEmpty((string)dr["xmmc"]))
                        {
                            oTZTBJBXX.ZBXMXX_XMMC = dr["xmmc"].ToString();
                        }
                        oTZTBJBXX.ZBXMXX_LB = dr["xmlb"].ToString();
                        oTZTBJBXX.ID = int.Parse(dr["id"].ToString());
                        oTZTBJBXX.ZBXMXX_XMBH = dr["xmbh"].ToString();
                        oTZTBJBXX.ZBXMXX_ZBFS = dr["zbfs"].ToString();
                        oTZTBJBXX.ZBXMXX_ZBJ = decimal.Parse(dr["zbjg"].ToString());
                        oTZTBJBXX.ZBXMXX_SMZBJ = dr["smzbj"].ToString();
                        oTZTBJBXX.Unit_JSDWName = dr["jsdwmc"].ToString();
                        oTZTBJBXX.ZTBGG_KBSJ = DateTime.Parse(dr["kbsj"].ToString());
                        oTZTBJBXX.Unit_ZBDWName = dr["zbdwmc"].ToString();
                        oTZTBJBXX.ZBXMXX_YSJE = decimal.Parse(dr["ysje"].ToString());
                        oTZTBJBXX.ZBXMXX_ZFJE = decimal.Parse(dr["zfje"].ToString());
                        oTZTBJBXX.Person_Name = dr["fzr"].ToString();
                        oTZTBJBXX.ZTBHTBA_SQJE = oTZTBJBXX.ZBXMXX_YSJE - oTZTBJBXX.ZBXMXX_ZFJE;
                        lstTZTBJBXX.Add(oTZTBJBXX);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDBHelper = null;
            }
            return lstTZTBJBXX;
        }

        #endregion
        
        #region 合同预警

        public ActionResult HTYJ()
        {
            return View();
        }

        public ActionResult HTYJList(int iPageNo, string sTS)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            Users oUser = CMisproApp.GetCurrentUser();
            var T = context.ZBDLHT.Where(p => p.ZBDLHT_ID !="" && p.ZBDLHT_WHRID == CMisproApp.GetCurrentUser().Users_ID);
            if (!String.IsNullOrEmpty(sTS))
                T = T.Where(p => p.ZBDLHT_HTDQSJ <= DateTime.Now.AddDays(int.Parse(sTS)));
            T = T.OrderByDescending(p => p.ZBDLHT_HTDQSJ).ThenByDescending(p => p.ZBDLHT_ID);
            return View(TPageWizard.GetData<ZBDLHT>(10, iPageNo, T.ToList()));
        }
        #endregion


    }
}
