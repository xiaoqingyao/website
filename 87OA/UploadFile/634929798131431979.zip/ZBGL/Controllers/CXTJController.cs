﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WoExpress.DataEntity.Models;

namespace WoExpress.ZBGL.Controllers
{
    public class CXTJController : Controller
    {
        //
        // GET: /CXTJ/

        public ActionResult YWJBQK()
        {
            return View();
        }

        public ActionResult CKXMXX(int id)
        {
            ViewData["XMID"] = id;
            return View();
        }

        public ActionResult CYDWTJ(int id)
        {
            ViewData["XMID"] = id;
            return View();
        }

        public ActionResult CKZBLXInfo(int id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            ZBLX oZTBGG = new ZBLX();
            var T = context.ZBXMXX.SingleOrDefault(p => p.ZBXMXX_ID == id);
            if (T != null)
            {
                oZTBGG = context.ZBLX.SingleOrDefault(p => p.ZBLX_ID == T.ZBXMXX_LXID);
            }
            ViewData["Operate"] = "V";
            return View(oZTBGG);
        }

        public ActionResult CKSKJL(int id)
        {
            ViewData["XMID"] = id;
            return View();
        }

        public ActionResult XMDetail(int id)
        {
            ViewData["XMID"] = id;
            DataEntityDataContext context = new DataEntityDataContext();
            ZBXMBD oFBFAMX = new ZBXMBD();
            oFBFAMX = context.ZBXMBD.SingleOrDefault(p => p.ZBXMBD_ID == id);
            ZBWJ ozbwej = context.ZBWJ.SingleOrDefault(p => p.ZBWJ_ID == id);
            if (ozbwej!=null)
            {
            ViewData["KBSJ"] = ozbwej.ZBWJ_KBSJ;
            ViewData["KBDD"] = ozbwej.ZBWJ_KBDD;
            }
            return View(oFBFAMX);
        }

        class Node
        {
            public int ZBXMXX_ID { get; set; }
            public string ZBXMXX_XMMC { get; set; }
            public string ZBXMXX_JSDW { get; set; }
            public string ZBXMXX_FZR { get; set; }
            public string ZBXMXX_WHR { get; set; }
            public DateTime ZBXMXX_WHSJ { get; set; }
            public string ZBXMXX_SFFS { get; set; }
            public string ZBXMXX_FWLX { get; set; }
            public decimal ZBXMXX_BL { get; set; }
            public decimal ZBXMXX_YSJE { get; set; }
            public decimal ZBXMXX_BGJE { get; set; }
            public decimal ZBXMBD_SJJE { get; set; }
        }

        class BDNode
        {
            public int ZBXMBD_ID { get; set; }
            public string ZBXMBD_ZBDW { get; set; }
            public string ZBXMBD_FBNR { get; set; }
            public string ZBXMBD_FBFS { get; set; }
            public string ZBXMBD_HTGSJ { get; set; }
            public DateTime ZBXMBD_JHFBSJ { get; set; }
            public decimal ZBXMBD_ZBJG { get; set; }
            public decimal ZBXMBD_YSJE { get; set; }
            public decimal ZBXMBD_ZFJE { get; set; }
            public decimal ZBXMBD_BL { get; set; }
            public decimal ZBXMBD_ZZF { get; set; }
            public string ZBXMBD_FWLX { get; set; }
            public string ZBXMBD_SMZBJ { get; set; }
            public string ZBXMBD_SFFS { get; set; }
            public decimal ZBXMBD_SQJE { get; set; }

        }

        class DWNode
        {
            public int DW_XH { get; set; }
            public string DW_Name { get; set; }
            public string DW_ZBJG { get; set; }
            public DateTime DW_CYSJ { get; set; }
        }

        class CYXMNode
        {
            public int XM_XH { get; set; }
            public int XM_ID { get; set; }
            public string XM_MC { get; set; }
            public string XM_SFZB { get; set; }
            public decimal XM_ZBJG { get; set; }
        }

        class SKNode
        {
            public int SK_XH { get; set; }
            public string SK_ZZF { get; set; }
            public string SK_SKR { get; set; }
            public DateTime SK_SKSJ { get; set; }
            public decimal SK_JE { get; set; }
            public DateTime SK_THRQ { get; set; }
            public string SK_ZT { get; set; }
        }

        public ActionResult GetZBXMXX(string id)
        {
            //排序的字段名
            string sortname = Request.Params["sortname"];
            //排序的方向
            string sortorder = Request.Params["sortorder"];
            //当前页
            int page = Convert.ToInt32(Request.Params["page"]);
            //每页显示的记录数
            int pagesize = Convert.ToInt32(Request.Params["pagesize"]);
            DataEntityDataContext entity = new DataEntityDataContext();
            IList<Node> list = new List<Node>();

            var T = entity.ZBXMXX.Where(p => p.ZBXMXX_ID > 0);
            if (!string.IsNullOrEmpty(id))
            {
                T = T.Where(p => p.ZBXMXX_WHSJ.Value.Year == int.Parse(id));
            }
            T = T.OrderByDescending(p => p.ZBXMXX_WHSJ);
            List<ZBXMXX> lists = (List<ZBXMXX>)T.ToList().Skip((page - 1) * pagesize).Take(pagesize).ToList();
            for (var i = 0; i < lists.Count; i++)
            {
                Node node = new Node();
                node.ZBXMXX_ID = lists[i].ZBXMXX_ID;
                node.ZBXMXX_XMMC = lists[i].ZBXMXX_XMMC;
                node.ZBXMXX_JSDW = entity.Unit.SingleOrDefault(p => p.Unit_ID == lists[i].ZBXMXX_JSDW) == null ? "" : entity.Unit.SingleOrDefault(p => p.Unit_ID == lists[i].ZBXMXX_JSDW).Unit_Name;
                node.ZBXMXX_FZR = entity.Person.SingleOrDefault(p => p.Person_ID == lists[i].ZBXMXX_FZR) == null ? "" : entity.Person.SingleOrDefault(p => p.Person_ID == lists[i].ZBXMXX_FZR).Person_Name;
                node.ZBXMXX_WHR = lists[i].ZBXMXX_WHR;
                node.ZBXMXX_WHSJ = (DateTime)lists[i].ZBXMXX_WHSJ;
                List<ZBDLHT> htlist = entity.ZBDLHT.Where(p => p.ZBDLHT_ID.Contains(","+lists[i].ZBXMXX_ID.ToString()+",")).ToList();
                if(htlist.Count>0)
                {
                    node.ZBXMXX_SFFS = htlist[0].ZBDLHT_SFFS;
                    node.ZBXMXX_FWLX = htlist[0].ZBDLHT_FWLX;
                    node.ZBXMXX_BL = htlist[0].ZBDLHT_FL == null ? 0 : (decimal)htlist[0].ZBDLHT_FL;
                    if (entity.ZBXMBD.Where(p => p.ZBXMBD_XMID == lists[i].ZBXMXX_ID).Count()>0)
                    {
                        node.ZBXMXX_YSJE = (decimal)entity.ZBXMBD.Where(p => p.ZBXMBD_XMID == lists[i].ZBXMXX_ID).Sum(p => p.ZBXMBD_YSJE);
                        node.ZBXMXX_BGJE = (decimal)entity.ZBXMBD.Where(p => p.ZBXMBD_XMID == lists[i].ZBXMXX_ID).Sum(p => p.ZBXMBD_JE);
                        node.ZBXMBD_SJJE = (decimal)entity.ZBXMBD.Where(p => p.ZBXMBD_XMID == lists[i].ZBXMXX_ID).Sum(p => p.ZBXMBD_ZZF);
                    }
                }
               list.Add(node);
            }
            var griddata = new { Rows = list, Total =T.ToList().Count };
            return Json(griddata);
        }

        public ActionResult GetZBBDXX(int id)
        {
            //排序的字段名
            string sortname = Request.Params["sortname"];
            //排序的方向
            string sortorder = Request.Params["sortorder"];
            //当前页
            int page = Convert.ToInt32(Request.Params["page"]);
            //每页显示的记录数
            int pagesize = Convert.ToInt32(Request.Params["pagesize"]);
            DataEntityDataContext entity = new DataEntityDataContext();
            IList<BDNode> list = new List<BDNode>();

            var T = entity.ZBXMBD.Where(p => p.ZBXMBD_XMID == id);
            List<ZBXMBD> lists = (List<ZBXMBD>)T.ToList().Skip((page - 1) * pagesize).Take(pagesize).ToList();
            //这里模拟排序操作
            if (sortorder == "asc")
                lists = lists.OrderByDescending(c => c.ZBXMBD_WHSJ).ToList();
            else
                lists = lists.OrderBy(c => c.ZBXMBD_WHSJ).ToList();
            for (var i = 0; i < lists.Count; i++)
            {
                BDNode bd = new BDNode();
                bd.ZBXMBD_ID = lists[i].ZBXMBD_ID;
                bd.ZBXMBD_FBNR = lists[i].ZBXMBD_FBNR;
                bd.ZBXMBD_FBFS = lists[i].ZBXMBD_FBFS;
                if (null != lists[i].ZBXMBD_ZBDW)
                {
                bd.ZBXMBD_ZBDW = GetUnitName((int)lists[i].ZBXMBD_ZBDW);
                }
                else
                {
                    bd.ZBXMBD_ZBDW = "";
                }
                bd.ZBXMBD_HTGSJ = lists[i].ZBXMBD_HTGSJ.ToString();
                bd.ZBXMBD_BL = lists[i].ZBXMBD_BL == null ? 0 : (decimal)lists[i].ZBXMBD_BL;
                bd.ZBXMBD_ZBJG = lists[i].ZBXMBD_ZBJG == null ? 0 : (decimal)lists[i].ZBXMBD_ZBJG;
                bd.ZBXMBD_FWLX = lists[i].ZBXMBD_FWLX;
                bd.ZBXMBD_SFFS = lists[i].ZBXMBD_SFFS;
                bd.ZBXMBD_SMZBJ = lists[i].ZBXMBD_SMZBJ;
                bd.ZBXMBD_YSJE = lists[i].ZBXMBD_YSJE == null ? 0 : (decimal)lists[i].ZBXMBD_YSJE;
                bd.ZBXMBD_ZFJE = lists[i].ZBXMBD_ZFJE == null ? 0 : (decimal)lists[i].ZBXMBD_ZFJE / 10000;
                bd.ZBXMBD_ZZF = lists[i].ZBXMBD_ZZF == null ? 0 : (decimal)lists[i].ZBXMBD_ZZF;
                bd.ZBXMBD_SQJE = bd.ZBXMBD_YSJE - bd.ZBXMBD_ZFJE;
                list.Add(bd);
            }
            var griddata = new { Rows = list, Total = T.ToList().Count };
            return Json(griddata);
        }

        private string GetUnitName(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.Unit.Where(p=>p.Unit_ID==id);
            if(T.ToList().Count>0)
            {
                return T.ToList()[0].Unit_Name;
            }

            return "";
        }

        public ActionResult GetZBXMXXCX(string id)
        {
            //排序的字段名
            string sortname = Request.Params["sortname"];
            //排序的方向
            string sortorder = Request.Params["sortorder"];
            //当前页
            int page = Convert.ToInt32(Request.Params["page"]);
            //每页显示的记录数
            int pagesize = Convert.ToInt32(Request.Params["pagesize"]);
            string conditon = Request.Params["whereparm"];
            DataEntityDataContext entity = new DataEntityDataContext();
            IList<Node> list = new List<Node>();

            var T = entity.ZBXMXX.Where(p => p.ZBXMXX_ID > 0);
            string[] str = id.Split(',');
            if (!string.IsNullOrEmpty(str[0]))
            {
                T = T.Where(p => p.ZBXMXX_XMMC.Contains(str[0]));
            }
            if (!string.IsNullOrEmpty(str[1]))
            {
                T = T.Where(p => p.ZBXMXX_WHSJ.Value.Year == int.Parse(str[1]));
            }
            T = T.OrderByDescending(p => p.ZBXMXX_WHSJ);
            List<ZBXMXX> lists = (List<ZBXMXX>)T.ToList().Skip((page - 1) * pagesize).Take(pagesize).ToList();
            for (var i = 0; i < lists.Count; i++)
            {
                Node node = new Node();
                node.ZBXMXX_ID = lists[i].ZBXMXX_ID;
                node.ZBXMXX_XMMC = lists[i].ZBXMXX_XMMC;
                node.ZBXMXX_JSDW = entity.Unit.SingleOrDefault(p => p.Unit_ID == lists[i].ZBXMXX_JSDW) == null ? "" : entity.Unit.SingleOrDefault(p => p.Unit_ID == lists[i].ZBXMXX_JSDW).Unit_Name;
                node.ZBXMXX_FZR = entity.Person.SingleOrDefault(p => p.Person_ID == lists[i].ZBXMXX_FZR) == null ? "" : entity.Person.SingleOrDefault(p => p.Person_ID == lists[i].ZBXMXX_FZR).Person_Name;
                node.ZBXMXX_WHR = lists[i].ZBXMXX_WHR;
                node.ZBXMXX_WHSJ = (DateTime)lists[i].ZBXMXX_WHSJ;
                List<ZBDLHT> htlist = entity.ZBDLHT.Where(p => p.ZBDLHT_ID.Contains("," + lists[i].ZBXMXX_ID.ToString() + ",")).ToList();
                if (htlist.Count > 0)
                {
                    node.ZBXMXX_SFFS = htlist[0].ZBDLHT_SFFS;
                    node.ZBXMXX_FWLX = htlist[0].ZBDLHT_FWLX;
                    node.ZBXMXX_BL = htlist[0].ZBDLHT_FL == null ? 0 : (decimal)htlist[0].ZBDLHT_FL;
                    node.ZBXMXX_YSJE = (decimal)entity.ZBXMBD.Where(p => p.ZBXMBD_XMID == lists[i].ZBXMXX_ID).Sum(p => p.ZBXMBD_YSJE);
                    node.ZBXMXX_BGJE = (decimal)entity.ZBXMBD.Where(p => p.ZBXMBD_XMID == lists[i].ZBXMXX_ID).Sum(p => p.ZBXMBD_JE);
                    node.ZBXMBD_SJJE = (decimal)entity.ZBXMBD.Where(p => p.ZBXMBD_XMID == lists[i].ZBXMXX_ID).Sum(p => p.ZBXMBD_ZZF);
                }
                list.Add(node);
            }
            var griddata = new { Rows = list, Total = T.ToList().Count };
            return Json(griddata);
        }

        public ActionResult GetDWTJ(int id)
        {
            //当前页
            int page = Convert.ToInt32(Request.Params["page"]);
            //每页显示的记录数
            int pagesize = Convert.ToInt32(Request.Params["pagesize"]);
            DataEntityDataContext entity = new DataEntityDataContext();
            IList<DWNode> list = new List<DWNode>();
            DWNode node = null;
            string ZZF = "";
            var T = entity.ZBSKDJ.Where(p => p.ZBSKDJ_XMID == id && p.ZBSKDJ_LB == "GBF");
            List<ZBSKDJ> lists = (List<ZBSKDJ>)T.ToList().Skip((page - 1) * pagesize).Take(pagesize).ToList();
            List<ZBSKDJ> li = entity.ZBSKDJ.Where(p => p.ZBSKDJ_XMID == id && p.ZBSKDJ_LB == "DLF").ToList();
            if (li.Count > 0)
            {
                ZZF = li[0].ZBSKDJ_ZFF;
            }
            for (var i = 0; i < lists.Count; i++)
            {
                node = new DWNode();
                node.DW_XH = i + 1;
                node.DW_Name = lists[i].ZBSKDJ_ZFF;
                if (ZZF != lists[i].ZBSKDJ_ZFF)
                {
                    node.DW_ZBJG = "未中标";
                }
                else
                {
                    node.DW_ZBJG = "中标";
                }
                list.Add(node);
            }
            var griddata = new { Rows = list, Total = T.ToList().Count };
            return Json(griddata);
        }

        public ActionResult CYXMTJ(string id)
        {
            ViewData["id"] = id;
            return View();
        }

        public ActionResult GetCYXM(string id)
        {
            //当前页
            int page = Convert.ToInt32(Request.Params["page"]);
            //每页显示的记录数
            int pagesize = Convert.ToInt32(Request.Params["pagesize"]);
            DataEntityDataContext entity = new DataEntityDataContext();
            IList<CYXMNode> list = new List<CYXMNode>();
            CYXMNode node = null;
            var T = entity.ZBSKDJ.Where(p => p.ZBSKDJ_ZFF == id && p.ZBSKDJ_LB == "GBF");
            List<ZBSKDJ> lists = (List<ZBSKDJ>)T.ToList().Skip((page - 1) * pagesize).Take(pagesize).ToList();
            for (var i = 0; i < lists.Count; i++)
            {
                node = new CYXMNode();
                node.XM_XH = i + 1;
                node.XM_ID = (int)lists[i].ZBSKDJ_XMID;
                node.XM_MC = lists[i].ZBXMBD.ZBXMBD_FBNR;
                if (null != lists[i].ZBXMBD.ZBXMBD_ZBDW && id == GetUnit((int)lists[i].ZBXMBD.ZBXMBD_ZBDW))
                {
                    node.XM_SFZB = "中标";
                }
                else
                {
                    node.XM_SFZB = "未中标";
                }
                node.XM_ZBJG = lists[i].ZBXMBD.ZBXMBD_ZBJG == null ? 0 : (decimal)lists[i].ZBXMBD.ZBXMBD_ZBJG;
                list.Add(node);
            }
            var griddata = new { Rows = list, Total = T.ToList().Count };
            return Json(griddata);
        }

        private string GetUnit(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            List<Unit> list = entity.Unit.Where(p => p.Unit_ID == id).ToList();
            if (list.Count > 0)
            {
                return list[0].Unit_Name;
            }
            else
            {
                return "";
            }
        }

        #region 收款记录统计

        public ActionResult SKJLTJ(int id)
        {
            ViewData["XMID"] = id;
            return View();
        }

        public ActionResult GetDLF(int id)
        {
            //当前页
            int page = Convert.ToInt32(Request.Params["page"]);
            //每页显示的记录数
            int pagesize = Convert.ToInt32(Request.Params["pagesize"]);
            DataEntityDataContext entity = new DataEntityDataContext();
            IList<SKNode> list = new List<SKNode>();
            SKNode node = null;
            var T = entity.ZBSKDJ.Where(p => p.ZBSKDJ_XMID == id && p.ZBSKDJ_LB == "DLF");
            List<ZBSKDJ> lists = (List<ZBSKDJ>)T.ToList().Skip((page - 1) * pagesize).Take(pagesize).ToList();
            for (var i = 0; i < lists.Count; i++)
            {
                node = new SKNode();
                node.SK_XH = i + 1;
                node.SK_ZZF = lists[i].ZBSKDJ_ZFF;
                node.SK_SKR = lists[i].ZBSKDJ_SKR;
                node.SK_SKSJ = (DateTime)lists[i].ZBSKDJ_SKRQ;
                node.SK_JE = lists[i].ZBSKDJ_SKJE == null ? 0 : (decimal)lists[i].ZBSKDJ_SKJE;
                list.Add(node);
            }
            var griddata = new { Rows = list, Total = T.ToList().Count };
            return Json(griddata);
        }

        public ActionResult GetGBF(int id)
        {
            //当前页
            int page = Convert.ToInt32(Request.Params["page"]);
            //每页显示的记录数
            int pagesize = Convert.ToInt32(Request.Params["pagesize"]);
            DataEntityDataContext entity = new DataEntityDataContext();
            IList<SKNode> list = new List<SKNode>();
            SKNode node = null;
            var T = entity.ZBSKDJ.Where(p => p.ZBSKDJ_XMID == id && p.ZBSKDJ_LB == "GBF");
            List<ZBSKDJ> lists = (List<ZBSKDJ>)T.ToList().Skip((page - 1) * pagesize).Take(pagesize).ToList();
            for (var i = 0; i < lists.Count; i++)
            {
                node = new SKNode();
                node.SK_XH = i + 1;
                node.SK_ZZF = lists[i].ZBSKDJ_ZFF;
                node.SK_SKR = lists[i].ZBSKDJ_SKR;
                node.SK_SKSJ = (DateTime)lists[i].ZBSKDJ_SKRQ;
                node.SK_JE = lists[i].ZBSKDJ_SKJE == null ? 0 : (decimal)lists[i].ZBSKDJ_SKJE;
                list.Add(node);
            }
            var griddata = new { Rows = list, Total = T.ToList().Count };
            return Json(griddata);
        }

        public ActionResult GetBZJ(int id)
        {
            //当前页
            int page = Convert.ToInt32(Request.Params["page"]);
            //每页显示的记录数
            int pagesize = Convert.ToInt32(Request.Params["pagesize"]);
            DataEntityDataContext entity = new DataEntityDataContext();
            IList<SKNode> list = new List<SKNode>();
            SKNode node = null;
            var T = entity.ZBSKDJ.Where(p => p.ZBSKDJ_XMID == id && p.ZBSKDJ_LB == "BZJ");
            List<ZBSKDJ> lists = (List<ZBSKDJ>)T.ToList().Skip((page - 1) * pagesize).Take(pagesize).ToList();
            for (var i = 0; i < lists.Count; i++)
            {
                node = new SKNode();
                node.SK_XH = i + 1;
                node.SK_ZZF = lists[i].ZBSKDJ_ZFF;
                node.SK_SKR = lists[i].ZBSKDJ_SKR;
                node.SK_SKSJ = (DateTime)lists[i].ZBSKDJ_SKRQ;
                node.SK_JE = lists[i].ZBSKDJ_SKJE == null ? 0 : (decimal)lists[i].ZBSKDJ_SKJE;
                if (lists[i].ZBSKDJ_BZJZT == 1)
                {
                    node.SK_ZT = "已退";
                    node.SK_THRQ = (DateTime)lists[i].ZBSKDJ_THSJ;
                }
                else
                {
                    node.SK_ZT = "未退";
                    node.SK_THRQ = DateTime.MinValue;
                }

                list.Add(node);
            }
            var griddata = new { Rows = list, Total = T.ToList().Count };
            return Json(griddata);
        }

        #endregion

    }

}
