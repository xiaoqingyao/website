﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WoExpress.DataEntity.Models;

namespace WoExpress.ZBGL.Controllers
{
    public class CYBGController : Controller
    {
        //
        // GET: /CYBG/

        public ActionResult ZBWJBALCB(int id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            WoExpress.DataEntity.Models.ZBXMXX oXMXX = new WoExpress.DataEntity.Models.ZBXMXX();
            oXMXX = context.ZBXMXX.Where(p => p.ZBXMXX_ID == id).ToList()[0];
            return View(oXMXX);
        }

        public ActionResult ZBWJDJB(int id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            WoExpress.DataEntity.Models.ZBXMXX oXMXX = new WoExpress.DataEntity.Models.ZBXMXX();
            oXMXX = context.ZBXMXX.Where(p => p.ZBXMXX_ID == id).ToList()[0];
            return View(oXMXX);
        }

    }
}
