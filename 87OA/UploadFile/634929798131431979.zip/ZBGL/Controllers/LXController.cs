﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WoExpress.DataEntity.Models;
using WoExpress.Core.Page;
using WoExpress.Core.Utility;
using WoExpress.Core.Data;
using System.Data;

namespace WoExpress.ZBGL.Controllers
{
    public class LXController : Controller
    {
        const int iPageSize = 10;

        #region 招标立项

        public ActionResult ZBLX(int id)
        {
            ViewData["id"] = id;
            return View();
        }

        public ActionResult ZBLXList(int iPageNo, string id, string sKSRQS, string sJSRQE)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZBLX.Where(p => p.ZBLX_ID != 0);
            if (int.Parse(id) != 0)
            {
                T = T.Where(p => p.ZBLX_XMID == int.Parse(id));
            }
            if (!String.IsNullOrEmpty(sKSRQS))
                T = T.Where(p => p.ZBLX_LXSJ >= DateTime.Parse(sKSRQS));
            if (!String.IsNullOrEmpty(sJSRQE))
                T = T.Where(p => p.ZBLX_LXSJ <= DateTime.Parse(sJSRQE));
            T = T.OrderByDescending(p => p.ZBLX_WHSJ);
            return View(TPageWizard.GetData<ZBLX>(iPageSize, iPageNo, T.ToList()));
        }

        public ActionResult ZBLXInfo(int id, string sOperate)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            ZBLX oZTBGG = new ZBLX();
            switch (sOperate)
            {
                case "N":
                    oZTBGG.ZBLX_GRPID = MisproUtils.GetNewID("ZBLX");
                    oZTBGG.ZBLX_ID = 0;
                    break;
                case "E":
                    oZTBGG = context.ZBLX.SingleOrDefault(p => p.ZBLX_ID == id);
                    break;
                case "V":
                    oZTBGG = context.ZBLX.SingleOrDefault(p => p.ZBLX_ID == id);
                    break;
                default:
                    break;
            }
            ViewData["Operate"] = sOperate;

            return View(oZTBGG);
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZBLXDel(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZBLX.SingleOrDefault(p => p.ZBLX_ID == id);
            try
            {
                entity.ZBLX.DeleteOnSubmit(T);
                entity.SubmitChanges();
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZBLXSave(int id, string LXSJ, string LXWH, string LXBM, string LXBT, int iGRPID, decimal ZTZE, string XMDD, int XMID, string sOperate)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                ZBLX oZTBGG = new ZBLX();
                switch (sOperate)
                {
                    case "N":
                        oZTBGG.ZBLX_ID = MisproUtils.GetMaxTblID("ZBLX", "ZBLX_ID");
                        oZTBGG.ZBLX_XMID = 0;
                        oZTBGG.ZBLX_LXWH = LXWH;
                        oZTBGG.ZBLX_LXBM = LXBM;
                        oZTBGG.ZBLX_LXBT = LXBT;
                        if (!String.IsNullOrEmpty(LXSJ))
                        {
                            oZTBGG.ZBLX_LXSJ = DateTime.Parse(LXSJ);
                        }
                        oZTBGG.ZBLX_XMDD = XMDD;
                        oZTBGG.ZBLX_ZTZE = ZTZE;
                        oZTBGG.ZBLX_GRPID = iGRPID;
                        oZTBGG.ZBLX_XMID = XMID;
                        if (XMID != 0)
                        {
                            ZBXMXX oXMLB = context.ZBXMXX.SingleOrDefault(p => p.ZBXMXX_ID == XMID);
                            if (null != oXMLB)
                            {
                                oXMLB.ZBXMXX_LXID = oZTBGG.ZBLX_ID;
                            }
                            context.ZBXMXX.Context.SubmitChanges();
                        }
                        oZTBGG.ZBLX_FJS = context.ZBLXFJ.Where(p => p.ZBLXFJ_GRPID == iGRPID).Count();
                        oZTBGG.ZBLX_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oZTBGG.ZBLX_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oZTBGG.ZBLX_WHSJ = DateTime.Now;
                        context.ZBLX.InsertOnSubmit(oZTBGG);
                        context.ZBLX.Context.SubmitChanges();
                        break;
                    case "E":
                        oZTBGG = context.ZBLX.SingleOrDefault(p => p.ZBLX_ID == id);
                        oZTBGG.ZBLX_LXWH = LXWH;
                        oZTBGG.ZBLX_LXBM = LXBM;
                        oZTBGG.ZBLX_LXBT = LXBT;
                        if (!String.IsNullOrEmpty(LXSJ))
                        {
                            oZTBGG.ZBLX_LXSJ = DateTime.Parse(LXSJ);
                        }
                        if (XMID!=0)
                        {
                        oZTBGG.ZBLX_XMID = XMID;
                        }
                        oZTBGG.ZBLX_XMDD = XMDD;
                        oZTBGG.ZBLX_ZTZE = ZTZE;
                        oZTBGG.ZBLX_GRPID = iGRPID;
                        oZTBGG.ZBLX_FJS = context.ZBLXFJ.Where(p => p.ZBLXFJ_GRPID == iGRPID).Count();
                        oZTBGG.ZBLX_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oZTBGG.ZBLX_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oZTBGG.ZBLX_WHSJ = DateTime.Now;
                        context.ZBLX.Context.SubmitChanges();
                        break;
                    default:
                        break;
                }
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }


        #endregion
    }
}
