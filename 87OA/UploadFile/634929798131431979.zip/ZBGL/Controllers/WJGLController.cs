﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WoExpress.Core.Data;
using WoExpress.Core.Utility;
using WoExpress.DataEntity.Models;
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using WoExpress.Core.Page;
using System.IO;
using System.Xml;

namespace WoExpress.ZBGL.Controllers
{
    public class WJGLController : Controller
    {
        const int iPageSize = 12;
        static string LBID = "";

        #region 文件管理

        public ActionResult WJGL()
        {
            return View();
        }


        public ActionResult WJList(int iPageNo, string sWJM, string sPXFS, string LBID,int BDID,int XMID, string GXRID)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            Users oUser = CMisproApp.GetCurrentUser();
            if (entity.Connection.State == ConnectionState.Closed)
                entity.Connection.Open();
            SqlCommand command = new SqlCommand("select * " +
                " from ZBWJGL", (SqlConnection)entity.Connection);
            using (DbDataReader read = command.ExecuteReader(CommandBehavior.CloseConnection))
            {
                var T = entity.Translate<ZBWJGL>(read).ToList();
                    if (LBID == "0")
                        T = T.Where(p => p.ZBWJGL_SCZID == oUser.Users_ID).ToList();
                    else
                    {
                        //string s = "";
                        //s = "," + LBID + GetZBWJGL(int.Parse(LBID)) + ",";
                        T = T.Where(p =>p.ZBWJGL_WJLB==LBID && p.ZBWJGL_XMID==XMID && p.ZBWJGL_BDID==BDID).ToList();
                    }
                if (!String.IsNullOrEmpty(sWJM))
                    T = T.Where(p => p.ZBWJGL_WJM.IndexOf(sWJM) >= 0).ToList();
                if (sPXFS == "1")
                    T = T.OrderByDescending(p => p.ZBWJGL_SCSJ).ToList();
                else if (sPXFS == "2")
                    T = T.OrderBy(p => p.ZBWJGL_SCSJ).ToList();
                else if (sPXFS == "3")
                    T = T.OrderByDescending(p => p.ZBWJGL_XZCS).ToList();
                else if (sPXFS == "4")
                    T = T.OrderBy(p => p.ZBWJGL_XZCS).ToList();
                return View(TPageWizard.GetData<ZBWJGL>(iPageSize - 1, iPageNo, T.ToList()));
            }
        }

        public ActionResult WJUploadFile(string id)
        {
            LBID = id;
            return View();
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public string WJUpload(FormCollection fc)
        {
            int n = Request.Files.Count;
            for (int i = 0; i < n; i++)
            {
                var fa = Request.Files[i];
                if (fa.FileName.Length > 0)
                {
                    string[] pn = fa.FileName.Split('\\');
                    int k = fa.ContentLength;
                    byte[] dbuff = new byte[k];
                    Stream stream = fa.InputStream;
                    stream.Read(dbuff, 0, k);

                    DataEntityDataContext entity = new DataEntityDataContext();
                    ZBWJGL oZBWJGL = new ZBWJGL();
                    oZBWJGL.ZBWJGL_XMID =int.Parse(Request.Form["XMID"]);
                    oZBWJGL.ZBWJGL_BDID = int.Parse(Request.Form["BDID"]);
                    oZBWJGL.ZBWJGL_WJM = pn[pn.Length - 1];
                    oZBWJGL.ZBWJGL_WJDX = (k / 1024).ToString() + "KB";
                    oZBWJGL.ZBWJGL_SCZID = CMisproApp.GetCurrentUser().Users_ID;
                    oZBWJGL.ZBWJGL_SCZXM = CMisproApp.GetCurrentUser().Users_Name;
                    oZBWJGL.ZBWJGL_SCSJ = DateTime.Now;
                    oZBWJGL.ZBWJGL_XZCS = 0;
                    oZBWJGL.ZBWJGL_WJNR = dbuff;
                    oZBWJGL.ZBWJGL_WJLX = fa.ContentType;
                    oZBWJGL.ZBWJGL_WJLB =Request.Form["LBID"];
                    entity.ZBWJGL.InsertOnSubmit(oZBWJGL);
                    entity.ZBWJGL.Context.SubmitChanges();
                }
            }
            return "success";
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string WJDelete(int id)
        {
            try
            {
                DataEntityDataContext entity = new DataEntityDataContext();
                var T = entity.ZBWJGL.SingleOrDefault(p => p.ZBWJGL_ID == id);
                entity.ZBWJGL.DeleteOnSubmit(T);
                entity.ZBWJGL.Context.SubmitChanges();
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public ActionResult WJDownloadFile(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZBWJGL.SingleOrDefault(p => p.ZBWJGL_ID == id);
            byte[] buffer = null;
            buffer = T.ZBWJGL_WJNR.ToArray();
            string sFileType = T.ZBWJGL_WJLX;
            string sFileName = HttpUtility.UrlEncode(T.ZBWJGL_WJM);
            T.ZBWJGL_XZCS = T.ZBWJGL_XZCS + 1;
            entity.GGWJ.Context.SubmitChanges();
            return File(buffer, sFileType, sFileName);
        }


        public ActionResult GetZBWJLBTree(int id)
        {
            ViewData["XMLData"] = GetZBWJLBXML(id);
           // ViewData["GXXMLData"] = GetGXWJLBXML();
            return View();
        }

        public string GetZBWJLBXML(int id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.ZBXMXX.SingleOrDefault(p=>p.ZBXMXX_ID==id);
            XmlDocument doc = new XmlDocument();
            XmlElement root = doc.CreateElement("tree");
            root.SetAttribute("id", "0");
            doc.AppendChild(root);

            XmlElement item = doc.CreateElement("item");
            if (null == T)
            {
                item.SetAttribute("text", "项目文件");
                
            }
            else
            {
                item.SetAttribute("text", T.ZBXMXX_XMMC);
            }
            item.SetAttribute("id", id.ToString());
            item.SetAttribute("open", "1");
            item.SetAttribute("im0", "folderClosed.gif");
            item.SetAttribute("im1", "folderOpen.gif");
            item.SetAttribute("im2", "folderClosed.gif");
            item.SetAttribute("call", "1");
            item.SetAttribute("select", "1");
            
            root.AppendChild(item);
            var TT = context.ZBXMBD.Where(p => p.ZBXMBD_XMID == id);
            foreach (var t in TT)
            {
                XmlElement items = doc.CreateElement("item");
                items.SetAttribute("text", t.ZBXMBD_FBNR);
                items.SetAttribute("id", "BD"+t.ZBXMBD_ID.ToString());
                item.SetAttribute("im0", "folderClosed.gif");
                item.SetAttribute("im1", "folderOpen.gif");
                item.SetAttribute("im2", "folderClosed.gif");
                item.AppendChild(items);
                CreateGRXmlInfo(t.ZBXMBD_ID, doc, items);
            }

            return "<?xml version=\"1.0\" encoding=\"utf-16\" ?>" + doc.InnerXml;
        }

        public void CreateGRXmlInfo(double p_FID, XmlDocument p_Doc, XmlElement p_Element)
        {
            DataEntityDataContext context = new DataEntityDataContext();

            var T = context.ZBWJLB.Where(p => p.ZBWJLB_ID>0);
            foreach (var t in T)
            {
                ZBWJLB oZBWJLB = context.ZBWJLB.SingleOrDefault(p => p.ZBWJLB_ID == t.ZBWJLB_ID);
                XmlElement item = p_Doc.CreateElement("item");
                item.SetAttribute("text", oZBWJLB.ZBWJLB_MC);
                item.SetAttribute("id", oZBWJLB.ZBWJLB_ID.ToString());
                    item.SetAttribute("im0", "leaf.gif");
                    item.SetAttribute("im1", "leaf.gif");
                    item.SetAttribute("im2", "leaf.gif");
                p_Element.AppendChild(item);
            }
        }

        public string GetGXWJLBXML()
        {
            XmlDocument doc = new XmlDocument();
            XmlElement root = doc.CreateElement("tree");
            root.SetAttribute("id", "0");
            doc.AppendChild(root);

            XmlElement item = doc.CreateElement("item");
            item.SetAttribute("text", "共享文件");
            item.SetAttribute("id", "All");
            item.SetAttribute("open", "1");
            item.SetAttribute("im0", "folderClosed.gif");
            item.SetAttribute("im1", "folderOpen.gif");
            item.SetAttribute("im2", "folderClosed.gif");
            item.SetAttribute("call", "1");
            root.AppendChild(item);

            CreateGXXmlInfo(doc, item);

            return "<?xml version=\"1.0\" encoding=\"utf-16\" ?>" + doc.InnerXml;
        }

        public void CreateGXXmlInfo(XmlDocument p_Doc, XmlElement p_Element)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            XmlElement wode = p_Doc.CreateElement("item");
            wode.SetAttribute("text", "我的共享");
            wode.SetAttribute("id", CMisproApp.GetCurrentUser().Users_ID);
            wode.SetAttribute("im0", "leaf.gif");
            wode.SetAttribute("im1", "leaf.gif");
            wode.SetAttribute("im2", "leaf.gif");
            p_Element.AppendChild(wode);
            var T = context.ZBWJGL.Where(p => p.ZBWJGL_GXRID.IndexOf("," + CMisproApp.GetCurrentUser().Users_PersonID.ToString() + ",") >= 0);
            if (T.Count() > 0)
            {
                string sql = "select distinct ZBWJGL_SCZID, ZBWJGL_SCZXM from ZBWJGL "
                             + " where ZBWJGL_GXRID like'%," + CMisproApp.GetCurrentUser().Users_PersonID.ToString() + ",%'";
                List<SCZXM> oSCZXM = new List<SCZXM>();
                DBHelper oDBHelper = null;
                oDBHelper = new DBHelper();
                using (IDataReader dr = oDBHelper.ExecuteReader(CommandType.Text, sql))
                {
                    while (dr.Read())
                    {
                        SCZXM oscz = new SCZXM();
                        oscz.sSXZID = dr["ZBWJGL_SCZID"].ToString();
                        oscz.sXM = dr["ZBWJGL_SCZXM"].ToString();
                        oSCZXM.Add(oscz);
                    }
                }
                foreach (var t in oSCZXM)
                {
                    XmlElement item = p_Doc.CreateElement("item");
                    item.SetAttribute("text", t.sXM);
                    item.SetAttribute("id", t.sSXZID);
                    item.SetAttribute("im0", "leaf.gif");
                    item.SetAttribute("im1", "leaf.gif");
                    item.SetAttribute("im2", "leaf.gif");
                    p_Element.AppendChild(item);
                }
            }
        }

        public string GetZBWJGL(int iWJLB)
        {
            string s = "";
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.ZBWJLB.Where(p => p.ZBWJLB_ID == iWJLB).ToList();
            if (T.Count() == 0)
                return s;
            else
            {
                foreach (var t1 in T)
                {
                    int iLBID = t1.ZBWJLB_ID;
                    s += GetZBWJGL(iLBID) + "," + iLBID;
                }
                return s;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string GXWJSave(string id, string sPersonIDs, string sPersonNames)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                ZBWJGL oZBWJGL = new ZBWJGL();
                oZBWJGL = context.ZBWJGL.SingleOrDefault(p => p.ZBWJGL_ID == int.Parse(id));
                oZBWJGL.ZBWJGL_GXRID = sPersonIDs;
                oZBWJGL.ZBWJGL_GXR = sPersonNames;
                context.SubmitChanges();
            }
            catch (Exception mes)
            {
                return mes.Message;
            }
            return "";
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string GXWJJSave(string LBID, string sPersonIDs, string sPersonNames)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                string sWJLB = "," + LBID + GetZBWJGL(int.Parse(LBID)) + ",";
                var T = context.ZBWJGL.Where(p => sWJLB.IndexOf("," + p.ZBWJGL_WJLB + ",") >= 0);
                int ii = T.Count();
                foreach (var t in T)
                {
                    ZBWJGL oZBWJGL = new ZBWJGL();
                    oZBWJGL = context.ZBWJGL.SingleOrDefault(p => p.ZBWJGL_ID == t.ZBWJGL_ID);
                    oZBWJGL.ZBWJGL_GXRID = sPersonIDs;
                    oZBWJGL.ZBWJGL_GXR = sPersonNames;
                    context.SubmitChanges();
                }
                return "";
            }
            catch (Exception mes)
            {
                return mes.Message;
            }
        }
        #endregion

        #region 选择文件类别、人员
    

        public ActionResult XZGXRY(string id)
        {
            ViewData["xmlData"] = GetPersonXML(id);
            return View();
        }

        public string GetPersonXML(string id)
        {
            XmlDocument doc = new XmlDocument();
            XmlElement root = doc.CreateElement("tree");
            root.SetAttribute("id", "0");
            doc.AppendChild(root);
            XmlElement item = doc.CreateElement("item");
            item.SetAttribute("text", "所有人员");
            item.SetAttribute("id", "All");
            item.SetAttribute("open", "1");
            item.SetAttribute("im0", "folderClosed.gif");
            item.SetAttribute("im1", "folderOpen.gif");
            item.SetAttribute("im2", "folderClosed.gif");
            item.SetAttribute("call", "1");
            item.SetAttribute("select", "1");
            root.AppendChild(item);
            CreatePersonXmlInfo(doc, item, id);

            return "<?xml version=\"1.0\" encoding=\"utf-16\" ?>" + doc.InnerXml;
        }

        public void CreatePersonXmlInfo(XmlDocument p_Doc, XmlElement p_Element, string id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            ZBWJGL oZBWJGL = new ZBWJGL();
            if (id != "0")
            {
                oZBWJGL = context.ZBWJGL.SingleOrDefault(p => p.ZBWJGL_ID == int.Parse(id));
            }
            int unitid = 0;
            try
            {
                 unitid = CMisproApp.GetCurrentUser().Person.Unit.Unit_ID;
            }
            catch(Exception ex)
            {

            }
            var listUnits = context.Unit.Where(p => p.Unit_ID ==unitid);
            foreach (var oUnit in listUnits)
            {
                var persons = context.Person.Where(p => p.Person_UnitID == oUnit.Unit_ID);
                bool myself = false;
                var personsMyself = context.Person.Where(p => p.Person_UnitID == oUnit.Unit_ID && p.Person_ID == CMisproApp.GetCurrentUser().Users_PersonID);
                if (personsMyself.Count() == 1 && persons.Count() == 1)
                    myself = true;
                else
                    myself = false;
                if (persons.Count() > 0 && myself == false)
                {
                    XmlElement Unititem = p_Doc.CreateElement("item");
                    Unititem.SetAttribute("text", oUnit.Unit_Name);
                    Unititem.SetAttribute("id", "U" + oUnit.Unit_ID.ToString());
                    Unititem.SetAttribute("im0", "folderClosed.gif");
                    Unititem.SetAttribute("im1", "folderOpen.gif");
                    Unititem.SetAttribute("im2", "folderClosed.gif");
                    p_Element.AppendChild(Unititem);
                    var listZSP = context.Person.Where(p => p.Person_UnitID == oUnit.Unit_ID && p.Person_DepartmentID == 0);
                    if (listZSP.Count() > 0)
                    {
                        foreach (var oZSP in listZSP)
                        {
                            if (oZSP.Person_ID != CMisproApp.GetCurrentUser().Users_PersonID)
                            {
                                XmlElement per = p_Doc.CreateElement("item");
                                per.SetAttribute("text", oZSP.Person_Name);
                                per.SetAttribute("id", "P" + oZSP.Person_ID.ToString());
                                per.SetAttribute("im0", "person.gif");
                                per.SetAttribute("im1", "person.gif");
                                per.SetAttribute("im2", "person.gif");
                                if (!String.IsNullOrEmpty(oZBWJGL.ZBWJGL_GXRID) && oZBWJGL.ZBWJGL_GXRID.IndexOf("," + oZSP.Person_ID + ",") >= 0)
                                {
                                    per.SetAttribute("checked", "true");
                                    per.SetAttribute("open", "1");
                                }
                                Unititem.AppendChild(per);
                            }
                        }
                    }
                    var listDepartment = context.Department.Where(p => p.Department_UnitID == oUnit.Unit_ID);
                    if (listDepartment.Count() > 0)
                    {
                        foreach (var oDepartment in listDepartment)
                        {
                            bool departmyself = false;
                            var listPersons = context.Person.Where(p => p.Person_DepartmentID == oDepartment.Department_ID);
                            var Dmyself = context.Person.Where(p => p.Person_DepartmentID == oDepartment.Department_ID && p.Person_ID == CMisproApp.GetCurrentUser().Users_PersonID);
                            if (Dmyself.Count() == 1 && listPersons.Count() == 1)
                                departmyself = true;
                            if (listPersons.Count() > 0 && departmyself == false)
                            {
                                XmlElement dep = p_Doc.CreateElement("item");
                                dep.SetAttribute("text", oDepartment.Department_Name);
                                dep.SetAttribute("id", "D" + oDepartment.Department_ID.ToString());
                                dep.SetAttribute("im0", "folderClosed.gif");
                                dep.SetAttribute("im1", "folderOpen.gif");
                                dep.SetAttribute("im2", "folderClosed.gif");
                                Unititem.AppendChild(dep);
                                foreach (var oPerson in listPersons)
                                {
                                    if (oPerson.Person_ID != CMisproApp.GetCurrentUser().Users_PersonID)
                                    {
                                        XmlElement per = p_Doc.CreateElement("item");
                                        per.SetAttribute("text", oPerson.Person_Name);
                                        per.SetAttribute("id", "P" + oPerson.Person_ID.ToString());
                                        per.SetAttribute("im0", "person.gif");
                                        per.SetAttribute("im1", "person.gif");
                                        per.SetAttribute("im2", "person.gif");
                                        if (!String.IsNullOrEmpty(oZBWJGL.ZBWJGL_GXRID) && oZBWJGL.ZBWJGL_GXRID.IndexOf("," + oPerson.Person_ID + ",") >= 0)
                                        {
                                            per.SetAttribute("checked", "true");
                                            per.SetAttribute("open", "1");
                                        }
                                        dep.AppendChild(per);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        public string getPersonNames(string sPersonIDs)
        {
            if (!String.IsNullOrEmpty(sPersonIDs))
            {
                DataEntityDataContext context = new DataEntityDataContext();
                string sIDs = "";
                string sPersons = "";
                string[] arrID = sPersonIDs.Split(',');
                foreach (var t in arrID)
                {
                    if (!String.IsNullOrEmpty(t))
                    {
                        if (t.StartsWith("P"))
                        {
                            var oPerson = context.Person.SingleOrDefault(p => p.Person_ID == int.Parse(t.Substring(1)));
                            if (sIDs == "")
                            {
                                sIDs = "," + t.Substring(1) + ",";
                                sPersons = oPerson.Person_Name;
                            }
                            else
                            {
                                sIDs += t.Substring(1) + ",";
                                sPersons += "," + oPerson.Person_Name;
                            }

                        }
                    }
                }
                return sIDs + "|" + sPersons;
            }
            else
            {
                return "";
            }
        }
        #endregion

        public class SCZXM
        {
            public string sXM;
            public string sSXZID;
        }

        public int GetWJLBPX(int FID, string LX)
        {
            DBHelper oDBHelper = null;
            oDBHelper = new DBHelper();
            int defaultID = 0;
            int maxPXH = 0;
            string sql = "";
            if (LX == "GG")
                sql = "select isnull(max(WJLB_PXH),0) from WJLB where WJLB_FID = " + FID;
            else
                sql = "select isnull(max(ZBWJLB_PXH),0) from ZBWJLB where ZBWJLB_FID = " + FID
                    + " and ZBWJLB_SSRID = '" + CMisproApp.GetCurrentUser().Users_ID + "'";
            maxPXH = Convert.ToInt32(oDBHelper.ExecuteScalar(CommandType.Text, sql));
            defaultID = maxPXH - maxPXH % 10 + 10;
            return defaultID;
        }
    }
}
