﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WoExpress.DataEntity.Models;
using WoExpress.Core.Page;
using WoExpress.Core.Utility;
using WoExpress.Core.Data;

namespace WoExpress.ZBGL.Controllers
{
    /// <summary>
    /// 项目概况控制器
    /// </summary>
    public class XMGKController : Controller
    {
        public ActionResult GetXMGKInfo()
        {
            TXMGKInfo o = new TXMGKInfo();
            var TProjectsOfBulletinInThisWeek = GetProjectsOfBulletinInThisWeek();
            var TProjectsOfBulletinInNextWeek = GetProjectsOfBulletinInNextWeek();
            var TProjectsOfBidInThisWeek = GetProjectsOfBidInThisWeek();
            var TProjectsOfBidInNextWeek = GetProjectsOfBidInNextWeek();
            o.CountOfBulletinInThisWeek = TProjectsOfBulletinInThisWeek.Count;
            o.CountOfBulletinInNextWeek = TProjectsOfBulletinInNextWeek.Count;
            o.CountOfBidInThisWeek = TProjectsOfBidInThisWeek.Count;
            o.CountOfBidInNextWeek = TProjectsOfBidInNextWeek.Count;
            o.ProjectsOfBulletinInThisWeek = TProjectsOfBulletinInThisWeek;
            o.ProjectsOfBulletinInNextWeek = TProjectsOfBulletinInNextWeek;
            o.ProjectsOfBidInThisWeek = TProjectsOfBidInThisWeek;
            o.ProjectsOfBidInNextWeek = TProjectsOfBidInNextWeek;
            return View(o);
        }

        private DateTime GetTheFirstDayOfThisWeek()
        {
            DateTime dt = DateTime.Today;
            int iDayOfWeek = 0;
            switch (dt.DayOfWeek)
            {
                case DayOfWeek.Sunday:
                    iDayOfWeek = 0;
                    break;
                case DayOfWeek.Monday:
                    iDayOfWeek = 1;
                    break;
                case DayOfWeek.Tuesday:
                    iDayOfWeek = 2;
                    break;
                case DayOfWeek.Wednesday:
                    iDayOfWeek = 3;
                    break;
                case DayOfWeek.Thursday:
                    iDayOfWeek = 4;
                    break;
                case DayOfWeek.Friday:
                    iDayOfWeek = 5;
                    break;
                case DayOfWeek.Saturday:
                    iDayOfWeek = 6;
                    break;
                default:
                    break;
            }
            return dt.AddDays(iDayOfWeek * (-1));
        }

        public List<ZBXMXX> GetProjectsOfBulletinInThisWeek()
        {
            DateTime dtMin = GetTheFirstDayOfThisWeek();
            DateTime dtMax = dtMin.AddDays(7);
            DataEntityDataContext context = new DataEntityDataContext();
            return context.ZBXMXX.Where(p => p.ZBGG.Where(c => c.ZBGG_GGSJE >= dtMin && c.ZBGG_GGSJB <= dtMax).Count() > 0).ToList();
        }

        public List<ZBXMXX> GetProjectsOfBulletinInNextWeek()
        {
            DateTime dtMin = GetTheFirstDayOfThisWeek();
            DateTime dtNextMin = dtMin.AddDays(7);
            DateTime dtNextMax = dtMin.AddDays(14);
            DataEntityDataContext context = new DataEntityDataContext();
            return context.ZBXMXX.Where(p => p.ZBGG.Where(c => c.ZBGG_GGSJE >= dtNextMin && c.ZBGG_GGSJB <= dtNextMax).Count() > 0).ToList();
        }

        public List<ZBXMXX> GetProjectsOfBidInThisWeek()
        {
            DateTime dtMin = GetTheFirstDayOfThisWeek();
            DateTime dtMax = dtMin.AddDays(7);
            DataEntityDataContext context = new DataEntityDataContext();
            return context.ZBXMXX.Where(p => p.ZBWJ.Where(c => c.ZBWJ_KBSJ >= dtMin && c.ZBWJ_KBSJ <= dtMax).Count() > 0).ToList();
        }

        public List<ZBXMXX> GetProjectsOfBidInNextWeek()
        {
            DateTime dtMin = GetTheFirstDayOfThisWeek();
            DateTime dtNextMin = dtMin.AddDays(7);
            DateTime dtNextMax = dtMin.AddDays(14);
            DataEntityDataContext context = new DataEntityDataContext();
            return context.ZBXMXX.Where(p => p.ZBWJ.Where(c => c.ZBWJ_KBSJ >= dtNextMin && c.ZBWJ_KBSJ <= dtNextMax).Count() > 0).ToList();
        }
    }

    /// <summary>
    /// 项目概况数据定义
    /// </summary>
    public class TXMGKInfo
    {
        public int CountOfBulletinInThisWeek { get; set; }  //本周公告项目数
        public int CountOfBulletinInNextWeek { get; set; }  //下周公告项目数
        public int CountOfBidInThisWeek { get; set; }       //本周开标项目数
        public int CountOfBidInNextWeek { get; set; }       //下周开标项目数
        public List<ZBXMXX> ProjectsOfBulletinInThisWeek;
        public List<ZBXMXX> ProjectsOfBulletinInNextWeek;
        public List<ZBXMXX> ProjectsOfBidInThisWeek;
        public List<ZBXMXX> ProjectsOfBidInNextWeek;
        public TXMGKInfo()
        {
            ProjectsOfBulletinInThisWeek = new List<ZBXMXX>();
            ProjectsOfBulletinInNextWeek = new List<ZBXMXX>();
            ProjectsOfBidInThisWeek = new List<ZBXMXX>();
            ProjectsOfBidInNextWeek = new List<ZBXMXX>();
        }
    }
}
