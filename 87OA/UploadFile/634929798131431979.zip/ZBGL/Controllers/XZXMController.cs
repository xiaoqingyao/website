﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WoExpress.DataEntity.Models;
using WoExpress.Core.Page;

namespace WoExpress.ZBGL.Controllers
{
    /// <summary>
    /// 选择项目控制器
    /// </summary>
    public class XZXMController : Controller
    {
        #region 选择招标项目
        public ActionResult XMXX(int id)
        {
            ViewData["ID"] = id;
            return View();
        }

        public ActionResult XMXXList(int iPageNo, int id, string sXMMC)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            List<int> lst = new List<int>();
            lst.Add(id);
            GetChildIDList(id, ref lst);
            var T = entity.ZBXMXX.Where(p => lst.IndexOf(p.ZBXMXX_ID) < 0); //排除当前节点的所有子节点
            if (!String.IsNullOrEmpty(sXMMC))
                T = T.Where(p => p.ZBXMXX_XMMC.IndexOf(sXMMC) >= 0);
            T = T.OrderByDescending(p => p.ZBXMXX_XMBH);
            return View(TPageWizard.GetData<ZBXMXX>(12, iPageNo, T.ToList()));
        }

        private void GetChildIDList(int id, ref List<int> lst)
        {
            using (DataEntityDataContext context = new DataEntityDataContext())
            {
                foreach (var t in context.ZBXMXX.Where(p => p.ZBXMXX_FID == id))
                {
                    lst.Add(t.ZBXMXX_ID);
                    if (context.ZBXMXX.Where(p => p.ZBXMXX_FID == t.ZBXMXX_ID).Count() > 0)
                        GetChildIDList(t.ZBXMXX_ID, ref lst);
                }
            }
        }
        #endregion
    }
}
