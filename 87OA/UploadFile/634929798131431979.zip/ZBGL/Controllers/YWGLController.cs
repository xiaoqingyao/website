﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Collections;
using System.IO;
using WoExpress.DataEntity.Models;
using WoExpress.Core.Page;
using WoExpress.Core.Utility;
using WoExpress.Core.Workflow;
using WoExpress.Core.Data;
using WoExpress.ZBGL.Models;
using System.Runtime.Serialization.Json;
using WoExpress.PUBLIC.Controllers;

namespace WoExpress.ZBGL.Controllers
{
    /// <summary>
    /// 业务管理控制器
    /// </summary>
    public class YWGLController : Controller
    {
        const int iPageSize = 12;

        #region 项目类别

        public ActionResult XMLB()
        {
            return View();
        }

        public ActionResult XMLBList(int iPageNo)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZBXMLB.Where(p => p.ZBXMLB_ID != 0);
            return View(TPageWizard.GetData<ZBXMLB>(iPageSize, iPageNo, T.ToList()));
        }

        public ActionResult XMLBInfo(int id, string sOperate)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            WoExpress.DataEntity.Models.ZBXMLB oXMLB = new WoExpress.DataEntity.Models.ZBXMLB();
            switch (sOperate)
            {
                case "N":
                    break;
                case "E":
                    oXMLB = entity.ZBXMLB.SingleOrDefault(p => p.ZBXMLB_ID == id);
                    break;
                case "V":
                    oXMLB = entity.ZBXMLB.SingleOrDefault(p => p.ZBXMLB_ID == id);
                    break;
                default:
                    break;
            }
            ViewData["Operate"] = sOperate;

            return View(oXMLB);
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string XMLBDel(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZBXMLB.SingleOrDefault(p => p.ZBXMLB_ID == id);
            if (entity.ZBXMGK.Where(p => p.ZBXMGK_XMLB == id).Count() > 0)
                return "该类型已被使用，不允许删除！";
            if (entity.ZBXMXX.Where(p => p.ZBXMXX_XMLB == id).Count() > 0)
                return "该类型已被使用，不允许删除！";

            try
            {
                entity.ZBXMLB.DeleteOnSubmit(T);
                entity.SubmitChanges();
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string XMLBSave(int id, string sMC, string sBZ, string sOperate)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                WoExpress.DataEntity.Models.ZBXMLB oXMLB = new WoExpress.DataEntity.Models.ZBXMLB();
                switch (sOperate)
                {
                    case "N":
                        oXMLB.ZBXMLB_ID = MisproUtils.GetMaxTblID("ZBXMLB", "ZBXMLB_ID");
                        oXMLB.ZBXMLB_MC = sMC;
                        oXMLB.ZBXMLB_BZ = sBZ;
                        oXMLB.ZBXMLB_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oXMLB.ZBXMLB_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oXMLB.ZBXMLB_WHSJ = DateTime.Now;
                        context.ZBXMLB.InsertOnSubmit(oXMLB);
                        context.ZBXMLB.Context.SubmitChanges();
                        break;
                    case "E":
                        oXMLB = context.ZBXMLB.SingleOrDefault(p => p.ZBXMLB_ID == id);
                        oXMLB.ZBXMLB_MC = sMC;
                        oXMLB.ZBXMLB_BZ = sBZ;
                        oXMLB.ZBXMLB_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oXMLB.ZBXMLB_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oXMLB.ZBXMLB_WHSJ = DateTime.Now;
                        context.ZBXMLB.Context.SubmitChanges();
                        break;
                    default:
                        break;
                }
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        #endregion

        #region 收费标准

        public ActionResult SFBZ()
        {
            return View();
        }

        public ActionResult SFBZList()
        {
            return View();
        }
        #endregion

        #region 项目进度

        public ActionResult XMJD()
        {
            return View();
        }

        public ActionResult XMJDList(int iPageNo)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZBXMJD.Where(p => p.ZBXMJD_ID != 0);
            return View(TPageWizard.GetData<ZBXMJD>(iPageSize, iPageNo, T.ToList()));
        }

        public ActionResult XMJDInfo(int id, string sOperate)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            WoExpress.DataEntity.Models.ZBXMJD oXMJD = new WoExpress.DataEntity.Models.ZBXMJD();
            switch (sOperate)
            {
                case "N":
                    break;
                case "E":
                    oXMJD = entity.ZBXMJD.SingleOrDefault(p => p.ZBXMJD_ID == id);
                    break;
                case "V":
                    oXMJD = entity.ZBXMJD.SingleOrDefault(p => p.ZBXMJD_ID == id);
                    break;
                default:
                    break;
            }
            ViewData["Operate"] = sOperate;

            return View(oXMJD);
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string XMJDDel(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZBXMJD.SingleOrDefault(p => p.ZBXMJD_ID == id);
            if (entity.ZBXMJDPZ.Where(p => p.ZBXMJDPZ_JDID == id).Count() > 0)
                return "该进度节点已被使用，不允许删除！";

            try
            {
                entity.ZBXMJD.DeleteOnSubmit(T);
                entity.SubmitChanges();
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string XMJDSave(int id, string sMC, string sBZ, string sOperate)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                WoExpress.DataEntity.Models.ZBXMJD oXMLB = new WoExpress.DataEntity.Models.ZBXMJD();
                switch (sOperate)
                {
                    case "N":
                        oXMLB.ZBXMJD_ID = MisproUtils.GetMaxTblID("ZBXMJD", "ZBXMJD_ID");
                        oXMLB.ZBXMJD_MC = sMC;
                        oXMLB.ZBXMJD_BZ = sBZ;
                        oXMLB.ZBXMJD_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oXMLB.ZBXMJD_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oXMLB.ZBXMJD_WHSJ = DateTime.Now;
                        context.ZBXMJD.InsertOnSubmit(oXMLB);
                        context.ZBXMJD.Context.SubmitChanges();
                        break;
                    case "E":
                        oXMLB = context.ZBXMJD.SingleOrDefault(p => p.ZBXMJD_ID == id);
                        oXMLB.ZBXMJD_MC = sMC;
                        oXMLB.ZBXMJD_BZ = sBZ;
                        oXMLB.ZBXMJD_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oXMLB.ZBXMJD_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oXMLB.ZBXMJD_WHSJ = DateTime.Now;
                        context.ZBXMJD.Context.SubmitChanges();
                        break;
                    default:
                        break;
                }
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }


        public ActionResult XMJDPZInfo(int id, string sOperate)
        {
            DataEntityDataContext entity = new DataEntityDataContext();

            var T = entity.ZBXMJDPZ.Where(p => p.ZBXMJDPZ_XMID == id);
            foreach (var item in entity.ZBXMJD.Where(p => p.ZBXMJD_ID > 0 && !p.ZBXMJDPZ.Where(c => c.ZBXMJDPZ_XMID == id).Select(c => c.ZBXMJDPZ_JDID).Contains(p.ZBXMJD_ID)).ToList())
            {
                WoExpress.DataEntity.Models.ZBXMJDPZ oXMJDPZ = new WoExpress.DataEntity.Models.ZBXMJDPZ();
                oXMJDPZ.ZBXMJDPZ_ID = MisproUtils.GetMaxTblID("ZBXMJDPZ", "ZBXMJDPZ_ID");
                oXMJDPZ.ZBXMJDPZ_XMID = id;
                oXMJDPZ.ZBXMJDPZ_JDID = item.ZBXMJD_ID;
                oXMJDPZ.ZBXMJDPZ_SFYX = 0;
                oXMJDPZ.ZBXMJDPZ_TXDX = "";
                oXMJDPZ.ZBXMJDPZ_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                oXMJDPZ.ZBXMJDPZ_WHR = CMisproApp.GetCurrentUser().Users_Name;
                oXMJDPZ.ZBXMJDPZ_WHSJ = DateTime.Now;
                entity.ZBXMJDPZ.InsertOnSubmit(oXMJDPZ);
                entity.ZBXMJDPZ.Context.SubmitChanges();

            }
            ViewData["Operate"] = sOperate;
            if (CMisproApp.GetCurrentUser().Person != null)
            {
                ViewData["UnitName"] = CMisproApp.GetCurrentUser().Person.Unit.Unit_Name;
            }
            return View(TPageWizard.GetData<ZBXMJDPZ>(T.ToList().Count, 1, T.ToList()));
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string XMJDPZSave(string[] id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            for (int i = 0; i < id.Length; i++)
            {
                WoExpress.DataEntity.Models.ZBXMJDPZ oXMJDPZ = new WoExpress.DataEntity.Models.ZBXMJDPZ();
                JDPZ ojdpz = JsonDeserialize<JDPZ>(id[i]);
                oXMJDPZ = entity.ZBXMJDPZ.SingleOrDefault(p => p.ZBXMJDPZ_ID == ojdpz.uid);
                DelCanlander(oXMJDPZ);
                oXMJDPZ.ZBXMJDPZ_SFYX = 1;
                oXMJDPZ.ZBXMJDPZ_TXDX = "";
                if (!string.IsNullOrEmpty(ojdpz.jhsj))
                {
                    oXMJDPZ.ZBXMJDPZ_JHSJ = DateTime.Parse(ojdpz.jhsj);

                }
                if (!string.IsNullOrEmpty(ojdpz.txsj1))
                {
                    oXMJDPZ.ZBXMJDPZ_TXSJ1 = DateTime.Parse(ojdpz.txsj1);
                    if (!string.IsNullOrEmpty(ojdpz.jhsj))
                    {
                        InsertCanlander(ojdpz.ry, oXMJDPZ, ojdpz.jhsj, ojdpz.txsj1);
                    }
                }
                if (!string.IsNullOrEmpty(ojdpz.txsj2))
                {
                    oXMJDPZ.ZBXMJDPZ_TXSJ2 = DateTime.Parse(ojdpz.txsj2);
                    if (!string.IsNullOrEmpty(ojdpz.jhsj))
                    {
                        InsertCanlander(ojdpz.ry, oXMJDPZ, ojdpz.jhsj, ojdpz.txsj2);
                    }
                }
                if (!string.IsNullOrEmpty(ojdpz.txsj3))
                {
                    oXMJDPZ.ZBXMJDPZ_TXSJ3 = DateTime.Parse(ojdpz.txsj3);
                    if (!string.IsNullOrEmpty(ojdpz.jhsj))
                    {
                        InsertCanlander(ojdpz.ry, oXMJDPZ, ojdpz.jhsj, ojdpz.txsj3);
                    }
                }
                oXMJDPZ.ZBXMJDPZ_TXDX = ojdpz.ry;
                oXMJDPZ.ZBXMJDPZ_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                oXMJDPZ.ZBXMJDPZ_WHR = CMisproApp.GetCurrentUser().Users_Name;
                oXMJDPZ.ZBXMJDPZ_WHSJ = DateTime.Now;
                entity.ZBXMJDPZ.Context.SubmitChanges();
            }
            return "";
        }

        private void DelCanlander(WoExpress.DataEntity.Models.ZBXMJDPZ oXMJDPZ)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.CalendarTX.Where(p => p.CalendarTX_BDID == oXMJDPZ.ZBXMJDPZ_JDID && p.CalendarTX_FBFAID == oXMJDPZ.ZBXMJDPZ_ID);
            entity.CalendarTX.DeleteAllOnSubmit(T);
            entity.SubmitChanges();

        }

        private void InsertCanlander(string ry, WoExpress.DataEntity.Models.ZBXMJDPZ oXMJDPZ, string jhsj, string txsj1)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            if (!string.IsNullOrEmpty(ry))
            {
                string[] str = ry.Split(',');
                for (int j = 0; j < str.Length; j++)
                {

                    WoExpress.DataEntity.Models.CalendarTX oTX = null;

                    if (!string.IsNullOrEmpty(str[j]))
                    {
                        oTX = new WoExpress.DataEntity.Models.CalendarTX();
                        oTX.CalendarTX_UPhone = entity.Person.Where(p => p.Person_Name == str[j]).ToList()[0].Person_DH;
                        if (!string.IsNullOrEmpty(oTX.CalendarTX_UPhone) && DateTime.Parse(txsj1) > DateTime.Now)
                        {
                            oTX.CalendarTX_UPName = str[j];
                            oTX.CalendarTX_TXSJ = DateTime.Parse(txsj1);
                            oTX.CalendarTX_Subject = oXMJDPZ.ZBXMJD.ZBXMJD_MC + "提醒";
                            oTX.CalendarTX_location = "";
                            oTX.CalendarTX_Description = entity.ZBXMXX.SingleOrDefault(p => p.ZBXMXX_ID == oXMJDPZ.ZBXMJDPZ_XMID).ZBXMXX_XMMC + "" + oXMJDPZ.ZBXMJD.ZBXMJD_MC + "：" + jhsj + "请记得处理...";
                            oTX.CalendarTX_KSSJ = DateTime.Parse(txsj1);
                            oTX.CalendarTX_RecumingRule = CMisproApp.GetCurrentUser().Users_Name;
                            oTX.CalendarTX_SFTZ = 'N';
                            oTX.CalendarTX_FBFAID = oXMJDPZ.ZBXMJDPZ_ID;
                            oTX.CalendarTX_BDID = oXMJDPZ.ZBXMJDPZ_JDID;
                            entity.CalendarTX.InsertOnSubmit(oTX);
                            entity.CalendarTX.Context.SubmitChanges();
                        }

                    }

                }
            }
        }

        #endregion

        #region 代理小组

        public ActionResult DLXZ()
        {
            return View();
        }

        public ActionResult DLXZList(int iPageNo)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZBDLXZ.Where(p => p.ZBDLXZ_ID != 0);
            return View(TPageWizard.GetData<ZBDLXZ>(iPageSize, iPageNo, T.ToList()));
        }

        public ActionResult DLXZInfo(int id, string sOperate)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            WoExpress.DataEntity.Models.ZBDLXZ oDLXZ = new WoExpress.DataEntity.Models.ZBDLXZ();
            switch (sOperate)
            {
                case "N":
                    break;
                case "E":
                    oDLXZ = entity.ZBDLXZ.SingleOrDefault(p => p.ZBDLXZ_ID == id);
                    break;
                case "V":
                    oDLXZ = entity.ZBDLXZ.SingleOrDefault(p => p.ZBDLXZ_ID == id);
                    break;
                default:
                    break;
            }
            ViewData["Operate"] = sOperate;
            if (CMisproApp.GetCurrentUser().Person != null)
            {
                ViewData["UnitName"] = CMisproApp.GetCurrentUser().Person.Unit.Unit_Name;
            }
            return View(oDLXZ);
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string DLXZDel(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZBDLXZ.SingleOrDefault(p => p.ZBDLXZ_ID == id);
            if (entity.ZBXMXX.Where(p => p.ZBXMXX_DLXZ == id).Count() > 0)
                return "该代理小组已被使用，不允许删除！";

            try
            {
                entity.ZBDLXZ.DeleteOnSubmit(T);
                entity.SubmitChanges();
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string DLXZSave(int id, string sMC, int FZR, string FZRMC, string CYID, string CYMC, string sOperate)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                WoExpress.DataEntity.Models.ZBDLXZ oDLXZ = new WoExpress.DataEntity.Models.ZBDLXZ();
                switch (sOperate)
                {
                    case "N":
                        oDLXZ.ZBDLXZ_ID = MisproUtils.GetMaxTblID("ZBDLXZ", "ZBDLXZ_ID");
                        oDLXZ.ZBDLXZ_MC = sMC;
                        oDLXZ.ZBDLXZ_FZR = FZR;
                        oDLXZ.ZBDLXZ_FZRMC = FZRMC;
                        oDLXZ.ZBDLXZ_CYID = CYID;
                        oDLXZ.ZBDLXZ_CYMC = CYMC;
                        oDLXZ.ZBDLXZ_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oDLXZ.ZBDLXZ_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oDLXZ.ZBDLXZ_WHSJ = DateTime.Now;
                        context.ZBDLXZ.InsertOnSubmit(oDLXZ);
                        context.ZBDLXZ.Context.SubmitChanges();
                        break;
                    case "E":
                        oDLXZ = context.ZBDLXZ.SingleOrDefault(p => p.ZBDLXZ_ID == id);
                        oDLXZ.ZBDLXZ_MC = sMC;
                        oDLXZ.ZBDLXZ_FZR = FZR;
                        oDLXZ.ZBDLXZ_FZRMC = FZRMC;
                        oDLXZ.ZBDLXZ_CYID = CYID;
                        oDLXZ.ZBDLXZ_CYMC = CYMC;
                        oDLXZ.ZBDLXZ_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oDLXZ.ZBDLXZ_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oDLXZ.ZBDLXZ_WHSJ = DateTime.Now;
                        context.ZBDLXZ.Context.SubmitChanges();
                        break;
                    default:
                        break;
                }
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        #endregion

        #region 项目概况

        public ActionResult XMGK()
        {
            return View();
        }

        public ActionResult XMGKList(int iPageNo, string sKSRQS, string sJSRQE, string xmmc)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZBXMGK.Where(p => p.ZBXMGK_ID != 0);
            if (!String.IsNullOrEmpty(sKSRQS))
                T = T.Where(p => p.ZBXMGK_WHSJ >= DateTime.Parse(sKSRQS));
            if (!String.IsNullOrEmpty(sJSRQE))
                T = T.Where(p => p.ZBXMGK_WHSJ <= DateTime.Parse(sJSRQE));
            if (!String.IsNullOrEmpty(xmmc))
                T = T.Where(p => p.ZBXMGK_XMMC.IndexOf(xmmc) >= 0);
            return View(TPageWizard.GetData<ZBXMGK>(iPageSize, iPageNo, T.ToList()));
        }

        public ActionResult XMGKInfo(int id, string sOperate)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            WoExpress.DataEntity.Models.ZBXMGK oXMLB = new WoExpress.DataEntity.Models.ZBXMGK();
            switch (sOperate)
            {
                case "N":
                    break;
                case "E":
                    oXMLB = entity.ZBXMGK.SingleOrDefault(p => p.ZBXMGK_ID == id);
                    break;
                case "V":
                    oXMLB = entity.ZBXMGK.SingleOrDefault(p => p.ZBXMGK_ID == id);
                    break;
                default:
                    break;
            }
            ViewData["Operate"] = sOperate;
            ViewData["LBList"] = entity.ZBXMLB.Where(p => p.ZBXMLB_ID > 0);
            return View(oXMLB);
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string XMGKDel(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZBXMGK.SingleOrDefault(p => p.ZBXMGK_ID == id);
            try
            {
                entity.ZBXMGK.DeleteOnSubmit(T);
                entity.SubmitChanges();
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string XMGKSave(int id, string sMC, int iLB, string FS, string DWID, string FZR, string sBZ, string sOperate)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                WoExpress.DataEntity.Models.ZBXMGK oXMLB = new WoExpress.DataEntity.Models.ZBXMGK();
                switch (sOperate)
                {
                    case "N":
                        oXMLB.ZBXMGK_ID = MisproUtils.GetMaxTblID("ZBXMGK", "ZBXMGK_ID");
                        oXMLB.ZBXMGK_XMMC = sMC;
                        oXMLB.ZBXMGK_ZBFS = sBZ;
                        oXMLB.ZBXMGK_ZBFS = FS;
                        oXMLB.ZBXMGK_XMLB = iLB;
                        oXMLB.ZBXMGK_JBMS = sBZ;
                        oXMLB.ZBXMGK_JSDW = DWID;
                        oXMLB.ZBXMGK_FZR = FZR;
                        oXMLB.ZBXMGK_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oXMLB.ZBXMGK_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oXMLB.ZBXMGK_WHSJ = DateTime.Now;
                        context.ZBXMGK.InsertOnSubmit(oXMLB);
                        context.ZBXMGK.Context.SubmitChanges();
                        break;
                    case "E":
                        oXMLB = context.ZBXMGK.SingleOrDefault(p => p.ZBXMGK_ID == id);
                        oXMLB.ZBXMGK_XMMC = sMC;
                        oXMLB.ZBXMGK_ZBFS = sBZ;
                        oXMLB.ZBXMGK_XMLB = iLB;
                        oXMLB.ZBXMGK_ZBFS = FS;
                        oXMLB.ZBXMGK_JBMS = sBZ;
                        oXMLB.ZBXMGK_JSDW = DWID;
                        oXMLB.ZBXMGK_FZR = FZR;
                        context.ZBXMGK.Context.SubmitChanges();
                        break;
                    default:
                        break;
                }
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        #endregion

        #region 项目信息

        public ActionResult XMDJ(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            ViewData["LBList"] = entity.ZBXMLB.Where(p => p.ZBXMLB_ID > 0);
            ViewData["CPage"] = id;
            ViewData["AutoCompStrJSDW"] = PUBLICController.GetAllUnitHints("XT02");
            return View();
        }

        public string CanInsert()
        {
            return CMisproApp.GetCurrentUser().Person == null ? "N" : "Y";
        }

        public ActionResult XMDJList(int iPageNo, string sLb, string sKSRQS, string sJSRQE, string xmmc, string SJ, int ZBR, int ZBJ1, int ZBJ2)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            int currentid = 0;
            var T = entity.ZBXMXX.Where(p => p.ZBXMXX_ID != 0);

            if (CMisproApp.GetCurrentUser().Person != null)
            {
                currentid = CMisproApp.GetCurrentUser().Person.Person_ID;
            }
            else
            {
                T = T.Where(p => p.ZBXMXX_FZR == currentid || (p.ZBDLXZ.ZBDLXZ_CYID.Insert(p.ZBDLXZ.ZBDLXZ_CYID.Length, ",").Insert(0, ",")).Contains("," + currentid.ToString() + ","));
            }
            if (MisproUtils.GetUserOption("UZBXM") != "Y")
            {
                T = T.Where(p => p.ZBXMXX_FZR == currentid || (p.ZBDLXZ.ZBDLXZ_CYID.Insert(p.ZBDLXZ.ZBDLXZ_CYID.Length, ",").Insert(0, ",")).Contains("," + currentid.ToString() + ","));
            }
            if (!String.IsNullOrEmpty(sLb))
            {
                T = T.Where(p => p.ZBXMXX_XMLB == int.Parse(sLb));
            }
            if (!String.IsNullOrEmpty(sKSRQS))
                T = T.Where(p => p.ZBXMXX_WHSJ >= DateTime.Parse(sKSRQS));
            if (!String.IsNullOrEmpty(sJSRQE))
                T = T.Where(p => p.ZBXMXX_WHSJ <= DateTime.Parse(sJSRQE));
            if (!String.IsNullOrEmpty(xmmc))
                T = T.Where(p => p.ZBXMXX_XMMC.IndexOf(xmmc) >= 0);
            if (!String.IsNullOrEmpty(SJ))
                T = T.Where(p => p.ZBXMXX_WHSJ.Value.Year == int.Parse(SJ));
            if (ZBR != 0)
            {
                T = T.Where(p => entity.ZBXMBD.Where(c => c.ZBXMBD_ZBDW == ZBR).Select(c => c.ZBXMBD_XMID).Contains(p.ZBXMXX_ID));
            }
            if(ZBJ1!=0 || ZBJ2!=0)
            {
                T = T.Where(p => entity.ZBXMBD.Where(c => c.ZBXMBD_ZBJG >= ZBJ1 && c.ZBXMBD_ZBJG<=ZBJ2).Select(c => c.ZBXMBD_XMID).Contains(p.ZBXMXX_ID));
            }
            return View(TPageWizard.GetData<ZBXMXX>(10, iPageNo, T.OrderByDescending(p => p.ZBXMXX_WHSJ).ToList()));
        }

        public ActionResult XMDJInfo(int id, string sOperate, int jdid)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            WoExpress.DataEntity.Models.ZBXMXX oXMLB = new WoExpress.DataEntity.Models.ZBXMXX();
            switch (sOperate)
            {
                case "N":
                    oXMLB.ZBXMXX_ID = MisproUtils.GetNewID("ZBXMXX");
                    oXMLB.ZBXMXX_XMBH = DateTime.Now.ToString("yyyyMMdd") + oXMLB.ZBXMXX_ID.ToString("0000");
                    oXMLB.ZBXMXX_ZBDW = 0;
                    string sql = "delete  from ZBXMBD where ZBXMBD_XMID not in (select ZBXMXX_ID from ZBXMXX ) and ZBXMBD_WHRID='" + CMisproApp.GetCurrentUser().Users_ID + "'";
                    ClearData(sql);
                    break;
                case "E":
                    oXMLB = entity.ZBXMXX.SingleOrDefault(p => p.ZBXMXX_ID == id);
                    break;
                case "V":
                    oXMLB = entity.ZBXMXX.SingleOrDefault(p => p.ZBXMXX_ID == id);
                    break;
                default:
                    break;
            }

            int currentid = 0;
            if (CMisproApp.GetCurrentUser().Person != null)
            {
                ViewData["UnitName"] = CMisproApp.GetCurrentUser().Person.Unit.Unit_Name;
                currentid = CMisproApp.GetCurrentUser().Person.Person_ID;
            }
            ViewData["Operate"] = sOperate;
            ViewData["CPage"] = jdid;
            ViewData["LBList"] = entity.ZBXMLB.Where(p => p.ZBXMLB_ID > 0);
            ViewData["DLXZList"] = entity.ZBDLXZ.Where(p => p.ZBDLXZ_ID > 0 && p.ZBDLXZ_FZR == currentid || (p.ZBDLXZ_CYID.Insert(p.ZBDLXZ_CYID.Length, ",").Insert(0, ",")).Contains("," + currentid.ToString() + ","));
            ViewData["AutoCompStr"] = PUBLICController.GetAllPersonints();
            ViewData["AutoCompStrJSDW"] = PUBLICController.GetAllUnitHints("XT03");
            return View(oXMLB);
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string XMDJDel(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZBXMXX.SingleOrDefault(p => p.ZBXMXX_ID == id);
            var TT = entity.ZBXMBD.Where(p => p.ZBXMBD_XMID == id);
            var TTT = entity.ZBDLHT.Where(p=>p.ZBDLHT_ID.Contains(","+id.ToString()+","));
            var TTTT = entity.ZBGG.Where(p => p.ZBGG_XMID==id);
            var TTTTT = entity.ZBWJ.Where(p => p.ZBWJ_XMID == id);
            try
            {
                if (TT.ToList().Count > 0)
                {
                    return "该项目下面存在标段信息，不能删除！";
                }
                if(TTT.ToList().Count>0)
                {
                    return "该项目下面存在合同信息，不能删除！";
                }
                if (TTTT.ToList().Count>0)
                {
                    return "该项目下面存在公告信息，不能删除！";
                }
                if (TTTTT.ToList().Count > 0)
                {
                    return "该项目下面存在招标文件信息，不能删除！";
                }          
                entity.ZBXMXX.DeleteOnSubmit(T);
                entity.SubmitChanges();

                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string XMDJSave(int id, string BH, string sMC, int iLB, int iDLXZ, string FS, int DWID, int FZR, string ZTE, string sBZ, string txtGCGM, decimal txtJZMJ, int txtGYZJ, int txtSYZJ, int txtWGZJ, int txtWGSRZJ, string txtKGRQ, string txtJGRQ, string txtXMDD, string txtLXR, string txtLXFS, string SelZGSC, string sOperate)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                WoExpress.DataEntity.Models.ZBXMXX oXMLB = new WoExpress.DataEntity.Models.ZBXMXX();
                switch (sOperate)
                {
                    case "N":
                        oXMLB.ZBXMXX_ID = id;
                        oXMLB.ZBXMXX_XMBH = BH;
                        oXMLB.ZBXMXX_XMMC = sMC;
                        oXMLB.ZBXMXX_ZBFS = FS;
                        oXMLB.ZBXMXX_XMLB = iLB;
                        oXMLB.ZBXMXX_JBMS = sBZ;
                        oXMLB.ZBXMXX_JSDW = DWID;
                        oXMLB.ZBXMXX_FZR = FZR;
                        oXMLB.ZBXMXX_XMDD = txtXMDD;
                        oXMLB.ZBXMXX_TZZE = ZTE;
                        oXMLB.ZBXMXX_XMGM = txtGCGM;
                        oXMLB.ZBXMXX_JZMJ = txtJZMJ;
                        oXMLB.ZBXMXX_TZ01 = txtGYZJ;
                        oXMLB.ZBXMXX_TZ02 = txtSYZJ;
                        oXMLB.ZBXMXX_TZ03 = txtWGZJ;
                        oXMLB.ZBXMXX_TZ04 = txtWGSRZJ;
                        oXMLB.ZBXMXX_DLXZ = iDLXZ;
                        oXMLB.ZBXMXX_ZGSCFS = SelZGSC;
                        oXMLB.ZBXMXX_JSDWLXR = GetPersonID(txtLXR, DWID, txtLXFS);
                        if (!string.IsNullOrEmpty(txtKGRQ))
                        {
                            oXMLB.ZBXMXX_JHKGRQ = DateTime.Parse(txtKGRQ);
                        }
                        if (!string.IsNullOrEmpty(txtJGRQ))
                        {
                            oXMLB.ZBXMXX_JHJGRQ = DateTime.Parse(txtJGRQ);
                        }
                        oXMLB.ZBXMXX_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oXMLB.ZBXMXX_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oXMLB.ZBXMXX_WHSJ = DateTime.Now;
                        context.ZBXMXX.InsertOnSubmit(oXMLB);
                        context.ZBXMXX.Context.SubmitChanges();
                        break;
                    case "E":
                        oXMLB = context.ZBXMXX.SingleOrDefault(p => p.ZBXMXX_ID == id);
                        oXMLB.ZBXMXX_XMBH = BH;
                        oXMLB.ZBXMXX_XMMC = sMC;
                        oXMLB.ZBXMXX_ZBFS = FS;
                        oXMLB.ZBXMXX_XMLB = iLB;
                        oXMLB.ZBXMXX_JBMS = sBZ;
                        oXMLB.ZBXMXX_JSDW = DWID;
                        oXMLB.ZBXMXX_FZR = FZR;
                        oXMLB.ZBXMXX_TZZE = ZTE;
                        oXMLB.ZBXMXX_XMDD = txtXMDD;
                        oXMLB.ZBXMXX_XMGM = txtGCGM;
                        oXMLB.ZBXMXX_JZMJ = txtJZMJ;
                        oXMLB.ZBXMXX_TZ01 = txtGYZJ;
                        oXMLB.ZBXMXX_TZ02 = txtSYZJ;
                        oXMLB.ZBXMXX_TZ03 = txtWGZJ;
                        oXMLB.ZBXMXX_TZ04 = txtWGSRZJ;
                        oXMLB.ZBXMXX_DLXZ = iDLXZ;
                        oXMLB.ZBXMXX_ZGSCFS = SelZGSC;
                        oXMLB.ZBXMXX_JSDWLXR = GetPersonID(txtLXR, DWID, txtLXFS);
                        if (!string.IsNullOrEmpty(txtKGRQ))
                        {
                            oXMLB.ZBXMXX_JHKGRQ = DateTime.Parse(txtKGRQ);
                        }
                        if (!string.IsNullOrEmpty(txtJGRQ))
                        {
                            oXMLB.ZBXMXX_JHJGRQ = DateTime.Parse(txtJGRQ);
                        }
                        oXMLB.ZBXMXX_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oXMLB.ZBXMXX_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oXMLB.ZBXMXX_WHSJ = DateTime.Now;
                        context.ZBXMXX.Context.SubmitChanges();
                        break;
                    default:
                        break;
                }
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        private void UpdateLX(int id, int xmid)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            ZBLX oZTBGG = new ZBLX();
            var T = context.ZBLX.Where(p => p.ZBLX_ID == id);
            if (T.ToList().Count > 0)
            {
                oZTBGG = T.ToList()[0];
                oZTBGG.ZBLX_XMID = xmid;
                context.ZBLX.Context.SubmitChanges();
            }

        }

        public ActionResult ZBXMBDInfo(int id, string sOperate, int jdid)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            ZBXMBD oFBFAMX = new ZBXMBD();
            switch (sOperate)
            {
                case "N":
                    oFBFAMX.ZBXMBD_XMID = jdid;
                    break;
                case "E":
                    oFBFAMX = context.ZBXMBD.SingleOrDefault(p => p.ZBXMBD_ID == id && p.ZBXMBD_XMID == jdid);
                    break;
                case "V":
                    oFBFAMX = context.ZBXMBD.SingleOrDefault(p => p.ZBXMBD_ID == id && p.ZBXMBD_XMID == jdid);
                    break;
            }
            ViewData["Operate"] = sOperate;
            return View(oFBFAMX);
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZBXMBDSave(int iJDCJID, int iXH, string BDBH, string BDXZ, string FBNR, string HTGSJ, string YSJ, string ZGXJ, string JHFBSJ, string ZYLB, string FBFS, string SQSJ, string BDMC, string TZE, string JZGM, string sOperate)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                ZBXMBD oZTBFBFAMX = new ZBXMBD();
                switch (sOperate)
                {
                    case "N":
                        oZTBFBFAMX.ZBXMBD_XMID = iJDCJID;
                        oZTBFBFAMX.ZBXMBD_ID = MisproUtils.GetMaxTblID("ZBXMBD", "ZBXMBD_ID");
                        oZTBFBFAMX.ZBXMBD_BDXZ = BDXZ;
                        oZTBFBFAMX.ZBXMBD_FBNR = FBNR;
                        oZTBFBFAMX.ZBXMBD_BDMC = BDMC;
                        oZTBFBFAMX.ZBXMBD_JZGM = JZGM;
                        oZTBFBFAMX.ZBXMBD_TZE = TZE;
                        if (!String.IsNullOrEmpty(YSJ))
                        {
                            oZTBFBFAMX.ZBXMBD_YSJ = decimal.Parse(YSJ);
                        }
                        if (!String.IsNullOrEmpty(ZGXJ))
                        {
                            oZTBFBFAMX.ZBXMBD_ZGXJ = decimal.Parse(ZGXJ);
                        }
                        if (!String.IsNullOrEmpty(HTGSJ))
                        {
                            oZTBFBFAMX.ZBXMBD_HTGSJ = int.Parse(HTGSJ);
                        }
                        if (!String.IsNullOrEmpty(JHFBSJ))
                        {
                            oZTBFBFAMX.ZBXMBD_JHFBSJ = DateTime.Parse(JHFBSJ);
                        }
                        oZTBFBFAMX.ZBXMBD_ZYLB = ZYLB;
                        oZTBFBFAMX.ZBXMBD_FBFS = FBFS;
                        if (!String.IsNullOrEmpty(SQSJ))
                        {
                            oZTBFBFAMX.ZBXMBD_SQSJ = DateTime.Parse(SQSJ);
                        }
                        oZTBFBFAMX.ZBXMBD_JE = 0;
                        oZTBFBFAMX.ZBXMBD_YSJE = 0;
                        oZTBFBFAMX.ZBXMBD_ZZF = 0;
                        oZTBFBFAMX.ZBXMBD_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oZTBFBFAMX.ZBXMBD_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oZTBFBFAMX.ZBXMBD_WHSJ = DateTime.Now;
                        context.ZBXMBD.InsertOnSubmit(oZTBFBFAMX);
                        context.ZBXMBD.Context.SubmitChanges();
                        break;
                    case "E":
                        oZTBFBFAMX = context.ZBXMBD.SingleOrDefault(p => p.ZBXMBD_XMID == iJDCJID && p.ZBXMBD_ID == iXH);
                        oZTBFBFAMX.ZBXMBD_BDXZ = BDXZ;
                        oZTBFBFAMX.ZBXMBD_FBNR = FBNR;
                        oZTBFBFAMX.ZBXMBD_BDMC = BDMC;
                        oZTBFBFAMX.ZBXMBD_JZGM = JZGM;
                        oZTBFBFAMX.ZBXMBD_TZE = TZE;
                        if (!String.IsNullOrEmpty(YSJ))
                        {
                            oZTBFBFAMX.ZBXMBD_YSJ = decimal.Parse(YSJ);
                        }
                        if (!String.IsNullOrEmpty(ZGXJ))
                        {
                            oZTBFBFAMX.ZBXMBD_ZGXJ = decimal.Parse(ZGXJ);
                        }
                        if (!String.IsNullOrEmpty(HTGSJ))
                        {
                            oZTBFBFAMX.ZBXMBD_HTGSJ = int.Parse(HTGSJ);
                        }
                        if (!String.IsNullOrEmpty(JHFBSJ))
                        {
                            oZTBFBFAMX.ZBXMBD_JHFBSJ = DateTime.Parse(JHFBSJ);
                        }
                        oZTBFBFAMX.ZBXMBD_ZYLB = ZYLB;
                        oZTBFBFAMX.ZBXMBD_FBFS = FBFS;
                        if (!String.IsNullOrEmpty(SQSJ))
                        {
                            oZTBFBFAMX.ZBXMBD_SQSJ = DateTime.Parse(SQSJ);
                        }
                        oZTBFBFAMX.ZBXMBD_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oZTBFBFAMX.ZBXMBD_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oZTBFBFAMX.ZBXMBD_WHSJ = DateTime.Now;
                        context.ZBXMBD.Context.SubmitChanges();
                        break;
                    default:
                        break;
                }
            }
            catch (Exception mes)
            {
                return mes.Message;
            }
            return "";
        }

        public ActionResult ZBXMBDList(int iPageNo, int iJDCJID)
        {
            int iPageSize1 = 4;
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.ZBXMBD.Where(p => p.ZBXMBD_XMID == iJDCJID);
            return View(TPageWizard.GetData<ZBXMBD>(iPageSize1, iPageNo, T.ToList()));
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZBXMBDDel(int iXH, int iJDCJID)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                ZBXMBD oJDCJMX = new ZBXMBD();
                oJDCJMX = context.ZBXMBD.SingleOrDefault(p => p.ZBXMBD_XMID == iJDCJID && p.ZBXMBD_ID == iXH);
                context.ZBXMBD.DeleteOnSubmit(oJDCJMX);
                context.ZBXMBD.Context.SubmitChanges();
            }
            catch (Exception mes)
            {
                return mes.Message;
            }
            return "";
        }

        private int GetPersonID(string name, int unitID, string DH)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                Person obj = new Person();
                var T = context.Person.Where(p => p.Person_Name == name && p.Person_UnitID == unitID);
                if (T.ToList().Count > 0)
                {
                    return T.ToList()[0].Person_ID;
                }
                else
                {
                    obj.Person_ID = MisproUtils.GetMaxTblID("Person", "Person_ID");
                    obj.Person_Name = name;
                    obj.Person_UnitID = unitID;
                    obj.Person_DepartmentID = 0;
                    obj.Person_ZT = "ZG";
                    obj.Person_SG = "";
                    obj.Person_DH = DH;
                    obj.Person_CreaterID = CMisproApp.GetCurrentUser().Users_ID;
                    obj.Person_CreaterName = CMisproApp.GetCurrentUser().Users_Name;
                    obj.Person_CreateTime = DateTime.Now;
                    obj.Person_RYBM = "";
                    obj.Person_DelFlag = 0;
                    context.Person.InsertOnSubmit(obj);
                    context.Person.Context.SubmitChanges();
                    return obj.Person_ID;
                }

            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        /// <summary>
        ///清除无用数据 
        /// </summary>
        public void ClearData(string sql)
        {
            DBHelper db = new DBHelper();
            try
            {
                db.ExecuteNonQuery(CommandType.Text, sql);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                db = null;
            }
        }
        #endregion

        #region 招标代理合同

        public ActionResult HTDL()
        {
            return View();
        }

        public ActionResult HTDLList(int iPageNo, string sHTMC, string sSFFS, string sFWLX, string iSFYQ)
        {
            try
            {
                using (DataEntityDataContext context = new DataEntityDataContext())
                {
                    var T = context.ZBDLHT.Where(p => p.ZBDLHT_ID != "");
                    if (!String.IsNullOrEmpty(sHTMC))
                        T = T.Where(p => p.ZBDLHT_HTMC.Contains(sHTMC));
                    if (!String.IsNullOrEmpty(sSFFS))
                        T = T.Where(p => p.ZBDLHT_SFFS == sSFFS);
                    if (!String.IsNullOrEmpty(sFWLX))
                        T = T.Where(p => p.ZBDLHT_FWLX == sFWLX);
                    if (!String.IsNullOrEmpty(iSFYQ))
                        T = T.Where(p => p.ZBDLHT_SFYQ == int.Parse(iSFYQ));
                    return View(TPageWizard.GetData<ZBDLHT>(iPageSize, iPageNo, T.ToList()));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ActionResult HTDLInfo(int id, string sOperate)
        {
            try
            {
                using (DataEntityDataContext context = new DataEntityDataContext())
                {
                    ZBDLHT oZBDLHT = new ZBDLHT();
                    switch (sOperate)
                    {
                        case "N":
                            oZBDLHT.ZBDLHT_PID = MisproUtils.GetMaxTblID("ZBDLHT", "ZBDLHT_PID");
                            oZBDLHT.ZBDLHT_HTBH = DateTime.Now.ToString("yyyyMMdd") + oZBDLHT.ZBDLHT_PID.ToString("0000"); ;
                            break;
                        case "E":
                            oZBDLHT = context.ZBDLHT.SingleOrDefault(p => p.ZBDLHT_PID == id);
                            break;
                        case "V":
                            oZBDLHT = context.ZBDLHT.SingleOrDefault(p => p.ZBDLHT_PID == id);
                            break;
                    }
                    ViewData["sOperate"] = sOperate;
                    return View(oZBDLHT);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string HTInfo(int id, int bid)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                ZBXMBD oZTBGG = new ZBXMBD();
                oZTBGG = context.ZBXMBD.SingleOrDefault(p => p.ZBXMBD_ID == bid && p.ZBXMBD_XMID == id);
                if (oZTBGG != null)
                {
                    string res = oZTBGG.ZBXMBD_SFFS + "," + oZTBGG.ZBXMBD_FWLX + "," + oZTBGG.ZBXMBD_BL + "," + oZTBGG.ZBXMBD_YSJE + "," + oZTBGG.ZBXMBD_JE + "," + oZTBGG.ZBXMBD_ZZF;
                    return res;
                }
                else
                {
                    return "";
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string DLHTSave(int id, string sHTMC, string sHTBH, int nowRow, string sHTID, int XMID, string sSFFS, string sFWLX, decimal sYSJE, decimal sFL, decimal sBGJE, decimal sSSJE, int sQDHT, decimal YGSF, string DLHTQDSJ, string HTDQSJ, string sOperate)
        {
            try
            {
                using (DataEntityDataContext context = new DataEntityDataContext())
                {
                    ZBXMBD oZBXMBD = context.ZBXMBD.SingleOrDefault(p => p.ZBXMBD_ID == nowRow);
                    oZBXMBD.ZBXMBD_BL = sFL;
                    oZBXMBD.ZBXMBD_FWLX = sFWLX;
                    oZBXMBD.ZBXMBD_SFFS = sSFFS;
                    oZBXMBD.ZBXMBD_ZZF = sSSJE;
                    oZBXMBD.ZBXMBD_YSJE = sYSJE;
                    oZBXMBD.ZBXMBD_JE = sBGJE;
                    context.SubmitChanges();
                    ZBDLHT oZBDLHT = new ZBDLHT();
                    switch (sOperate)
                    {
                        case "N":
                            //if (context.ZBDLHT.SingleOrDefault(p => p.ZBDLHT_ID == sHTID) == null)
                            //{
                            oZBDLHT.ZBDLHT_PID = id;
                            oZBDLHT.ZBDLHT_ID = sHTID;
                            oZBDLHT.ZBDLHT_BGJE = context.ZBXMBD.Where(p => p.ZBXMBD_XMID == XMID).Sum(p => p.ZBXMBD_JE);
                            oZBDLHT.ZBDLHT_FL = sFL;
                            oZBDLHT.ZBDLHT_FWLX = sFWLX;
                            oZBDLHT.ZBDLHT_YGSF = YGSF;
                            if (!string.IsNullOrEmpty(DLHTQDSJ))
                            {
                                oZBDLHT.ZBDLHT_DLHTQDSJ = DateTime.Parse(DLHTQDSJ);
                            }
                            if (!string.IsNullOrEmpty(HTDQSJ))
                            {
                                oZBDLHT.ZBDLHT_HTDQSJ = DateTime.Parse(HTDQSJ);
                            }
                            oZBDLHT.ZBDLHT_HTBH = sHTBH;
                            oZBDLHT.ZBDLHT_HTMC = sHTMC;
                            oZBDLHT.ZBDLHT_SFFS = sSFFS;
                            oZBDLHT.ZBDLHT_SFYQ = sQDHT;
                            oZBDLHT.ZBDLHT_SJJE = context.ZBXMBD.Where(p => p.ZBXMBD_XMID == XMID).Sum(p => p.ZBXMBD_ZZF);
                            oZBDLHT.ZBDLHT_YSJE = context.ZBXMBD.Where(p => p.ZBXMBD_XMID == XMID).Sum(p => p.ZBXMBD_YSJE);
                            oZBDLHT.ZBDLHT_WHR = CMisproApp.GetCurrentUser().Users_Name;
                            oZBDLHT.ZBDLHT_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                            oZBDLHT.ZBDLHT_WHSJ = DateTime.Now;
                            Workflow wf = new Workflow();
                            wf.Wfid = "ZBDLHT";
                            wf.Wfinst = wf.Get_WFInst(wf.Wfid);
                            wf.CurrentUser = CMisproApp.GetCurrentUser().Users_ID;
                            wf.CurrentWPID = "0000";
                            wf.NextWPID = wf.Get_NextWPID();
                            oZBDLHT.ZBDLHT_WFID = wf.Wfid;
                            oZBDLHT.ZBDLHT_WFInst = wf.Wfinst;
                            oZBDLHT.ZBDLHT_WPID = wf.NextWPID;
                            oZBDLHT.ZBDLHT_Awaiter = "," + CMisproApp.GetCurrentUser().Users_ID + ",";
                            oZBDLHT.ZBDLHT_Handler = "";
                            context.ZBDLHT.InsertOnSubmit(oZBDLHT);
                            context.SubmitChanges();
                            wf.WFSave();
                            break;
                        case "E":
                            oZBDLHT = context.ZBDLHT.SingleOrDefault(p => p.ZBDLHT_PID == id);
                            oZBDLHT.ZBDLHT_ID = sHTID;
                            oZBDLHT.ZBDLHT_BGJE = context.ZBXMBD.Where(p => p.ZBXMBD_XMID == XMID).Sum(p => p.ZBXMBD_JE);
                            oZBDLHT.ZBDLHT_FL = sFL;
                            oZBDLHT.ZBDLHT_FWLX = sFWLX;
                            oZBDLHT.ZBDLHT_YGSF = YGSF;
                            if (!string.IsNullOrEmpty(DLHTQDSJ))
                            {
                                oZBDLHT.ZBDLHT_DLHTQDSJ = DateTime.Parse(DLHTQDSJ);
                            }
                            if (!string.IsNullOrEmpty(HTDQSJ))
                            {
                                oZBDLHT.ZBDLHT_HTDQSJ = DateTime.Parse(HTDQSJ);
                            }
                            oZBDLHT.ZBDLHT_HTBH = sHTBH;
                            oZBDLHT.ZBDLHT_HTMC = sHTMC;
                            oZBDLHT.ZBDLHT_SFFS = sSFFS;
                            oZBDLHT.ZBDLHT_SFYQ = sQDHT;
                            oZBDLHT.ZBDLHT_SJJE = context.ZBXMBD.Where(p => p.ZBXMBD_XMID == XMID).Sum(p => p.ZBXMBD_ZZF);
                            oZBDLHT.ZBDLHT_YSJE = context.ZBXMBD.Where(p => p.ZBXMBD_XMID == XMID).Sum(p => p.ZBXMBD_YSJE);
                            oZBDLHT.ZBDLHT_WHR = CMisproApp.GetCurrentUser().Users_Name;
                            oZBDLHT.ZBDLHT_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                            oZBDLHT.ZBDLHT_WHSJ = DateTime.Now;
                            context.SubmitChanges();
                            break;
                        default:
                            break;
                    }
                    return "OK";
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ActionResult BDXXList(string id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            string[] str = id.Split(',');
            var T = (from t in context.ZBXMBD.Skip(0) where str.Contains(t.ZBXMBD_XMID.ToString()) select t).ToList();
            return View(TPageWizard.GetData<ZBXMBD>(T.Count, 1, T));
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string DLHTDel(string id)
        {
            try
            {
                using (DataEntityDataContext context = new DataEntityDataContext())
                {
                    ZBDLHT oZBDLHT = new ZBDLHT();
                    oZBDLHT = context.ZBDLHT.SingleOrDefault(p => p.ZBDLHT_PID ==int.Parse(id));
                    context.ZBDLHT.DeleteOnSubmit(oZBDLHT);
                    context.SubmitChanges();
                    return "OK";
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ActionResult ZWNG(string id, string sOperate)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            ZBDLHT oGWFW = context.ZBDLHT.SingleOrDefault(p => p.ZBDLHT_ID == id);
            string url = "http://" + Request.ServerVariables["HTTP_HOST"].ToString() + Request.ServerVariables["PATH_INFO"].ToString();
            int i = url.LastIndexOf("/");
            url = url.Substring(0, i);
            url = url.Substring(0, url.IndexOf('/', 7));
            ViewData["URL"] = url;
            if (sOperate == "true")
            {
                ViewData["Operate"] = "E";
            }
            else
            {
                ViewData["Operate"] = "V";
            }
            ViewData["GetLog"] = GetLog((double)oGWFW.ZBDLHT_WFInst);
            return View(oGWFW);
        }

        public string GetLog(double inst)
        {
            DBHelper oDBHelper = null;
            string result = "";
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                oDBHelper = new DBHelper();
                using (IDataReader dr = oDBHelper.ExecuteReader(CommandType.Text,
                        "select WFLHandler, Users_Name,WFLState, WFLLogTime, WFLMemo from WorkflowLog  left join Users on Users_ID=WFLHandler where WFLWFID='ZBDLHT' and WFLWFInst=" + inst + ""))
                {
                    while (dr.Read())
                    {
                        List<Users> alist = context.Users.Where(p => p.Users_Name == dr["Users_Name"].ToString()).ToList();
                        string name = alist[0].Person.Person_Name;
                        if (!String.IsNullOrEmpty(dr["WFLMemo"].ToString().Trim()))
                        {
                            if (dr["WFLState"].ToString().Equals("S"))
                            {
                                result += "<div>" + name + " 于 " + dr["WFLLogTime"].ToString() + "&nbsp作出审批处理：<span style='color:red;'>" + dr["WFLMemo"].ToString() + "</span></div>";
                            }
                            else if (dr["WFLState"].ToString().Equals("R"))
                            {
                                result += "<div>" + name + " 于 " + dr["WFLLogTime"].ToString() + "&nbsp作出退回处理：<span style='color:red;'>" + dr["WFLMemo"].ToString() + "</span></div>";
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDBHelper = null;
            }
            return result;
        }

        public ActionResult ShowDLXM()
        {
            return View();
        }

        public ActionResult ShowDLXMList(int iPageNo, string sXMMC)
        {
            try
            {
                using (DataEntityDataContext context = new DataEntityDataContext())
                {
                    var T = context.ZBXMXX.Where(p => p.ZBXMXX_ID > 0);
                    if (!String.IsNullOrEmpty(sXMMC.Trim()))
                        T = T.Where(p => p.ZBXMXX_XMMC.Contains(sXMMC.Trim()));
                    T = T.OrderByDescending(p => p.ZBXMXX_WHSJ);
                    return View(TPageWizard.GetData<ZBXMXX>(iPageSize, iPageNo, T.ToList()));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ActionResult ShowZBDLXMList(string sXMID)
        {
            try
            {
                using (DataEntityDataContext context = new DataEntityDataContext())
                {
                    var T = context.ZBXMXX.Where(p => sXMID.IndexOf(p.ZBXMXX_ID.ToString().Insert(p.ZBXMXX_ID.ToString().Length, ",").Insert(0, ",")) >= 0);
                    return View(T.ToList());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetXMID(int iHTID)
        {
            try
            {
                using (DataEntityDataContext context = new DataEntityDataContext())
                {
                    var sXMID = ",";
                    var T = context.ZBDLHTMX.Where(p => p.ZBDLHTMX_ID == iHTID);
                    foreach (var t in T)
                    {
                        sXMID += t.ZBDLHTMX_XMID + ",";
                    }
                    return sXMID;
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }
        #endregion

        #region 收款登记

        public ActionResult SKDJTJ()
        {
            return View();
        }

        public ActionResult SKDJ(int id, string sOperate)
        {
            ViewData["id"] = id;
            ViewData["LB"] = sOperate;
            return View();
        }

        public ActionResult SKDJList(int iPageNo, int id, string lB, string sRQS, string sRQE)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.ZBSKDJ.Where(p => p.ZBSKDJ_XMID == id && p.ZBSKDJ_LB == lB);
            if (!String.IsNullOrEmpty(sRQS.Trim()))
                T = T.Where(p => p.ZBSKDJ_SKRQ >= DateTime.Parse(sRQS));
            if (!String.IsNullOrEmpty(sRQE.Trim()))
                T = T.Where(p => p.ZBSKDJ_SKRQ < DateTime.Parse(sRQE).AddDays(1));
            T = T.OrderByDescending(p => p.ZBSKDJ_SKRQ);
            return View(TPageWizard.GetData<ZBSKDJ>(13, iPageNo, T.ToList()));
        }

        public ActionResult SKDJInfo(int id, string sOperate)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            ZBSKDJ oZBSKDJ = new ZBSKDJ();
            switch (sOperate)
            {
                case "N":
                    oZBSKDJ.ZBSKDJ_WHR = CMisproApp.GetCurrentUser().Users_Name;
                    oZBSKDJ.ZBSKDJ_WHSJ = DateTime.Now;
                    oZBSKDJ.ZBSKDJ_SKRQ = DateTime.Now;
                    break;
                case "E":
                    oZBSKDJ = context.ZBSKDJ.SingleOrDefault(p => p.ZBSKDJ_ID == id);
                    break;
                case "V":
                    oZBSKDJ = context.ZBSKDJ.SingleOrDefault(p => p.ZBSKDJ_ID == id);
                    break;
                default:
                    break;

            }
            ViewData["Operate"] = sOperate;
            ViewData["AutoCompStr"] = PUBLICController.GetAllPersonints();
            ViewData["AutoCompStrJSDW"] = PUBLICController.GetAllUnit();
            return View(oZBSKDJ);
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string SKDJSave(int id, int iXMID, string LB, string sSKR, string sSKRQ, string sSKJE, string sZFF, int YT, string THRQ, string sOperate)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            ZBSKDJ oZBSKDJ = new ZBSKDJ();
            ZBXMBD oZBXMBD = new ZBXMBD();
            ZBXMXX oZBXMXX = new ZBXMXX();
            try
            {
                switch (sOperate)
                {
                    case "N":
                        oZBSKDJ.ZBSKDJ_ID = MisproUtils.GetMaxTblID("ZBSKDJ", "ZBSKDJ_ID");
                        oZBSKDJ.ZBSKDJ_XMID = iXMID;
                        oZBSKDJ.ZBSKDJ_SKR = sSKR;
                        if (sSKRQ != "")
                            oZBSKDJ.ZBSKDJ_SKRQ = DateTime.Parse(sSKRQ);
                        oZBSKDJ.ZBSKDJ_LB = LB;
                        oZBSKDJ.ZBSKDJ_SKJE = decimal.Parse(sSKJE);
                        oZBSKDJ.ZBSKDJ_ZFF = sZFF;
                        oZBSKDJ.ZBSKDJ_BZJZT = YT;
                        if (!string.IsNullOrEmpty(THRQ))
                            oZBSKDJ.ZBSKDJ_THSJ = DateTime.Parse(THRQ);
                        oZBSKDJ.ZBSKDJ_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oZBSKDJ.ZBSKDJ_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oZBSKDJ.ZBSKDJ_WHSJ = DateTime.Now;
                        if (LB == "DLF")
                        {
                            oZBXMBD = context.ZBXMBD.SingleOrDefault(p => p.ZBXMBD_ID == iXMID);
                            if (oZBXMBD.ZBXMBD_ZFJE != null)
                                oZBXMBD.ZBXMBD_ZFJE += decimal.Parse(sSKJE);
                            else oZBXMBD.ZBXMBD_ZFJE = decimal.Parse(sSKJE);
                        }
                        context.ZBSKDJ.InsertOnSubmit(oZBSKDJ);
                        context.SubmitChanges();
                        context.ZBXMBD.Context.SubmitChanges();
                        break;
                    case "E":
                        oZBSKDJ = context.ZBSKDJ.SingleOrDefault(p => p.ZBSKDJ_ID == id);
                        if (LB == "DLF")
                        {
                            if (iXMID != oZBSKDJ.ZBSKDJ_XMID)
                            {
                                ZBXMBD oZBXMXX1 = new ZBXMBD();
                                oZBXMXX1 = context.ZBXMBD.SingleOrDefault(p => p.ZBXMBD_ID == oZBSKDJ.ZBSKDJ_XMID);
                                oZBXMXX1.ZBXMBD_ZFJE -= oZBSKDJ.ZBSKDJ_SKJE;
                                oZBXMBD = context.ZBXMBD.SingleOrDefault(p => p.ZBXMBD_ID == iXMID);
                                if (oZBXMBD.ZBXMBD_ZFJE != null)
                                    oZBXMBD.ZBXMBD_ZFJE += decimal.Parse(sSKJE);
                                else oZBXMBD.ZBXMBD_ZFJE = decimal.Parse(sSKJE);
                            }
                            else
                            {
                                oZBXMBD = context.ZBXMBD.SingleOrDefault(p => p.ZBXMBD_ID == iXMID);
                                if (oZBXMBD.ZBXMBD_ZFJE == null)
                                {
                                    oZBXMBD.ZBXMBD_ZFJE = decimal.Parse(sSKJE);
                                }
                                else
                                {
                                    oZBXMBD.ZBXMBD_ZFJE = oZBXMBD.ZBXMBD_ZFJE - oZBSKDJ.ZBSKDJ_SKJE + decimal.Parse(sSKJE);
                                }
                            }
                        }
                        oZBSKDJ.ZBSKDJ_XMID = iXMID;
                        oZBSKDJ.ZBSKDJ_SKR = sSKR;
                        oZBSKDJ.ZBSKDJ_LB = LB;
                        if (sSKRQ != "")
                            oZBSKDJ.ZBSKDJ_SKRQ = DateTime.Parse(sSKRQ);
                        oZBSKDJ.ZBSKDJ_BZJZT = YT;
                        if (!string.IsNullOrEmpty(THRQ))
                            oZBSKDJ.ZBSKDJ_THSJ = DateTime.Parse(THRQ);
                        oZBSKDJ.ZBSKDJ_SKJE = decimal.Parse(sSKJE);
                        oZBSKDJ.ZBSKDJ_ZFF = sZFF;
                        oZBSKDJ.ZBSKDJ_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oZBSKDJ.ZBSKDJ_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oZBSKDJ.ZBSKDJ_WHSJ = DateTime.Now;
                        context.ZBXMBD.Context.SubmitChanges();
                        context.SubmitChanges();
                        break;
                    default:
                        break;
                }
            }
            catch (Exception mes)
            {
                return mes.Message;
            }
            return "";
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string SKDJDel(int id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            ZBSKDJ oZBSKDJ = new ZBSKDJ();
            ZBXMXX oZBXMXX = new ZBXMXX();
            try
            {
                oZBSKDJ = context.ZBSKDJ.SingleOrDefault(p => p.ZBSKDJ_ID == id);
                //oZBXMXX = context.ZBXMXX.SingleOrDefault(p => p.ZBXMXX_ID == oZBSKDJ.ZBSKDJ_XMID);
                //oZBXMXX.ZBXMXX_ZFJE -= oZBSKDJ.ZBSKDJ_SKJE;
                context.ZBSKDJ.DeleteOnSubmit(oZBSKDJ);
                context.SubmitChanges();
            }
            catch (Exception mes)
            {
                return mes.Message;
            }
            return "";
        }

        public ActionResult ShowSingleXM()
        {
            return View();
        }

        public ActionResult ShowSingleXMList(int iPageNo, string sXMMC)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.ZBXMXX.Where(p => p.ZBXMXX_ID > 0);
            if (!String.IsNullOrEmpty(sXMMC.Trim()))
                T = T.Where(p => p.ZBXMXX_XMMC.Contains(sXMMC.Trim()));
            return View(TPageWizard.GetData<ZBXMXX>(iPageSize, iPageNo, T.ToList()));
        }
        #endregion

        #region 公共函数
        public static string GetUnit(int id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.Unit.Where(p => p.Unit_ID == id);
            string unitName = "";
            if (T.ToList().Count > 0)
            {
                unitName = T.ToList()[0].Unit_Name;
            }
            return unitName;
        }

        public static string GetUnitXZ(int id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.Unit.Where(p => p.Unit_ID == id);
            string unitName = "";
            if (T.ToList().Count > 0)
            {
                unitName = T.ToList()[0].Unit_DWXZ;
            }
            return unitName;
        }

        public string GetLXXXInfo(int id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.ZBLX.SingleOrDefault(p => p.ZBLX_ID == id);
            string sJson = "{";
            sJson += "\"ZBLX_ID\":\"" + T.ZBLX_ID.ToString() + "\",";
            sJson += "\"ZBLX_LXWH\":\"" + (String.IsNullOrEmpty(T.ZBLX_LXWH) ? "" : T.ZBLX_LXWH.ToString()) + "\",";
            sJson += "\"ZBLX_LXBM\":\"" + (String.IsNullOrEmpty(T.ZBLX_LXBM) ? "" : T.ZBLX_LXBM.ToString()) + "\",";
            sJson += "\"ZBLX_LXBT\":\"" + (String.IsNullOrEmpty(T.ZBLX_LXBT) ? "" : T.ZBLX_LXBT.ToString()) + "\",";
            sJson += "\"ZBLX_LXSJ\":\"" + (String.IsNullOrEmpty(T.ZBLX_LXSJ.ToString()) ? "" : T.ZBLX_LXSJ.ToString()) + "\",";
            sJson += "\"ZBLX_XMDD\":\"" + (String.IsNullOrEmpty(T.ZBLX_XMDD) ? "" : T.ZBLX_XMDD.ToString()) + "\",";
            sJson += "\"ZBLX_ZTZE\":\"" + (String.IsNullOrEmpty(T.ZBLX_ZTZE.ToString()) ? "" : T.ZBLX_ZTZE.ToString()) + "\"";
            sJson += "}";
            return sJson;
        }

        public static string GetPerson(int id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.Person.Where(p => p.Person_ID == id);
            string PersonName = "";
            if (T.ToList().Count > 0)
            {
                PersonName = T.ToList()[0].Person_Name;
            }
            return PersonName;
        }

        public static string GetPersonDH(int id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.Person.Where(p => p.Person_ID == id);
            string PersonNameDH = "";
            if (T.ToList().Count > 0)
            {
                PersonNameDH = T.ToList()[0].Person_DH;
            }
            return PersonNameDH;
        }

        public string GetPersonDHM(int id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.Person.Where(p => p.Person_ID == id);
            string PersonNameDH = "";
            if (T.ToList().Count > 0)
            {
                PersonNameDH = T.ToList()[0].Person_DH;
            }
            return PersonNameDH;
        }

        public decimal GetYSJE(string sFWLX, decimal txtZBJ)
        {
            try
            {
                return Common.GetAgencyCost(sFWLX, txtZBJ);
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        public ActionResult ShowDWXX(string id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.UnitType.OrderBy(p => p.UnitType_ID);
            var sOption = "";
            foreach (var t in T)
            {
                if (t.UnitType_Name.Contains(id))
                    sOption += "<option selected value=\"" + t.UnitType_ID + "\">" + t.UnitType_Name + "</option>";
                else
                    sOption += "<option value=\"" + t.UnitType_ID + "\">" + t.UnitType_Name + "</option>";
            }
            ViewData["Option"] = sOption;
            return View();
        }

        public ActionResult ShowDWXXList(int iPageNo, string sUnitType, string sUnitName)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.Unit.Where(p => p.Unit_Type == sUnitType);
            if (!String.IsNullOrEmpty(sUnitName))
                T = T.Where(p => p.Unit_Name.Contains(sUnitName));
            T = T.OrderBy(p => p.Unit_Name);
            return View(TPageWizard.GetData<Unit>(15, iPageNo, T.ToList()));
        }

        public ActionResult ShowLXXX()
        {
            return View();
        }

        public ActionResult ShowLXXXList(int iPageNo, string sUnitType, string sUnitName)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.ZBLX.Where(p => p.ZBLX_ID != 0);
            if (!String.IsNullOrEmpty(sUnitName))
                T = T.Where(p => p.ZBLX_LXWH.Contains(sUnitName));
            if (!String.IsNullOrEmpty(sUnitType))
                T = T.Where(p => p.ZBLX_LXBM.Contains(sUnitType));
            T = T.OrderByDescending(p => p.ZBLX_WHSJ);
            return View(TPageWizard.GetData<ZBLX>(15, iPageNo, T.ToList()));
        }

        public ActionResult ShowRYXX(int id)
        {
            ViewData["id"] = id;
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.Department.Where(p => p.Department_UnitID == id);
            List<SelectListItem> Mylist = new List<SelectListItem>();
            List<Department> departlist = T.ToList();
            Mylist.Add(new SelectListItem { Text = CMisproApp.GetCurrentUser().Person.Department.Department_Name, Value = CMisproApp.GetCurrentUser().Person.Person_DepartmentID.ToString() });
            for (int i = 0; i < departlist.Count; i++)
            {
                if (!departlist[i].Department_Name.Equals(CMisproApp.GetCurrentUser().Person.Department.Department_Name))
                {
                    Mylist.Add(new SelectListItem { Text = departlist[i].Department_Name, Value = departlist[i].Department_ID.ToString() });
                }

            }
            ViewData["Departlist"] = Mylist;
            return View();
        }

        public ActionResult ShowRYXXList(int iPageNo, int iUnitID, int iDepart, string MC)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.Person.Where(p => p.Person_UnitID == iUnitID);
            if (iDepart != 0)
            {
                T = T.Where(p => p.Person_DepartmentID == iDepart);
            }
            if (!string.IsNullOrEmpty(MC))
            {
                T = T.Where(p => p.Person_Name.Contains(MC));
            }
            return View(TPageWizard.GetData<Person>(6, iPageNo, T.ToList()));
        }

        public string GetFZRInfo(int id)
        {
            string sJson = "";
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.ZBDLXZ.SingleOrDefault(p => p.ZBDLXZ_ID == id);
            sJson += "{";
            sJson += "\"id\":\" " + T.ZBDLXZ_FZR + " \","
                                  + "\"mc\":\"" + T.ZBDLXZ_FZRMC + "\""
                              + "}";
            return sJson;
        }

        public static T JsonDeserialize<T>(string jsonString)
        {
            DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(T));

            MemoryStream ms = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(jsonString));

            T obj = (T)ser.ReadObject(ms);

            return obj;

        }

        #endregion

        #region 招标代理服务收费标准

        public decimal GetRate(decimal dZBJE, string sFWLX)
        {
            using (DataEntityDataContext context = new DataEntityDataContext())
            {
                var T = context.ZBSFBZ.Where(p => p.ZBSFBZ_FWLX == sFWLX);
                if (dZBJE > 100000)
                    return T.SingleOrDefault(p => p.ZBSFBZ_ZBJEXX == 100000).ZBSFBZ_FL.Value;
                else
                    return T.SingleOrDefault(p => p.ZBSFBZ_ZBJESX >= dZBJE && p.ZBSFBZ_ZBJEXX < dZBJE).ZBSFBZ_FL.Value;
            }
        }

        public decimal GetZBJEXX(decimal dZBJE, string sFWLX)
        {
            using (DataEntityDataContext context = new DataEntityDataContext())
            {
                var T = context.ZBSFBZ.Where(p => p.ZBSFBZ_FWLX == sFWLX);
                if (dZBJE > 100000)
                    return 100000;
                else
                    return T.SingleOrDefault(p => p.ZBSFBZ_ZBJEXX < dZBJE && p.ZBSFBZ_ZBJESX >= dZBJE).ZBSFBZ_ZBJEXX.Value;
            }
        }

        public decimal GetZBDLFWF(decimal dZBJE, string sFWLX)
        {
            using (DataEntityDataContext context = new DataEntityDataContext())
            {
                if (dZBJE <= 100)
                    return dZBJE * GetRate(dZBJE, sFWLX) / 100;
                else
                {
                    return (dZBJE - GetZBJEXX(dZBJE, sFWLX)) * GetRate(dZBJE, sFWLX) / 100 + GetZBDLFWF(GetZBJEXX(dZBJE, sFWLX), sFWLX);
                }
            }
        }
        #endregion

        #region 业务管理页面

        public ActionResult YWGL(int id, string sOperate)
        {
            ViewData["id"] = sOperate;
            ViewData["GCID"] = id;
            return View();
        }

        #endregion

        public ActionResult ShowZBFJ(int id, int sOperate, string jdid)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZBWJGL.Where(p => p.ZBWJGL_WJLB == jdid && (p.ZBWJGL_XMID == id)).ToList();
            return View(T.ToList());
        }
    }

    public class JDPZ
    {
        public int uid { get; set; }
        public string jhsj { get; set; }
        public string txsj1 { get; set; }
        public string txsj2 { get; set; }
        public string txsj3 { get; set; }
        public string ry { get; set; }
    }
}
