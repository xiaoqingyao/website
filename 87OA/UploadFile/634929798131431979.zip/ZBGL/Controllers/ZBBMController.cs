﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WoExpress.ZBGL.Controllers
{
    public class ZBBMController : Controller
    {
        //
        // GET: /ZBBM/

        public ActionResult ZBBM(int id)
        {
            ViewData["GCID"] = id;
            return View();
        }

    }
}
