﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WoExpress.DataEntity.Models;
using WoExpress.Core.Page;
using WoExpress.Core.Utility;
using WoExpress.Core.Data;
using System.Data;

namespace WoExpress.ZBGL.Controllers
{
    public class ZBGGController : Controller
    {
        const int iPageSize = 10;

        #region 招标公告

        public ActionResult ZBGG(int id)
        {
            ViewData["GCID"] = id;
            return View();
        }

        public ActionResult ZBGGList(int iPageNo, int id, string sdate, string edate)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.ZBGG.Where(p => p.ZBGG_ID != 0 && p.ZBGG_WHRID == CMisproApp.GetCurrentUser().Users_ID && p.ZBGG_XMID == id);
            if (!String.IsNullOrEmpty(sdate))
                T = T.Where(p => p.ZBGG_WHSJ >= DateTime.Parse(sdate));
            if (!String.IsNullOrEmpty(edate))
                T = T.Where(p => p.ZBGG_WHSJ <= DateTime.Parse(edate));
            T = T.OrderByDescending(p => p.ZBGG_WHSJ);
            return View(TPageWizard.GetData<ZBGG>(iPageSize, iPageNo, T.ToList()));
        }

        public ActionResult ZBGGInfo(int id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            ZBGG oZTBGG = new ZBGG();
            var T = context.ZBGG.Where(p => p.ZBGG_XMID == id);
            if (T.ToList().Count == 0)
            {
                oZTBGG.ZBGG_GRPID = MisproUtils.GetNewID("ZBGG");
                oZTBGG.ZBGG_ID = 0;
                string sql = "delete from ZBGGFJ where ZBGGFJ_GRPID not in(select ZBGGFJ_GRPID "
                         + "from ZBGG) "
                         + "  and ZBGGFJ_WHR='" + CMisproApp.GetCurrentUser().Users_Name + "'";
                ChangeData(sql);
                ViewData["Operate"] = "N";
            }
            else
            {
                oZTBGG = context.ZBGG.SingleOrDefault(p => p.ZBGG_XMID==id);
                ViewData["Operate"] = "E";
            }
            ViewData["GCID"] = id;
            return View(oZTBGG);
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZBGGDel(int id)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                ZBGG oZTBGG = new ZBGG();
                oZTBGG = context.ZBGG.SingleOrDefault(p => p.ZBGG_ID == id);
                context.ZBGG.DeleteOnSubmit(oZTBGG);
                context.ZBGG.Context.SubmitChanges();
                var T = context.ZBGGFJ.Where(p => p.ZBGGFJ_GRPID == oZTBGG.ZBGG_GRPID);
                context.ZBGGFJ.DeleteAllOnSubmit(T);
                context.ZBGGFJ.Context.SubmitChanges();
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZBGGSave(int id, int GCID, string GGSJB, string GGSJE, string WJFSB, string WJFSE, int iGRPID,string GZGK, string sOperate)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                ZBGG oZTBGG = new ZBGG();
                switch (sOperate)
                {
                    case "N":
                        oZTBGG.ZBGG_ID = MisproUtils.GetMaxTblID("ZBGG", "ZBGG_ID");
                        oZTBGG.ZBGG_XMID = GCID;
                        if (!String.IsNullOrEmpty(GGSJB))
                        {
                            oZTBGG.ZBGG_GGSJB = DateTime.Parse(GGSJB);
                        }
                        if (!String.IsNullOrEmpty(GGSJE))
                        {
                            oZTBGG.ZBGG_GGSJE = DateTime.Parse(GGSJE);
                        }
                        if (!String.IsNullOrEmpty(WJFSB))
                        {
                            oZTBGG.ZBGG_WJFSB = DateTime.Parse(WJFSB);
                        }
                        if (!String.IsNullOrEmpty(WJFSE))
                        {
                            oZTBGG.ZBGG_WJFSE = DateTime.Parse(WJFSE);
                        }
                        oZTBGG.ZBGG_GRPID = iGRPID;
                        oZTBGG.ZBGG_FJS = context.ZBGGFJ.Where(p => p.ZBGGFJ_GRPID == iGRPID).Count();
                        oZTBGG.ZBGG_GCGK = GZGK;
                        oZTBGG.ZBGG_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oZTBGG.ZBGG_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oZTBGG.ZBGG_WHSJ = DateTime.Now;
                        context.ZBGG.InsertOnSubmit(oZTBGG);
                        context.ZBGG.Context.SubmitChanges();
                        break;
                    case "E":
                        oZTBGG = context.ZBGG.SingleOrDefault(p => p.ZBGG_ID == id);
                        oZTBGG.ZBGG_XMID = GCID;
                        if (!String.IsNullOrEmpty(GGSJB))
                        {
                            oZTBGG.ZBGG_GGSJB = DateTime.Parse(GGSJB);
                        }
                        if (!String.IsNullOrEmpty(GGSJE))
                        {
                            oZTBGG.ZBGG_GGSJE = DateTime.Parse(GGSJE);
                        }
                        if (!String.IsNullOrEmpty(WJFSB))
                        {
                            oZTBGG.ZBGG_WJFSB = DateTime.Parse(WJFSB);
                        }
                        if (!String.IsNullOrEmpty(WJFSE))
                        {
                            oZTBGG.ZBGG_WJFSE = DateTime.Parse(WJFSE);
                        }
                        oZTBGG.ZBGG_GRPID = iGRPID;
                        oZTBGG.ZBGG_FJS = context.ZBGGFJ.Where(p => p.ZBGGFJ_GRPID == iGRPID).Count();
                        oZTBGG.ZBGG_GCGK = GZGK;
                        oZTBGG.ZBGG_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oZTBGG.ZBGG_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oZTBGG.ZBGG_WHSJ = DateTime.Now;
                        context.ZBGG.Context.SubmitChanges();
                        break;
                    default:
                        break;
                }
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public void ChangeData(string sql)
        {
            DBHelper db = new DBHelper();
            try
            {
                db.ExecuteNonQuery(CommandType.Text, sql);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                db = null;
            }
        }

        #endregion
    }
}
