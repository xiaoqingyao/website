﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WoExpress.DataEntity.Models;
using WoExpress.Core.Page;
using WoExpress.PUBLIC.Controllers;

namespace WoExpress.ZBGL.Controllers
{
    public class ZBJGController : Controller
    {
        //
        // GET: /ZBJG/

        public ActionResult ZBJG(int id)
        {
            ViewData["id"] = id;
            ViewData["AutoCompStrJSDW"] = PUBLICController.GetAllUnitHints("XT02");
            ViewData["AutoCompStr"] = PUBLICController.GetAllPersonints();
            return View();
        }

        public ActionResult ZBJGList(int id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.ZBXMBD.Where(p => p.ZBXMBD_XMID == id);
            return View(TPageWizard.GetData<ZBXMBD>(T.ToList().Count, 1, T.ToList()));
        }

        public string ZBJGInfo(int id)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                ZBXMBD oZTBGG = new ZBXMBD();
                oZTBGG = context.ZBXMBD.SingleOrDefault(p => p.ZBXMBD_ID == id);
               Unit unit= context.Unit.SingleOrDefault(p => p.Unit_ID == oZTBGG.ZBXMBD_ZBDW);
               if (unit != null)
                {
                    string res = unit.Unit_Name + "," + oZTBGG.ZBXMBD_ZBJG + "," + oZTBGG.ZBXMBD_ZBDW+","+oZTBGG.ZBXMBD_ZBXMJL+","+oZTBGG.ZBXMBD_SMZBJ;
                   Person person=context.Person.SingleOrDefault(p=>p.Person_ID==oZTBGG.ZBXMBD_ZBXMJL);
                   if(person!=null)
                   {
                       res += "," + person.Person_Name + "," + person.Person_DH;
                   }
                    return res;
                }
                else
                {

                    return "";
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZBJGSave(int id, int txtJSDWID, string txtZBJG, string txtXMJL, string txtSMZBJ)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                ZBXMBD oZTBGG = new ZBXMBD();
                oZTBGG = context.ZBXMBD.SingleOrDefault(p => p.ZBXMBD_ID == id);
                oZTBGG.ZBXMBD_ZBDW = txtJSDWID;
                oZTBGG.ZBXMBD_ZBJG = decimal.Parse(txtZBJG);
                oZTBGG.ZBXMBD_ZBXMJL = int.Parse(txtXMJL);
                oZTBGG.ZBXMBD_SMZBJ = txtSMZBJ;
                context.ZBXMBD.Context.SubmitChanges();
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }


    }
}
