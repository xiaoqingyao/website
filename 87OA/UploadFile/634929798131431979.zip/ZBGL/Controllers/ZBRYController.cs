﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WoExpress.DataEntity.Models;
using WoExpress.Core.Page;
using WoExpress.Core.Utility;
using WoExpress.Core.Data;
using System.Data;
using WoExpress.PUBLIC.Controllers;

namespace WoExpress.ZBGL.Controllers
{
    public class ZBRYController : Controller
    {
        const int iPageSize = 10;

        #region 招标人员

        public ActionResult ZBRY(int id)
        {
            ViewData["GCID"] = id;
            return View();
        }

        public ActionResult RYBB(int id)
        {
            ViewData["GCID"] = id;
            return View();
        }

        public ActionResult ZBRYList(int iPageNo, int id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.ZBRY.Where(p => p.ZBRY_ID != 0  && p.ZBRY_XMID == id);
            T = T.OrderByDescending(p => p.ZBRY_WHSJ);
            return View(TPageWizard.GetData<ZBRY>(iPageSize, iPageNo, T.ToList()));
        }

        public ActionResult RYBBList(int iPageNo, int id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.ZBRY.Where(p => p.ZBRY_ID != 0 && p.ZBRY_XMID == id);
            T = T.OrderByDescending(p => p.ZBRY_WHSJ);
            ViewData["GCMC"] = context.ZBXMXX.SingleOrDefault(p => p.ZBXMXX_ID == id).ZBXMXX_XMMC;
            return View(TPageWizard.GetData<ZBRY>(iPageSize, iPageNo, T.ToList()));
        }

        public ActionResult ZBRYInfo(int id, string sOperate)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            ZBRY oZTBGG = new ZBRY();
            switch (sOperate)
            {
                case "N":
                    oZTBGG.ZBRY_GRPID = 1;
                    oZTBGG.ZBRY_ID = 0;
                    oZTBGG.ZBRY_RYID = 0;
                    break;
                case "E":
                    oZTBGG = context.ZBRY.SingleOrDefault(p => p.ZBRY_ID == id);
                    break;
                case "V":
                    oZTBGG = context.ZBRY.SingleOrDefault(p => p.ZBRY_ID == id);
                    break;
                default:
                    break;
            }
            ViewData["Operate"] = sOperate;
            ViewData["AutoCompStr"] = PUBLICController.GetAllPersonints();
            ViewData["GCID"] = id;
            return View(oZTBGG);
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZBRYDel(int id)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                ZBRY oZTBGG = new ZBRY();
                oZTBGG = context.ZBRY.SingleOrDefault(p => p.ZBRY_ID == id);
                context.ZBRY.DeleteOnSubmit(oZTBGG);
                context.ZBRY.Context.SubmitChanges();
                var T = context.ZBRYFJ.Where(p => p.ZBRYFJ_GRPID == oZTBGG.ZBRY_GRPID);
                context.ZBRYFJ.DeleteAllOnSubmit(T);
                context.ZBRYFJ.Context.SubmitChanges();
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZBRYSave(int id, int GCID, int RYID, string ZW, string ZC, string ZCZG, int iGRPID, string SGZH, string BZ, string sOperate)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                ZBRY oZTBGG = new ZBRY();
                switch (sOperate)
                {
                    case "N":
                        oZTBGG.ZBRY_ID = MisproUtils.GetMaxTblID("ZBRY", "ZBRY_ID");
                        oZTBGG.ZBRY_XMID = GCID;
                        oZTBGG.ZBRY_RYID = RYID;
                        oZTBGG.ZBRY_ZW = ZW;
                        oZTBGG.ZBRY_ZC = ZC;
                        oZTBGG.ZBRY_ZCZG = ZCZG;
                        oZTBGG.ZBRY_SGZH = SGZH;
                        oZTBGG.ZBRY_BZ = BZ;
                        oZTBGG.ZBRY_GRPID = iGRPID;
                        oZTBGG.ZBRY_FJS = context.ZBRYFJ.Where(p => p.ZBRYFJ_GRPID == iGRPID).Count();
                        oZTBGG.ZBRY_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oZTBGG.ZBRY_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oZTBGG.ZBRY_WHSJ = DateTime.Now;
                        context.ZBRY.InsertOnSubmit(oZTBGG);
                        context.ZBRY.Context.SubmitChanges();
                        break;
                    case "E":
                        oZTBGG = context.ZBRY.SingleOrDefault(p => p.ZBRY_ID == id);
                        oZTBGG.ZBRY_XMID = GCID;
                        oZTBGG.ZBRY_RYID = RYID;
                        oZTBGG.ZBRY_ZW = ZW;
                        oZTBGG.ZBRY_ZC = ZC;
                        oZTBGG.ZBRY_ZCZG = ZCZG;
                        oZTBGG.ZBRY_SGZH = SGZH;
                        oZTBGG.ZBRY_BZ = BZ;
                        oZTBGG.ZBRY_GRPID = iGRPID;
                        oZTBGG.ZBRY_FJS = context.ZBRYFJ.Where(p => p.ZBRYFJ_GRPID == iGRPID).Count();
                        oZTBGG.ZBRY_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oZTBGG.ZBRY_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oZTBGG.ZBRY_WHSJ = DateTime.Now;
                        context.ZBRY.Context.SubmitChanges();
                        break;
                    default:
                        break;
                }
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        #endregion
    }
}
