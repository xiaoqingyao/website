﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WoExpress.DataEntity.Models;
using WoExpress.Core.Utility;
using WoExpress.Core.Page;

namespace WoExpress.ZBGL.Controllers
{
    public class ZBSXBAController : Controller
    {
        //
        // GET: /ZBFBFA/
        public ActionResult SXBA(int id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            WoExpress.DataEntity.Models.ZBXMXX oXMXX = new WoExpress.DataEntity.Models.ZBXMXX();
            oXMXX = context.ZBXMXX.Where(p => p.ZBXMXX_ID == id).ToList()[0];
            var TT = context.ZBXMXX.Where(p => p.ZBXMXX_ID == id);
            if (TT.ToList().Count > 0)
            {
                Person person = context.Person.SingleOrDefault(p => p.Person_ID == TT.ToList()[0].ZBXMXX_JSDWLXR);
                if (person != null)
                {
                    ViewData["LXR"] = person.Person_Name;
                    ViewData["LXRDH"] = person.Person_DH;
                }
            }
            return View(oXMXX);
        }

        public ActionResult SXBAList(int iPageNo, int iJDCJID)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.ZBXMBD.Where(p => p.ZBXMBD_XMID == iJDCJID);
           
            return View(TPageWizard.GetData<ZBXMBD>(T.ToList().Count, iPageNo, T.ToList()));
        }

    }
}
