﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WoExpress.DataEntity.Models;
using WoExpress.Core.Utility;
using WoExpress.Core.Page;
using WoExpress.Core.Data;
using System.Data;

namespace WoExpress.ZBGL.Controllers
{
    public class ZBWJController : Controller
    {
        const int iPageSize = 10;

        #region 招标文件

        public ActionResult ZBWJ(int id)
        {
            ViewData["GCID"] = id;
            return View();
        }

        public ActionResult ZBWJList(int iPageNo, int id, string sdate, string edate)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.ZBWJ.Where(p => p.ZBWJ_ID != 0 && p.ZBWJ_WHRID == CMisproApp.GetCurrentUser().Users_ID && p.ZBWJ_XMID == id);
            if (!String.IsNullOrEmpty(sdate))
                T = T.Where(p => p.ZBWJ_WHSJ >= DateTime.Parse(sdate));
            if (!String.IsNullOrEmpty(edate))
                T = T.Where(p => p.ZBWJ_WHSJ <= DateTime.Parse(edate));
            T = T.OrderByDescending(p => p.ZBWJ_WHSJ);
            return View(TPageWizard.GetData<ZBWJ>(iPageSize, iPageNo, T.ToList()));
        }

        public ActionResult ZBWJInfo(int id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            ZBWJ oZTBGG = new ZBWJ();
            var T = context.ZBWJ.Where(p => p.ZBWJ_XMID == id);
            if (T.ToList().Count == 0)
            {
                oZTBGG.ZBWJ_GRPID = MisproUtils.GetNewID("ZBWJ");
                oZTBGG.ZBWJ_ID = id;
                string sql = "delete from ZBWJFJ where ZBWJFJ_GRPID not in(select ZBWJFJ_GRPID "
                         + "from ZBWJ) "
                         + "  and ZBWJFJ_WHR='" + CMisproApp.GetCurrentUser().Users_Name + "'";
                ChangeData(sql);
                ViewData["Operate"] = "N";
            }
            else
            {
                oZTBGG.ZBWJ_GRPID = T.ToList()[0].ZBWJ_GRPID;
                ViewData["Operate"] = "E";
            }
            ViewData["GCID"] = id;
            return View(oZTBGG);
        }

        public string WJInfo(int id, int bid)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                ZBWJ oZTBGG = new ZBWJ();
                oZTBGG = context.ZBWJ.SingleOrDefault(p => p.ZBWJ_ID == bid && p.ZBWJ_XMID == id);
                if (oZTBGG != null)
                {
                    if (oZTBGG.ZBWJ_GRPID == 0)
                    {
                        oZTBGG.ZBWJ_GRPID = MisproUtils.GetNewID("ZBWJ");
                    }
                    string res = oZTBGG.ZBWJ_KBSJ + "," + oZTBGG.ZBWJ_KBDD + "," + oZTBGG.ZBWJ_PBBF + "," + oZTBGG.ZBWJ_GRPID;
                    return res;
                }
                else
                {
                    return "";
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZBWJDel(int id)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                ZBWJ oZTBGG = new ZBWJ();
                oZTBGG = context.ZBWJ.SingleOrDefault(p => p.ZBWJ_ID == id);
                context.ZBWJ.DeleteOnSubmit(oZTBGG);
                context.ZBWJ.Context.SubmitChanges();
                var T = context.ZBWJFJ.Where(p => p.ZBWJFJ_GRPID == oZTBGG.ZBWJ_GRPID);
                context.ZBWJFJ.DeleteAllOnSubmit(T);
                context.ZBWJFJ.Context.SubmitChanges();
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZBWJSave(int id, int GCID, string KBSJ, string KBDD, string PBFS, int iGRPID, string sOperate)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                ZBWJ oZTBGG = new ZBWJ();
                if (context.ZBWJ.SingleOrDefault(p => p.ZBWJ_ID == GCID && p.ZBWJ_XMID == id) == null)
                {
                    oZTBGG.ZBWJ_ID = GCID;
                    oZTBGG.ZBWJ_XMID = id;
                    if (!String.IsNullOrEmpty(KBSJ))
                    {
                        oZTBGG.ZBWJ_KBSJ = DateTime.Parse(KBSJ);
                    }
                    oZTBGG.ZBWJ_GRPID = iGRPID;
                    oZTBGG.ZBWJ_FJS = context.ZBWJFJ.Where(p => p.ZBWJFJ_GRPID == iGRPID).Count();
                    oZTBGG.ZBWJ_KBDD = KBDD;
                    oZTBGG.ZBWJ_PBBF = PBFS;
                    oZTBGG.ZBWJ_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                    oZTBGG.ZBWJ_WHR = CMisproApp.GetCurrentUser().Users_Name;
                    oZTBGG.ZBWJ_WHSJ = DateTime.Now;
                    context.ZBWJ.InsertOnSubmit(oZTBGG);
                    context.ZBWJ.Context.SubmitChanges();
                }
                else
                {
                    oZTBGG = context.ZBWJ.SingleOrDefault(p => p.ZBWJ_ID == GCID && p.ZBWJ_XMID == id);
                    if (!String.IsNullOrEmpty(KBSJ))
                    {
                        oZTBGG.ZBWJ_KBSJ = DateTime.Parse(KBSJ);
                    }
                    oZTBGG.ZBWJ_GRPID = iGRPID;
                    oZTBGG.ZBWJ_FJS = context.ZBWJFJ.Where(p => p.ZBWJFJ_GRPID == iGRPID).Count();
                    oZTBGG.ZBWJ_KBDD = KBDD;
                    oZTBGG.ZBWJ_PBBF = PBFS;
                    oZTBGG.ZBWJ_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                    oZTBGG.ZBWJ_WHR = CMisproApp.GetCurrentUser().Users_Name;
                    oZTBGG.ZBWJ_WHSJ = DateTime.Now;
                    context.ZBWJ.Context.SubmitChanges();
                }

                var TZBXMBD = context.ZBXMBD.Where(p => p.ZBXMBD_ID == GCID);
                if (TZBXMBD.Count() > 0)
                {
                    if (!String.IsNullOrEmpty(KBSJ))
                    {
                        TZBXMBD.First().ZBXMBD_KBSJ = DateTime.Parse(KBSJ);
                        context.SubmitChanges();
                    }

                }

                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZBWJSave2(int id, int GCID, string KBSJ, string KBDD, string PBFS, int iGRPID, string sOperate)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                var T = context.ZBXMBD.Where(p => p.ZBXMBD_XMID == id);
                foreach (var item in T)
                {
                    ZBWJ oZTBGG = new ZBWJ();
                    if (context.ZBWJ.SingleOrDefault(p => p.ZBWJ_ID == item.ZBXMBD_ID && p.ZBWJ_XMID == id) == null)
                    {
                        oZTBGG.ZBWJ_ID = item.ZBXMBD_ID;
                        oZTBGG.ZBWJ_XMID = id;
                        if (!String.IsNullOrEmpty(KBSJ))
                        {
                            oZTBGG.ZBWJ_KBSJ = DateTime.Parse(KBSJ);
                        }
                        oZTBGG.ZBWJ_GRPID = iGRPID;
                        oZTBGG.ZBWJ_FJS = context.ZBWJFJ.Where(p => p.ZBWJFJ_GRPID == iGRPID).Count();
                        oZTBGG.ZBWJ_KBDD = KBDD;
                        oZTBGG.ZBWJ_PBBF = PBFS;
                        oZTBGG.ZBWJ_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oZTBGG.ZBWJ_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oZTBGG.ZBWJ_WHSJ = DateTime.Now;
                        context.ZBWJ.InsertOnSubmit(oZTBGG);
                        context.ZBWJ.Context.SubmitChanges();
                    }
                    else
                    {
                        oZTBGG = context.ZBWJ.SingleOrDefault(p => p.ZBWJ_ID == item.ZBXMBD_ID && p.ZBWJ_XMID == id);
                        if (!String.IsNullOrEmpty(KBSJ))
                        {
                            oZTBGG.ZBWJ_KBSJ = DateTime.Parse(KBSJ);
                        }
                        oZTBGG.ZBWJ_GRPID = iGRPID;
                        oZTBGG.ZBWJ_FJS = context.ZBWJFJ.Where(p => p.ZBWJFJ_GRPID == iGRPID).Count();
                        oZTBGG.ZBWJ_KBDD = KBDD;
                        oZTBGG.ZBWJ_PBBF = PBFS;
                        oZTBGG.ZBWJ_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oZTBGG.ZBWJ_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oZTBGG.ZBWJ_WHSJ = DateTime.Now;
                        context.ZBWJ.Context.SubmitChanges();
                    }
                    var TZBXMBD = context.ZBXMBD.SingleOrDefault(p => p.ZBXMBD_ID == item.ZBXMBD_ID);
                    if (!String.IsNullOrEmpty(KBSJ))
                    {
                        TZBXMBD.ZBXMBD_KBSJ = DateTime.Parse(KBSJ);
                        context.SubmitChanges();
                    }
                }

                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public void ChangeData(string sql)
        {
            DBHelper db = new DBHelper();
            try
            {
                db.ExecuteNonQuery(CommandType.Text, sql);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                db = null;
            }
        }

        #endregion

    }
}
