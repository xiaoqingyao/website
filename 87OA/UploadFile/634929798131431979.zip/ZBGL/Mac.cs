﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WoExpress.Core.System;

namespace WoExpress.ZBGL
{
    public class Mac : WoExpress.Core.System.Mac
    {
        public Mac()
        {
            //以下设置部件信息
            ID = "ZBGL";
            Name = "招标管理";
            Supplier = "南京沃叶软件有限公司";
            Version = 2;

            //以下设置各模块的信息（610000-619999）
            AddModuleInfo(610000, 0, "招标管理", "C", "");
            
            AddModuleInfo(611000, 610000, "项目管理", "C", "");
            AddModuleInfo(611010, 611000, "项目类别", "F", "/ZBGL/YWGL/XMLB");
            AddModuleInfo(611020, 611000, "收费标准", "F", "/ZBGL/YWGL/SFBZ");
            AddModuleInfo(611021, 611000, "项目进度", "F", "/ZBGL/YWGL/XMJD");
            AddModuleInfo(611022, 611000, "代理小组", "F", "/ZBGL/YWGL/DLXZ");
            AddModuleInfo(611030, 611000, "项目概况", "F", "/ZBGL/YWGL/XMGK");
            AddModuleInfo(611032, 611000, "立项文件", "F", "/ZBGL/LX/ZBLX/0");
            AddModuleInfo(611040, 611000, "项目登记", "F", "/ZBGL/YWGL/XMDJ/0");
            AddModuleInfo(611045, 611000, "文件管理", "F", "/ZBGL/ZBWJGL/WJGL");
            AddModuleInfo(611050, 611000, "综合查询", "F", "/ZBGL/CXTJ/YWJBQK");

            AddModuleInfo(613000, 610000, "合同收款管理", "C", "");
            AddModuleInfo(613010, 613000, "代理合同", "F", "/ZBGL/YWGL/HTDL");
            AddModuleInfo(613020, 613000, "收款登记", "F", "/ZBGL/YWGL/SKDJTJ");

            AddModuleInfo(614000, 610000, "常用报表管理", "C", "");
            AddModuleInfo(614010, 614000, "项目查询", "F", "/ZBGL/BBGL/XMCX");
            AddModuleInfo(614015, 614000, "代理合同预警查询", "F", "/ZBGL/BBGL/HTYJ");
            AddModuleInfo(614020, 614000, "按建设单位统计", "F", "/ZBGL/BBGL/DWTJ");
            AddModuleInfo(614030, 614000, "按负责人统计", "F", "/ZBGL/BBGL/FZRTJ");
            
        }
    }
}
