﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WoExpress.DataEntity.Models;

namespace WoExpress.ZBGL.Models
{
    public static class Common
    {
        /// <summary>
        /// 根据服务类型和中标金额获取代理费用【目前根据[2002]1980号文】
        /// </summary>
        /// <param name="p_FWLX">服务类型</param>
        /// <param name="p_ZBJE">中标金额</param>
        /// <returns>代理费用</returns>
        public static decimal GetAgencyCost(string p_FWLX, decimal p_ZBJE)
        {
            decimal dResult = 0;
            using (DataEntityDataContext context = new DataEntityDataContext())
            {
                var T = context.ZBSFBZ.Where(p => p.ZBSFBZ_FWLX == p_FWLX).OrderBy(p => p.ZBSFBZ_ZBJEXX);
                foreach (var t in T)
                {
                    if (p_ZBJE <= t.ZBSFBZ_ZBJESX.Value || t.ZBSFBZ_ZBJESX.Value == 0)
                        return dResult + (p_ZBJE - t.ZBSFBZ_ZBJEXX.Value) * t.ZBSFBZ_FL.Value;
                    else
                        dResult += (t.ZBSFBZ_ZBJESX.Value - t.ZBSFBZ_ZBJEXX.Value) * t.ZBSFBZ_FL.Value;
                }
            }
            return dResult;
        }
    }
}
