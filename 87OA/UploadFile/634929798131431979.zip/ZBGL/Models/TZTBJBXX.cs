﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WoExpress.DataEntity.Models;

namespace WoExpress.ZBGL.Models
{
    public class TZTBJBXX
    {
        public int ID { get; set; }
        public string ZBXMXX_XMMC { get; set; }
        public string ZBXMXX_LB { get; set; }
        public string ZBXMXX_XMBH { get; set; }
        public decimal ZBXMXX_ZBJ { get; set; }
        public string ZBXMXX_SMZBJ { get; set; }
        public decimal ZBXMXX_YSJE { get; set; }
        public decimal ZBXMXX_ZFJE { get; set; }
        public decimal ZTBHTBA_SQJE { get; set; }
        public DateTime ZTBGG_KBSJ { get; set; }
        public string Unit_JSDWName { get; set; }
        public string Unit_ZBDWName { get; set; }
        public string ZBXMXX_ZBFS { get; set; }
        public string ZBXMLB_MC { get; set; }
        public string Person_Name { get; set; }

    }

    public class TTJData
    {
        public float fPX1;
        public float fPX2;
        public string sJSDW;
        public int iXMID;
        public string sXMMC;
        public string sFZRXM;
        public string sZBFS;
        public string sXMLB;
        public string sZBDW;
        public string sSMZBJ;
        public decimal dYSJE;
        public decimal dZFJE;
        public decimal dZBJE;
        public decimal dSQJE;
        public decimal dBGJE;
        public DateTime sKBSJ;
        public string JSDWLXR;
        public string DH;
    }
}
