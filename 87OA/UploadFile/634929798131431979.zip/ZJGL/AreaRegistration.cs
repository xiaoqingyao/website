﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WoExpress.ZJGL
{
    public class ZJGLAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "ZJGL";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "ZJGL_default",
                "ZJGL/{controller}/{action}/{id}",
                new { action = "Index", id = "" }
            );
        }
    }
}
