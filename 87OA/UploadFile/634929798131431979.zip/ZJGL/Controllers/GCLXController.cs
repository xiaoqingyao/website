﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WoExpress.DataEntity.Models;
using WoExpress.Core.Utility;
using WoExpress.Core.Page;

namespace WoExpress.ZJGL.Controllers
{
    /// <summary>
    /// 造价工程类型控制器
    /// </summary>
    public class GCLXController : Controller
    {
        const int iPageSize = 15;
        #region 造价工作类型

        public ActionResult ZJGCLX()
        {
            return View();
        }

        public ActionResult ZJGCLXInfo(int id, string sOperate)
        {
            using (DataEntityDataContext context = new DataEntityDataContext())
            {
                ZJGCLX oZJGCLX = new ZJGCLX();
                switch (sOperate)
                {
                    case "N":
                        oZJGCLX.ZJGCLX_ID = MisproUtils.GetMaxTblID("ZJGCLX", "ZJGCLX_ID");
                        break;
                    case "E":
                        oZJGCLX = context.ZJGCLX.SingleOrDefault(p => p.ZJGCLX_ID == id);
                        break;
                    case "V":
                        oZJGCLX = context.ZJGCLX.SingleOrDefault(p => p.ZJGCLX_ID == id);
                        break;
                }
                ViewData["sOperate"] = sOperate;
                return View(oZJGCLX);
            }
        }

        public ActionResult ZJGCLXList(int iPageNo, string selzt)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                var T = context.ZJGCLX.Where(p => p.ZJGCLX_ID > 0);
                if (!string.IsNullOrEmpty(selzt))
                {
                    T = T.Where(p=>p.ZJGCLX_TY==int.Parse(selzt));
                }
                return View(TPageWizard.GetData<ZJGCLX>(iPageSize, iPageNo, T.ToList()));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZJGCLXSave(int id, string sMC, string sBZ,int sStopped, string sOperate)
        {
            try
            {
                using (DataEntityDataContext context = new DataEntityDataContext())
                {
                    ZJGCLX oZJGCLX = new ZJGCLX();
                    var np = CMisproApp.GetCurrentUser();
                    switch (sOperate)
                    {
                        case "N":
                            oZJGCLX.ZJGCLX_ID = id;
                            oZJGCLX.ZJGCLX_BZ = sBZ;
                            oZJGCLX.ZJGCLX_MC = sMC;
                            oZJGCLX.ZJGCLX_TY = sStopped;
                            oZJGCLX.ZJGCLX_WHR = np.Users_Name;
                            oZJGCLX.ZJGCLX_WHRID = np.Users_ID;
                            oZJGCLX.ZJGCLX_WHSJ = DateTime.Now;
                            context.ZJGCLX.InsertOnSubmit(oZJGCLX);
                            context.ZJGCLX.Context.SubmitChanges();
                            break;
                        case "E":
                            oZJGCLX = context.ZJGCLX.SingleOrDefault(p => p.ZJGCLX_ID == id);
                            oZJGCLX.ZJGCLX_BZ = sBZ;
                            oZJGCLX.ZJGCLX_MC = sMC;
                            oZJGCLX.ZJGCLX_TY = sStopped;
                            oZJGCLX.ZJGCLX_WHR = np.Users_Name;
                            oZJGCLX.ZJGCLX_WHRID = np.Users_ID;
                            oZJGCLX.ZJGCLX_WHSJ = DateTime.Now;
                            context.ZJGCLX.Context.SubmitChanges();
                            break;
                    }
                    return "OK";
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZJGCLXDel(int id)
        {
            try
            {
                using (DataEntityDataContext context = new DataEntityDataContext())
                {
                    ZJGCLX oZJGCLX = context.ZJGCLX.SingleOrDefault(p => p.ZJGCLX_ID == id);
                    context.ZJGCLX.DeleteOnSubmit(oZJGCLX);
                    context.ZJGCLX.Context.SubmitChanges();
                    return "OK";
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        
        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZJGCLXTY(int id)
        {
            try
            {
                using (DataEntityDataContext context = new DataEntityDataContext())
                {
                    ZJGCLX oZJGCLX = context.ZJGCLX.SingleOrDefault(p => p.ZJGCLX_ID == id);
                    if (oZJGCLX.ZJGCLX_TY == 0)
                    {
                        oZJGCLX.ZJGCLX_TY = 1;
                    }
                    else
                    {
                        oZJGCLX.ZJGCLX_TY =0;
                    }
                    context.ZJGCLX.Context.SubmitChanges();
                    return "OK";
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        
        #endregion
    }
}
