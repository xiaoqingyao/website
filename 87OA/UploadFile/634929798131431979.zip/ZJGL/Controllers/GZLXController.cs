﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WoExpress.DataEntity.Models;
using WoExpress.Core.Utility;
using WoExpress.Core.Page;

namespace WoExpress.ZJGL.Controllers
{
    /// <summary>
    /// 造价工作类型控制器
    /// </summary>
    public class GZLXController : Controller
    {
        const int iPageSize = 15;

        #region 造价工作类型

        public ActionResult ZJGZLX()
        {
            return View();
        }

        public ActionResult ZJGZLXInfo(int id, string sOperate)
        {
            using (DataEntityDataContext context = new DataEntityDataContext())
            {
                ZJGZLX oZJGZLX = new ZJGZLX();
                switch (sOperate)
                {
                    case "N":
                        oZJGZLX.ZJGZLX_ID = MisproUtils.GetMaxTblID("ZJGZLX", "ZJGZLX_ID");
                        break;
                    case "E":
                        oZJGZLX = context.ZJGZLX.SingleOrDefault(p => p.ZJGZLX_ID == id);
                        break;
                    case "V":
                        oZJGZLX = context.ZJGZLX.SingleOrDefault(p => p.ZJGZLX_ID == id);
                        break;
                }
                ViewData["sOperate"] = sOperate;
                return View(oZJGZLX);
            }
        }

        public ActionResult ZJGZLXList(int iPageNo, string selzt)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                var T = context.ZJGZLX.Where(p => p.ZJGZLX_ID > 0);
                if (!string.IsNullOrEmpty(selzt))
                {
                    T = T.Where(p => p.ZJGZLX_TY == int.Parse(selzt));
                }
                return View(TPageWizard.GetData<ZJGZLX>(iPageSize, iPageNo, T.ToList()));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZJGZLXSave(int id, string sMC, string JSJS, string GZXZ, string sBZ, int sStopped, string sOperate)
        {
            try
            {
                using (DataEntityDataContext context = new DataEntityDataContext())
                {
                    ZJGZLX oZJGZLX = new ZJGZLX();
                    var np = CMisproApp.GetCurrentUser();
                    switch (sOperate)
                    {
                        case "N":
                            oZJGZLX.ZJGZLX_ID = id;
                            oZJGZLX.ZJGZLX_BZ = sBZ;
                            oZJGZLX.ZJGZLX_MC = sMC;
                            oZJGZLX.ZJGZLX_JSJS = JSJS;
                            oZJGZLX.ZJGZLX_GZXZ = GZXZ;
                            oZJGZLX.ZJGZLX_TY = sStopped;
                            oZJGZLX.ZJGZLX_WHR = np.Users_Name;
                            oZJGZLX.ZJGZLX_WHRID = np.Users_ID;
                            oZJGZLX.ZJGZLX_WHSJ = DateTime.Now;
                            context.ZJGZLX.InsertOnSubmit(oZJGZLX);
                            context.ZJGZLX.Context.SubmitChanges();
                            break;
                        case "E":
                            oZJGZLX = context.ZJGZLX.SingleOrDefault(p => p.ZJGZLX_ID == id);
                            oZJGZLX.ZJGZLX_BZ = sBZ;
                            oZJGZLX.ZJGZLX_MC = sMC;
                            oZJGZLX.ZJGZLX_JSJS = JSJS;
                            oZJGZLX.ZJGZLX_GZXZ = GZXZ;
                            oZJGZLX.ZJGZLX_TY = sStopped;
                            oZJGZLX.ZJGZLX_WHR = np.Users_Name;
                            oZJGZLX.ZJGZLX_WHRID = np.Users_ID;
                            oZJGZLX.ZJGZLX_WHSJ = DateTime.Now;
                            context.ZJGZLX.Context.SubmitChanges();
                            break;
                    }
                    return "OK";
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZJGZLXDel(int id)
        {
            try
            {
                using (DataEntityDataContext context = new DataEntityDataContext())
                {
                    ZJGZLX oZJGZLX = context.ZJGZLX.SingleOrDefault(p => p.ZJGZLX_ID == id);
                    context.ZJGZLX.DeleteOnSubmit(oZJGZLX);
                    context.ZJGZLX.Context.SubmitChanges();
                    return "OK";
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZJGZLXTY(int id)
        {
            try
            {
                using (DataEntityDataContext context = new DataEntityDataContext())
                {
                    ZJGZLX oZJGCLX = context.ZJGZLX.SingleOrDefault(p => p.ZJGZLX_ID == id);
                    if (oZJGCLX.ZJGZLX_TY == 0)
                    {
                        oZJGCLX.ZJGZLX_TY = 1;
                    }
                    else
                    {
                        oZJGCLX.ZJGZLX_TY = 0;
                    }
                    context.ZJGZLX.Context.SubmitChanges();
                    return "OK";
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        #endregion
    }
}
