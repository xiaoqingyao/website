﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WoExpress.DataEntity.Models;
using WoExpress.Core.Page;
using WoExpress.Core.Utility;
using WoExpress.Core.Data;
using System.Data;

namespace WoExpress.ZJGL.Controllers
{
    /// <summary>
    /// 结算标准控制器
    /// </summary>
    public class JSBZController : Controller
    {
        const int iPageSize = 15;

        #region 结算标准

        public ActionResult ZJJSBZ()
        {
            return View();
        }

        public ActionResult ZJJSBZList(int iPageNo, string selzt)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZJJSBZ.Where(p => p.ZJJSBZ_ID != 0);
            if (!string.IsNullOrEmpty(selzt))
            {
                T = T.Where(p => p.ZJJSBZ_TY == int.Parse(selzt));
            }
            return View(TPageWizard.GetData<ZJJSBZ>(iPageSize, iPageNo, T.ToList()));
        }

        public ActionResult ZJJSBZInfo(int id, string sOperate)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            WoExpress.DataEntity.Models.ZJJSBZ oXMLB = new WoExpress.DataEntity.Models.ZJJSBZ();
            switch (sOperate)
            {
                case "N":
                    break;
                case "E":
                    oXMLB = entity.ZJJSBZ.SingleOrDefault(p => p.ZJJSBZ_ID == id);
                    break;
                case "V":
                    oXMLB = entity.ZJJSBZ.SingleOrDefault(p => p.ZJJSBZ_ID == id);
                    break;
                default:
                    break;
            }
            ViewData["Operate"] = sOperate;

            return View(oXMLB);
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZJJSBZTY(int id)
        {
            try
            {
                using (DataEntityDataContext context = new DataEntityDataContext())
                {
                    ZJJSBZ oZJGCLX = context.ZJJSBZ.SingleOrDefault(p => p.ZJJSBZ_ID == id);
                    if (oZJGCLX.ZJJSBZ_TY == 0)
                    {
                        oZJGCLX.ZJJSBZ_TY = 1;
                    }
                    else
                    {
                        oZJGCLX.ZJJSBZ_TY = 0;
                    }
                    context.ZJJSBZ.Context.SubmitChanges();
                    return "OK";
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }


        public ActionResult ViewJSBZMX(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZJJSBZMX.Where(p => p.ZJJSBZMX_ID == id);
            string sql = "select ZJJSBZMX_GCLXID from ZJJSBZMX where ZJJSBZMX_ID="+id+" group by ZJJSBZMX_GCLXID";
            string sql1 = "select  ZJJSBZMX_ZJJEXX ,ZJJSBZMX_ZJJESX ,ZJJSBZMX_GZLXID from ZJJSBZMX where ZJJSBZMX_ID=" + id + " group by ZJJSBZMX_GZLXID,ZJJSBZMX_ZJJEXX,ZJJSBZMX_ZJJESX order by ZJJSBZMX_ZJJEXX,ZJJSBZMX_ZJJESX asc ";
            string result = "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"border: 1px solid #C0C0C0; table-layout: fixed; width: 100%;\"><tr class=\"wx_table_head_tr\"><td>造价金额下限</td><td>造价金额上限</td><td>考核类别</td>";
            string sID = "";
            DBHelper oDBHelper = null;
            try
            {
                oDBHelper = new DBHelper();
                using (IDataReader dr = oDBHelper.ExecuteReader(CommandType.Text, sql))
                {
                    while (dr.Read())
                    {
                        var TT = entity.ZJGCLX.SingleOrDefault(p => p.ZJGCLX_ID == int.Parse(dr["ZJJSBZMX_GCLXID"].ToString()));
                        result += "<td>"+TT.ZJGCLX_MC+"</td>";
                        sID += dr["ZJJSBZMX_GCLXID"].ToString()+',';
                    }
                    result += "</tr>";
                }
                using (IDataReader dr = oDBHelper.ExecuteReader(CommandType.Text, sql1))
                {
                    while (dr.Read())
                    {
                        var TT = entity.ZJGZLX.SingleOrDefault(p => p.ZJGZLX_ID == int.Parse(dr["ZJJSBZMX_GZLXID"].ToString()));
                        string SX = dr["ZJJSBZMX_ZJJESX"].ToString();
                        if (int.Parse(SX) == 0)
                        {
                            SX = "不限";
                        }
                        result += "<tr class=\"wx_table_data_tr\"><td>" + dr["ZJJSBZMX_ZJJEXX"].ToString() + "</td><td>" + dr["ZJJSBZMX_ZJJESX"].ToString() + "</td><td>" + TT.ZJGZLX_MC + "</td>";
                        var TTT = entity.ZJJSBZMX.Where(p => p.ZJJSBZMX_ID == id && p.ZJJSBZMX_GZLXID == int.Parse(dr["ZJJSBZMX_GZLXID"].ToString()) && p.ZJJSBZMX_ZJJEXX == int.Parse(dr["ZJJSBZMX_ZJJEXX"].ToString()) && p.ZJJSBZMX_ZJJESX == int.Parse(dr["ZJJSBZMX_ZJJESX"].ToString()));
                        string[] sids = sID.Split(',');
                        for (int i = 0; i < sids.Length; i++)
                        {
                            if (!string.IsNullOrEmpty(sids[i]))
                            {
                                TTT = TTT.Where(p => p.ZJJSBZMX_GCLXID == int.Parse(sids[i]));
                            if (TTT.ToList().Count > 0 && TTT.ToList()[0].ZJJSBZMX_BL!=0)
                            {
                                result += "<td>" + TTT.ToList()[0].ZJJSBZMX_BL + "</td>";
                            }
                            else
                            {
                                result += "<td></td>";
                            }
                            
                            }
                        }
                        result += "</tr>";
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                result += "</table>";
                oDBHelper = null;
            }
            ViewData["result"] = result;
            return View();
        }

        public ActionResult FZJSBZInfo(int id, string sOperate)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            WoExpress.DataEntity.Models.ZJJSBZ oXMLB = new WoExpress.DataEntity.Models.ZJJSBZ();
            oXMLB = entity.ZJJSBZ.SingleOrDefault(p => p.ZJJSBZ_ID == id);
            return View(oXMLB);
        }



        public ActionResult KSZJJSBZInfo(int id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            ViewData["id"] = id;
            ViewData["GZLXList"] = context.ZJGZLX.Where(p => p.ZJGZLX_ID > 0);
            ViewData["GCLXList"] = context.ZJGCLX.Where(p => p.ZJGCLX_ID > 0);
            return View();
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZJJSBZDel(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZJJSBZ.SingleOrDefault(p => p.ZJJSBZ_ID == id);
            var TT = entity.ZJJSBZMX.Where(p=>p.ZJJSBZMX_ID==id);
            if (entity.ZJXMRW.Where(p => p.ZJXMRW_JSBZ == id).Count() > 0)
                return "该标准已被使用，不允许删除！";

            try
            {
                entity.ZJJSBZMX.DeleteAllOnSubmit(TT);
                entity.SubmitChanges();
                entity.ZJJSBZ.DeleteOnSubmit(T);
                entity.SubmitChanges();
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZJJSBZSave(int id, string sMC, string sBZ, int sStopped, string sOperate)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                WoExpress.DataEntity.Models.ZJJSBZ oXMLB = new WoExpress.DataEntity.Models.ZJJSBZ();
                switch (sOperate)
                {
                    case "N":
                        oXMLB.ZJJSBZ_ID = MisproUtils.GetMaxTblID("ZJJSBZ", "ZJJSBZ_ID");
                        oXMLB.ZJJSBZ_MC = sMC;
                        oXMLB.ZJJSBZ_BZ = sBZ;
                        oXMLB.ZJJSBZ_TY=sStopped;
                        oXMLB.ZJJSBZ_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oXMLB.ZJJSBZ_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oXMLB.ZJJSBZ_WHSJ = DateTime.Now;
                        context.ZJJSBZ.InsertOnSubmit(oXMLB);
                        context.ZJJSBZ.Context.SubmitChanges();
                        break;
                    case "E":
                        oXMLB = context.ZJJSBZ.SingleOrDefault(p => p.ZJJSBZ_ID == id);
                        oXMLB.ZJJSBZ_MC = sMC;
                        oXMLB.ZJJSBZ_TY = sStopped;
                        oXMLB.ZJJSBZ_BZ = sBZ;
                        context.ZJJSBZ.Context.SubmitChanges();
                        break;
                    default:
                        break;
                }
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string FZJSBZSave(int id, string sMC, string sBZ)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                WoExpress.DataEntity.Models.ZJJSBZ oXMLB = new WoExpress.DataEntity.Models.ZJJSBZ();
                oXMLB.ZJJSBZ_ID = MisproUtils.GetMaxTblID("ZJJSBZ", "ZJJSBZ_ID");
                oXMLB.ZJJSBZ_MC = sMC;
                oXMLB.ZJJSBZ_BZ = sBZ;
                oXMLB.ZJJSBZ_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                oXMLB.ZJJSBZ_WHR = CMisproApp.GetCurrentUser().Users_Name;
                oXMLB.ZJJSBZ_WHSJ = DateTime.Now;
                context.ZJJSBZ.InsertOnSubmit(oXMLB);
                context.ZJJSBZ.Context.SubmitChanges();
                var T = context.ZJJSBZMX.Where(p=>p.ZJJSBZMX_ID==id);
                for (int i = 0; i < T.ToList().Count;i++ )
                {
                    WoExpress.DataEntity.Models.ZJJSBZMX oBZMX = new ZJJSBZMX();
                    oBZMX.ZJJSBZMX_ID = oXMLB.ZJJSBZ_ID;
                    oBZMX.ZJJSBZMX_XH = T.ToList()[i].ZJJSBZMX_XH;
                    oBZMX.ZJJSBZMX_GCLXID = T.ToList()[i].ZJJSBZMX_GCLXID;
                    oBZMX.ZJJSBZMX_GZLXID = T.ToList()[i].ZJJSBZMX_GZLXID;
                    oBZMX.ZJJSBZMX_BL = T.ToList()[i].ZJJSBZMX_BL;
                    oBZMX.ZJJSBZMX_ZJJESX = T.ToList()[i].ZJJSBZMX_ZJJESX;
                    oBZMX.ZJJSBZMX_ZJJEXX = T.ToList()[i].ZJJSBZMX_ZJJEXX;
                    oBZMX.ZJJSBZMX_WHR = T.ToList()[i].ZJJSBZMX_WHR;
                    oBZMX.ZJJSBZMX_WHRID = T.ToList()[i].ZJJSBZMX_WHRID;
                    oBZMX.ZJJSBZMX_WHSJ = T.ToList()[i].ZJJSBZMX_WHSJ;
                    context.ZJJSBZMX.InsertOnSubmit(oBZMX);
                    context.ZJJSBZMX.Context.SubmitChanges();

                }
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public string CheckData(int id, int LXID, int GZLX, int ZJXX, int ZJSX)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.ZJJSBZMX.Where(p => p.ZJJSBZMX_ID == id && (p.ZJJSBZMX_GCLXID == LXID || p.ZJJSBZMX_GZLXID == GZLX) && p.ZJJSBZMX_ZJJEXX <= ZJXX && p.ZJJSBZMX_ZJJESX >= ZJXX && p.ZJJSBZMX_ZJJESX == ZJSX);
            if (T.ToList().Count > 0)
            {
                return "Has";
            }
            return "";
        }

        public string KSZJJSBZSave(int id, int ZJXX, int ZJSX, int GCLXID, int GZLXID)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            try
            {
                var TTT = context.ZJJSBZMX.Where(p => p.ZJJSBZMX_ID == id && (p.ZJJSBZMX_GCLXID == GCLXID || p.ZJJSBZMX_GZLXID == GZLXID) && p.ZJJSBZMX_ZJJEXX <= ZJXX && p.ZJJSBZMX_ZJJESX >= ZJXX && p.ZJJSBZMX_ZJJESX == ZJSX);
                context.ZJJSBZMX.DeleteAllOnSubmit(TTT);
                context.SubmitChanges();
                if (GCLXID == 0 && GZLXID == 0)
                {
                    var T = context.ZJGZLX.Where(p => p.ZJGZLX_ID > 0);
                    var TT = context.ZJGCLX.Where(p => p.ZJGCLX_ID > 0);
                    for (int i = 0; i < T.ToList().Count; i++)
                    {
                        for (int j = 0; j < TT.ToList().Count; j++)
                        {
                            WoExpress.DataEntity.Models.ZJJSBZMX oXMLB = new WoExpress.DataEntity.Models.ZJJSBZMX();
                            oXMLB.ZJJSBZMX_ID = id;
                            if (context.ZJJSBZMX.Where(p => p.ZJJSBZMX_ID == id).Count() > 0)
                                oXMLB.ZJJSBZMX_XH = context.ZJJSBZMX.Where(p => p.ZJJSBZMX_ID == id).Max(p => p.ZJJSBZMX_XH) + 1;
                            else
                                oXMLB.ZJJSBZMX_XH = 1;
                            oXMLB.ZJJSBZMX_ZJJEXX = ZJXX;
                            oXMLB.ZJJSBZMX_ZJJESX = ZJSX;
                            oXMLB.ZJJSBZMX_GCLXID = TT.ToList()[j].ZJGCLX_ID;
                            oXMLB.ZJJSBZMX_GZLXID = T.ToList()[i].ZJGZLX_ID;
                            oXMLB.ZJJSBZMX_BZ = "";
                            oXMLB.ZJJSBZMX_BL = 0;
                            oXMLB.ZJJSBZMX_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                            oXMLB.ZJJSBZMX_WHR = CMisproApp.GetCurrentUser().Users_Name;
                            oXMLB.ZJJSBZMX_WHSJ = DateTime.Now;
                            context.ZJJSBZMX.InsertOnSubmit(oXMLB);
                            context.ZJJSBZMX.Context.SubmitChanges();
                        }

                    }
                }
                else if (GCLXID != 0 && GZLXID != 0)
                {
                    WoExpress.DataEntity.Models.ZJJSBZMX oXMLB = new WoExpress.DataEntity.Models.ZJJSBZMX();
                    oXMLB.ZJJSBZMX_ID = id;
                    if (context.ZJJSBZMX.Where(p => p.ZJJSBZMX_ID == id).Count() > 0)
                        oXMLB.ZJJSBZMX_XH = context.ZJJSBZMX.Where(p => p.ZJJSBZMX_ID == id).Max(p => p.ZJJSBZMX_XH) + 1;
                    else
                        oXMLB.ZJJSBZMX_XH = 1;
                    oXMLB.ZJJSBZMX_ZJJEXX = ZJXX;
                    oXMLB.ZJJSBZMX_ZJJESX = ZJSX;
                    oXMLB.ZJJSBZMX_GCLXID = GCLXID;
                    oXMLB.ZJJSBZMX_GZLXID = GZLXID;
                    oXMLB.ZJJSBZMX_BZ = "";
                    oXMLB.ZJJSBZMX_BL = 0;
                    oXMLB.ZJJSBZMX_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                    oXMLB.ZJJSBZMX_WHR = CMisproApp.GetCurrentUser().Users_Name;
                    oXMLB.ZJJSBZMX_WHSJ = DateTime.Now;
                    context.ZJJSBZMX.InsertOnSubmit(oXMLB);
                    context.ZJJSBZMX.Context.SubmitChanges();
                }
                else if (GCLXID == 0 && GZLXID != 0)
                {
                    var TT = context.ZJGCLX.Where(p => p.ZJGCLX_ID > 0);
                    for (int j = 0; j < TT.ToList().Count; j++)
                    {
                        WoExpress.DataEntity.Models.ZJJSBZMX oXMLB = new WoExpress.DataEntity.Models.ZJJSBZMX();
                        oXMLB.ZJJSBZMX_ID = id;
                        if (context.ZJJSBZMX.Where(p => p.ZJJSBZMX_ID == id).Count() > 0)
                            oXMLB.ZJJSBZMX_XH = context.ZJJSBZMX.Where(p => p.ZJJSBZMX_ID == id).Max(p => p.ZJJSBZMX_XH) + 1;
                        else
                            oXMLB.ZJJSBZMX_XH = 1;
                        oXMLB.ZJJSBZMX_ZJJEXX = ZJXX;
                        oXMLB.ZJJSBZMX_ZJJESX = ZJSX;
                        oXMLB.ZJJSBZMX_GCLXID = TT.ToList()[j].ZJGCLX_ID;
                        oXMLB.ZJJSBZMX_GZLXID = GZLXID;
                        oXMLB.ZJJSBZMX_BZ = "";
                        oXMLB.ZJJSBZMX_BL = 0;
                        oXMLB.ZJJSBZMX_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oXMLB.ZJJSBZMX_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oXMLB.ZJJSBZMX_WHSJ = DateTime.Now;
                        context.ZJJSBZMX.InsertOnSubmit(oXMLB);
                        context.ZJJSBZMX.Context.SubmitChanges();
                    }
                }
                else if (GCLXID != 0 && GZLXID == 0)
                {
                    var T = context.ZJGZLX.Where(p => p.ZJGZLX_ID > 0);
                    for (int i = 0; i < T.ToList().Count; i++)
                    {
                        WoExpress.DataEntity.Models.ZJJSBZMX oXMLB = new WoExpress.DataEntity.Models.ZJJSBZMX();
                        oXMLB.ZJJSBZMX_ID = id;
                        if (context.ZJJSBZMX.Where(p => p.ZJJSBZMX_ID == id).Count() > 0)
                            oXMLB.ZJJSBZMX_XH = context.ZJJSBZMX.Where(p => p.ZJJSBZMX_ID == id).Max(p => p.ZJJSBZMX_XH) + 1;
                        else
                            oXMLB.ZJJSBZMX_XH = 1;
                        oXMLB.ZJJSBZMX_ZJJEXX = ZJXX;
                        oXMLB.ZJJSBZMX_ZJJESX = ZJSX;
                        oXMLB.ZJJSBZMX_GCLXID = GCLXID;
                        oXMLB.ZJJSBZMX_GZLXID = T.ToList()[i].ZJGZLX_ID;
                        oXMLB.ZJJSBZMX_BZ = "";
                        oXMLB.ZJJSBZMX_BL = 0;
                        oXMLB.ZJJSBZMX_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oXMLB.ZJJSBZMX_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oXMLB.ZJJSBZMX_WHSJ = DateTime.Now;
                        context.ZJJSBZMX.InsertOnSubmit(oXMLB);
                        context.ZJJSBZMX.Context.SubmitChanges();

                    }
                }
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }

        #endregion

        #region 结算标准明细

        public ActionResult JSBZMX(int id)
        {
            ViewData["id"] = id;
            return View();
        }

        public ActionResult JSBZMXList(int iPageNo, int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZJJSBZMX.Where(p => p.ZJJSBZMX_ID == id);
            return View(TPageWizard.GetData<ZJJSBZMX>(iPageSize, iPageNo, T.ToList()));
        }

        public ActionResult JSBZMXInfo(int id, int iXH, string sOperate)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            WoExpress.DataEntity.Models.ZJJSBZMX oXMLB = new WoExpress.DataEntity.Models.ZJJSBZMX();
            switch (sOperate)
            {
                case "N":
                    oXMLB.ZJJSBZMX_ID = id;
                    break;
                case "E":
                    oXMLB = entity.ZJJSBZMX.SingleOrDefault(p => p.ZJJSBZMX_ID == id && p.ZJJSBZMX_XH == iXH);
                    break;
                case "V":
                    oXMLB = entity.ZJJSBZMX.SingleOrDefault(p => p.ZJJSBZMX_ID == id && p.ZJJSBZMX_XH == iXH);
                    break;
                default:
                    break;
            }
            ViewData["Operate"] = sOperate;
            ViewData["GZLXList"] = entity.ZJGZLX.Where(p => p.ZJGZLX_ID > 0);
            ViewData["GCLXList"] = entity.ZJGCLX.Where(p => p.ZJGCLX_ID > 0);
            return View(oXMLB);
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string JSBZMXDel(int id, int iXH)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZJJSBZMX.SingleOrDefault(p => p.ZJJSBZMX_ID == id && p.ZJJSBZMX_XH == iXH);
            try
            {
                entity.ZJJSBZMX.DeleteOnSubmit(T);
                entity.SubmitChanges();
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string JSBZMXSave(int id, int iXH, int ZJXX, int ZJSX, int GZLXID, int GCLXID, decimal BL, string sBZ, string sOperate)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                WoExpress.DataEntity.Models.ZJJSBZMX oXMLB = new WoExpress.DataEntity.Models.ZJJSBZMX();
                switch (sOperate)
                {
                    case "N":
                        oXMLB.ZJJSBZMX_ID = id;
                        if (context.ZJJSBZMX.Where(p => p.ZJJSBZMX_ID == id).Count() > 0)
                            oXMLB.ZJJSBZMX_XH = context.ZJJSBZMX.Where(p => p.ZJJSBZMX_ID == id).Max(p => p.ZJJSBZMX_XH) + 1;
                        else
                            oXMLB.ZJJSBZMX_XH = 1;
                        oXMLB.ZJJSBZMX_ZJJEXX = ZJXX;
                        oXMLB.ZJJSBZMX_ZJJESX = ZJSX;
                        oXMLB.ZJJSBZMX_GCLXID = GCLXID;
                        oXMLB.ZJJSBZMX_GZLXID = GZLXID;
                        oXMLB.ZJJSBZMX_BZ = sBZ;
                        oXMLB.ZJJSBZMX_BL = BL;
                        oXMLB.ZJJSBZMX_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oXMLB.ZJJSBZMX_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oXMLB.ZJJSBZMX_WHSJ = DateTime.Now;
                        context.ZJJSBZMX.InsertOnSubmit(oXMLB);
                        context.ZJJSBZMX.Context.SubmitChanges();
                        break;
                    case "E":
                        oXMLB = context.ZJJSBZMX.SingleOrDefault(p => p.ZJJSBZMX_ID == id && p.ZJJSBZMX_XH == iXH);
                        oXMLB.ZJJSBZMX_ZJJEXX = ZJXX;
                        oXMLB.ZJJSBZMX_ZJJESX = ZJSX;
                        oXMLB.ZJJSBZMX_GCLXID = GCLXID;
                        oXMLB.ZJJSBZMX_GZLXID = GZLXID;
                        oXMLB.ZJJSBZMX_BZ = sBZ;
                        oXMLB.ZJJSBZMX_BL = BL;
                        context.ZJJSBZ.Context.SubmitChanges();
                        break;
                    default:
                        break;
                }
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        #endregion

    }

    public class TZJJSBZMX
    {
        public int ZJSX;
        public int ZJXX;
        public string GCLX;
        public string GZLX;
    }
}
