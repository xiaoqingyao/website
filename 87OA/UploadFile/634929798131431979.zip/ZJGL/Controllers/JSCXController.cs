﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WoExpress.DataEntity.Models;
using WoExpress.Core.Utility;
using WoExpress.Core.Page;
using WoExpress.Core.Data;
using System.Data;

namespace WoExpress.ZJGL.Controllers
{
    public class JSCXController : Controller
    {
        const int iPageSize = 15;

        #region 结算查询
        public static List<TComputeResult> listJSCX = new List<TComputeResult>();

        public ActionResult ZJJSCX()
        {
            var TUser = CMisproApp.GetCurrentUser();
            if (TUser.Person == null)
            {
                ViewData["BMOption"] = "";
                return View();
            }
            int iUnitID = TUser.Person.Person_UnitID.Value;
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.Department.Where(p => p.Department_UnitID == iUnitID).OrderBy(p => p.Department_Name);
            string sBMOption = "";
            foreach (var t in T)
                sBMOption += "<option value='" + t.Department_ID.ToString() + "'>" + t.Department_Name + "</option>";
            ViewData["BMOption"] = sBMOption;
            return View();
        }

        public ActionResult ZJJSCXList(int iPageNo, string sGZLX, int iBMID, string sRYMC, string sXMMC, string sHZFS, string sHJ, string JSDW, string SJ)
        {
            listJSCX = GetDataList(sGZLX, iBMID, sRYMC, sXMMC, sHZFS, sHJ, JSDW, SJ);
            return View(TPageWizard.GetData<TComputeResult>(iPageSize, iPageNo, listJSCX));
        }

        public ActionResult JSCXCreateTable(string id)
        {
            ViewData["HZFS"] = id;
            return View(listJSCX);
        }

        public List<TComputeResult> GetDataList(string sGZLX, int iBMID, string sRYMC, string sXMMC, string sHZFS, string sHJ, string JSDW, string SJ)
        {
            string sZJGLU001 = MisproUtils.GetUserOption("ZJGLU001");
            int iCurrPersonID = CMisproApp.GetCurrentUser().Users_PersonID.Value;

            List<TComputeResult> lstResult = new List<TComputeResult>();
            DBHelper oDBHelper = null;
            try
            {
                oDBHelper = new DBHelper();
                string sCondition = "";
                if (!String.IsNullOrEmpty(sGZLX))
                    sCondition += " and ZJGZLX_GZXZ='" + sGZLX + "' ";
                if (iBMID > 0)
                    sCondition += " and Person_DepartmentID=" + iBMID.ToString() + " ";
                if (!String.IsNullOrEmpty(sRYMC))
                    sCondition += " and Person_Name like '%" + sRYMC + "%' ";
                if (!String.IsNullOrEmpty(SJ))
                    sCondition += " and year(ZJXMRW_SJ) = '" + SJ + "' ";
                if (!String.IsNullOrEmpty(sXMMC))
                    sCondition += " and ZJXMXX_MC like '%" + sXMMC + "%' ";
                if (!string.IsNullOrEmpty(JSDW))
                    sCondition += " and Unit_Name like '%" + JSDW + "%' ";
                if (sZJGLU001 != "Y")
                    sCondition += " and ZJXMRWCY_ZXR=" + iCurrPersonID.ToString() + " ";

                string sql = "";
                //如果显示非汇总结果，则查询出明细和汇总记录
                if (sHJ != "Y")
                {
                    sql = "select convert(float, 0) as PX1, convert(float, 0) as PX2, ZJXMRW_ID, ZJXMRWCY_XH, ZJXMRW_SJ ,"
                        + "  Unit_Name, Department_Name, ZJXMRWCY_ZXR,ZJXMRWCY_BL, Person_Name,ZJXMDWGC_MC, ZJXMXX_MC, ZJGCLX_MC, ZJGZLX_MC, ZJXMRW_YSJ, ZJXMRW_SDJ, ZJXMRWCY_BGJE, "
                        + "  case when ZJXMRWCY_BGJE=ZJXMRWCY_YSJE then 'N' else 'Y' end as BGBZ "
                        + "from ZJXMRW left join ZJXMDWGC on ZJXMRW_DWGCID=ZJXMDWGC_ID, ZJXMXX left join Unit on Unit_ID=ZJXMXX_JSDW "
                        + "  , ZJGCLX, ZJGZLX, ZJXMRWCY, Person, Department "
                        + "where ZJXMRW_ID=ZJXMRWCY_ID and ZJXMRW_XMID=ZJXMXX_ID and ZJXMRW_GCLX=ZJGCLX_ID "
                        + "  and ZJXMRW_GZLX=ZJGZLX_ID and ZJXMRWCY_ZXR=Person_ID and Person_DepartmentID=Department_ID ";
                    sql += sCondition;

                    sql += "union all ";

                    if (sHZFS == "JS")
                    {
                        sql += "select convert(float, 1) as PX1, convert(float, 0) as PX2, convert(float, 0) as ZJXMRW_ID, null,convert(float, 0) as ZJXMRWCY_XH, "
                            + "  Unit_Name, '' as Department_Name, 0 as ZJXMRWCY_ZXR,0 as ZJXMRWCY_BL,'' as ZJXMDWGC_MC, '' as Person_Name, '' as ZJXMXX_MC, '' as ZJGCLX_MC, '' as ZJGZLX_MC, "
                            + "  sum(isnull(ZJXMRW_YSJ, 0)) as ZJXMRW_YSJ, sum(isnull(ZJXMRW_SDJ, 0)) as ZJXMRW_SDJ, "
                            + "  sum(isnull(ZJXMRWCY_BGJE, 0)) as ZJXMRWCY_BGJE, '' as BGBZ "
                            + "from ZJXMRW left join ZJXMDWGC on ZJXMRW_DWGCID=ZJXMDWGC_ID, ZJXMXX left join Unit on Unit_ID=ZJXMXX_JSDW "
                        + "  , ZJGCLX, ZJGZLX, ZJXMRWCY, Person, Department "
                            + "where ZJXMRW_ID=ZJXMRWCY_ID and ZJXMRW_XMID=ZJXMXX_ID and ZJXMRW_GCLX=ZJGCLX_ID "
                            + "  and ZJXMRW_GZLX=ZJGZLX_ID and ZJXMRWCY_ZXR=Person_ID and Person_DepartmentID=Department_ID ";
                        sql += sCondition;
                        sql += "group by Unit_Name ";
                        sql += "union all ";
                    }
                    else if (sHZFS == "RY")
                    {
                        sql += "select convert(float, 1) as PX1, convert(float, 0) as PX2, convert(float, 0) as ZJXMRW_ID, null, convert(float, 0) as ZJXMRWCY_XH, "
                            + "  '' as Unit_Name, Department_Name, ZJXMRWCY_ZXR,0 as ZJXMRWCY_BL,'' as ZJXMDWGC_MC, Person_Name, '' as ZJXMXX_MC, '' as ZJGCLX_MC, '' as ZJGZLX_MC, "
                            + "  sum(isnull(ZJXMRW_YSJ, 0)) as ZJXMRW_YSJ, sum(isnull(ZJXMRW_SDJ, 0)) as ZJXMRW_SDJ, "
                            + "  sum(isnull(ZJXMRWCY_BGJE, 0)) as ZJXMRWCY_BGJE, '' as BGBZ "
                            + "from ZJXMRW left join ZJXMDWGC on ZJXMRW_DWGCID=ZJXMDWGC_ID, ZJXMXX left join Unit on Unit_ID=ZJXMXX_JSDW "
                        + "  , ZJGCLX, ZJGZLX, ZJXMRWCY, Person, Department "
                            + "where ZJXMRW_ID=ZJXMRWCY_ID and ZJXMRW_XMID=ZJXMXX_ID and ZJXMRW_GCLX=ZJGCLX_ID "
                            + "  and ZJXMRW_GZLX=ZJGZLX_ID and ZJXMRWCY_ZXR=Person_ID and Person_DepartmentID=Department_ID ";
                        sql += sCondition;
                        sql += "group by Department_Name, ZJXMRWCY_ZXR, Person_Name ";
                        sql += "union all ";
                    }
                    else if (sHZFS == "XM")
                    {
                        sql += "select convert(float, 1) as PX1, convert(float, 0) as PX2, convert(float, 0) as ZJXMRW_ID,null, convert(float, 0) as ZJXMRWCY_XH, "
                            + "  '' as Unit_Name, '' as Department_Name, 0 as ZJXMRWCY_ZXR,0 as ZJXMRWCY_BL,'' as ZJXMDWGC_MC, '' as Person_Name, ZJXMXX_MC, '' as ZJGCLX_MC, '' as ZJGZLX_MC, "
                            + "  sum(isnull(ZJXMRW_YSJ, 0)) as ZJXMRW_YSJ, sum(isnull(ZJXMRW_SDJ, 0)) as ZJXMRW_SDJ, "
                            + "  sum(isnull(ZJXMRWCY_BGJE, 0)) as ZJXMRWCY_BGJE, '' as BGBZ "
                            + "from ZJXMRW left join ZJXMDWGC on ZJXMRW_DWGCID=ZJXMDWGC_ID, ZJXMXX left join Unit on Unit_ID=ZJXMXX_JSDW "
                        + "  , ZJGCLX, ZJGZLX, ZJXMRWCY, Person, Department "
                            + "where ZJXMRW_ID=ZJXMRWCY_ID and ZJXMRW_XMID=ZJXMXX_ID and ZJXMRW_GCLX=ZJGCLX_ID "
                            + "  and ZJXMRW_GZLX=ZJGZLX_ID and ZJXMRWCY_ZXR=Person_ID and Person_DepartmentID=Department_ID ";
                        sql += sCondition;
                        sql += "group by ZJXMXX_MC ";
                        sql += "union all ";
                    }
                }
                sql += "select convert(float, 1) as PX1, convert(float, 1) as PX2, convert(float, 0) as ZJXMRW_ID, null, convert(float, 0) as ZJXMRWCY_XH, "
                    + "  '' as Unit_Name, '' as Department_Name, 0 as ZJXMRWCY_ZXR,0 as ZJXMRWCY_BL,'' as ZJXMDWGC_MC, '合计' as Person_Name, '' as ZJXMXX_MC, '' as ZJGCLX_MC, '' as ZJGZLX_MC, "
                    + "  sum(isnull(ZJXMRW_YSJ, 0)) as ZJXMRW_YSJ, sum(isnull(ZJXMRW_SDJ, 0)) as ZJXMRW_SDJ, "
                    + "  isnull(sum(isnull(ZJXMRWCY_BGJE, 0)), 0) as ZJXMRWCY_BGJE, '' as BGBZ "
                    + "from ZJXMRW left join ZJXMDWGC on ZJXMRW_DWGCID=ZJXMDWGC_ID, ZJXMXX left join Unit on Unit_ID=ZJXMXX_JSDW "
                        + "  , ZJGCLX, ZJGZLX, ZJXMRWCY, Person, Department "
                    + "where ZJXMRW_ID=ZJXMRWCY_ID and ZJXMRW_XMID=ZJXMXX_ID and ZJXMRW_GCLX=ZJGCLX_ID "
                    + "  and ZJXMRW_GZLX=ZJGZLX_ID and ZJXMRWCY_ZXR=Person_ID and Person_DepartmentID=Department_ID ";
                sql += sCondition;
                if (sHZFS == "JS")
                    sql += "order by PX2, Unit_Name, PX1, ZJXMXX_MC, Person_Name ";
                else if (sHZFS == "RY")
                    sql += "order by PX2, Person_Name, PX1, ZJXMXX_MC ";
                else if (sHZFS == "XM")
                    sql += "order by PX2, ZJXMXX_MC, PX1, Person_Name ";

                using (IDataReader dr = oDBHelper.ExecuteReader(CommandType.Text, sql))
                {
                    while (dr.Read())
                    {
                        TComputeResult oResult = new TComputeResult();
                        oResult.RWID = int.Parse(dr["ZJXMRW_ID"].ToString());
                        if (!string.IsNullOrEmpty(dr["ZJXMRWCY_XH"].ToString()))
                        {
                            oResult.CYXH = int.Parse(dr["ZJXMRWCY_XH"].ToString());
                        }
                        oResult.PX1 = float.Parse(dr["PX1"].ToString());
                        oResult.PX2 = float.Parse(dr["PX2"].ToString());
                        oResult.BMMC = dr["Department_Name"].ToString();
                        oResult.RYID = int.Parse(dr["ZJXMRWCY_ZXR"].ToString());
                        if (null != dr["ZJXMDWGC_MC"])
                        {
                            oResult.DWGC = dr["ZJXMDWGC_MC"].ToString() ;
                        }
                        
                        oResult.BL = decimal.Parse(dr["ZJXMRWCY_BL"].ToString());
                        oResult.RYMC = dr["Person_Name"].ToString();
                        if (null != dr["Unit_Name"])
                        {
                            oResult.JSDW = dr["Unit_Name"].ToString();
                        }
                        oResult.GCMC = dr["ZJXMXX_MC"].ToString();
                        oResult.GCLX = dr["ZJGCLX_MC"].ToString();
                        oResult.GZLX = dr["ZJGZLX_MC"].ToString();
                        if (dr["ZJXMRW_YSJ"].ToString() != "")
                            oResult.YSJ = decimal.Parse(dr["ZJXMRW_YSJ"].ToString());
                        else
                            oResult.YSJ = 0;
                        if (dr["ZJXMRW_SDJ"].ToString() != "")
                            oResult.SDJ = decimal.Parse(dr["ZJXMRW_SDJ"].ToString());
                        else oResult.SDJ = 0;
                        if (dr["ZJXMRWCY_BGJE"].ToString() != "")
                            oResult.SR = decimal.Parse(dr["ZJXMRWCY_BGJE"].ToString());
                        else oResult.SR = 0;
                        oResult.BGBZ = dr["BGBZ"].ToString();
                        lstResult.Add(oResult);
                    }
                }
            }
            catch (Exception ex)
            {
                //throw ex;
                return null;
            }
            finally
            {
                oDBHelper = null;
            }
            return lstResult;
        }
        #endregion

    }
}
