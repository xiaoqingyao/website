﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WoExpress.DataEntity.Models;
using WoExpress.Core.Utility;
using WoExpress.Core.Page;
using WoExpress.Core.Data;
using System.Data;

namespace WoExpress.ZJGL.Controllers
{
    /// <summary>
    /// 内部结算控制器
    /// </summary>
    public class NBJSController : Controller
    {
        const int iPageSize = 15;

        #region 内部结算
        public ActionResult ZJNBJS()
        {
            var TUser = CMisproApp.GetCurrentUser();
            if (TUser.Person == null)
            {
                ViewData["BMOption"] = "";
                return View();
            }
            int iUnitID = TUser.Person.Person_UnitID.Value;
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.Department.Where(p => p.Department_UnitID == iUnitID).OrderBy(p => p.Department_Name);
            string sBMOption = "";
            foreach (var t in T)
                sBMOption += "<option value='" + t.Department_ID.ToString() + "'>" + t.Department_Name + "</option>";
            ViewData["BMOption"] = sBMOption;
            return View();
        }

        public ActionResult ZJNBJSList(int iPageNo, string sGZLX, int iBMID, string sRYMC, string sXMMC, string sHZFS, string sBHBG)
        {
            List<TComputeResult> lstResult = new List<TComputeResult>();
            DBHelper oDBHelper = null;
            try
            {
                oDBHelper = new DBHelper();
                string sCondition = "";
                if (!String.IsNullOrEmpty(sGZLX))
                    sCondition += " and ZJGZLX_GZXZ='" + sGZLX + "' ";
                if (iBMID > 0)
                    sCondition += " and Person_DepartmentID=" + iBMID.ToString() + " ";
                if (!String.IsNullOrEmpty(sRYMC))
                    sCondition += " and Person_Name like '%" + sRYMC + "%' ";
                if (!String.IsNullOrEmpty(sXMMC))
                    sCondition += " and ZJXMXX_MC like '%" + sXMMC + "%' ";
                if (sBHBG.Equals("N"))
                    sCondition += " and ZJXMRWCY_BGJE=ZJXMRWCY_YSJE ";
                  
                string sql = "";

                sql = "select convert(float, 0) as PX1, convert(float, 0) as PX2, ZJXMRW_ID, ZJXMRWCY_XH, "
                    + "  Unit_Name, Department_Name, ZJXMRWCY_ZXR, Person_Name, ZJXMXX_MC, ZJGCLX_MC, ZJGZLX_MC, ZJXMRW_YSJ, ZJXMRW_SDJ, ZJXMRWCY_BGJE, "
                    + "  case when ZJXMRWCY_BGJE=ZJXMRWCY_YSJE then 'N' else 'Y' end as BGBZ "
                    + "from ZJXMRW, ZJXMXX left join Unit on Unit_ID=ZJXMXX_JSDW "
                    + "  , ZJGCLX, ZJGZLX, ZJXMRWCY, Person, Department "
                    + "where ZJXMRW_ID=ZJXMRWCY_ID and ZJXMRW_XMID=ZJXMXX_ID and ZJXMRW_GCLX=ZJGCLX_ID "
                    + "  and ZJXMRW_GZLX=ZJGZLX_ID and ZJXMRWCY_ZXR=Person_ID and Person_DepartmentID=Department_ID ";
                sql += sCondition;

                sql += "union all ";

                if (sHZFS == "JS")
                {
                    sql += "select convert(float, 1) as PX1, convert(float, 0) as PX2, convert(float, 0) as ZJXMRW_ID, convert(float, 0) as ZJXMRWCY_XH, "
                        + "  Unit_Name, '' as Department_Name, 0 as ZJXMRWCY_ZXR, '' as Person_Name, '' as ZJXMXX_MC, '' as ZJGCLX_MC, '' as ZJGZLX_MC, "
                        + "  sum(isnull(ZJXMRW_YSJ, 0)) as ZJXMRW_YSJ, sum(isnull(ZJXMRW_SDJ, 0)) as ZJXMRW_SDJ, "
                        + "  sum(isnull(ZJXMRWCY_BGJE, 0)) as ZJXMRWCY_BGJE, '' as BGBZ "
                        + "from ZJXMRW, ZJXMXX left join Unit on Unit_ID=ZJXMXX_JSDW "
                    + "  , ZJGCLX, ZJGZLX, ZJXMRWCY, Person, Department "
                        + "where ZJXMRW_ID=ZJXMRWCY_ID and ZJXMRW_XMID=ZJXMXX_ID and ZJXMRW_GCLX=ZJGCLX_ID "
                        + "  and ZJXMRW_GZLX=ZJGZLX_ID and ZJXMRWCY_ZXR=Person_ID and Person_DepartmentID=Department_ID ";
                    sql += sCondition;
                    sql += "group by Unit_Name ";
                    sql += "union all ";
                }
                else if (sHZFS == "RY")
                {
                    sql += "select convert(float, 1) as PX1, convert(float, 0) as PX2, convert(float, 0) as ZJXMRW_ID, convert(float, 0) as ZJXMRWCY_XH, "
                        + "  '' as Unit_Name, Department_Name, ZJXMRWCY_ZXR, Person_Name, '' as ZJXMXX_MC, '' as ZJGCLX_MC, '' as ZJGZLX_MC, "
                        + "  sum(isnull(ZJXMRW_YSJ, 0)) as ZJXMRW_YSJ, sum(isnull(ZJXMRW_SDJ, 0)) as ZJXMRW_SDJ, "
                        + "  sum(isnull(ZJXMRWCY_BGJE, 0)) as ZJXMRWCY_BGJE, '' as BGBZ "
                        + "from ZJXMRW, ZJXMXX left join Unit on Unit_ID=ZJXMXX_JSDW "
                    + "  , ZJGCLX, ZJGZLX, ZJXMRWCY, Person, Department "
                        + "where ZJXMRW_ID=ZJXMRWCY_ID and ZJXMRW_XMID=ZJXMXX_ID and ZJXMRW_GCLX=ZJGCLX_ID "
                        + "  and ZJXMRW_GZLX=ZJGZLX_ID and ZJXMRWCY_ZXR=Person_ID and Person_DepartmentID=Department_ID ";
                    sql += sCondition;
                    sql += "group by Department_Name, ZJXMRWCY_ZXR, Person_Name ";
                    sql += "union all ";
                }
                else if (sHZFS == "XM")
                {
                    sql += "select convert(float, 1) as PX1, convert(float, 0) as PX2, convert(float, 0) as ZJXMRW_ID, convert(float, 0) as ZJXMRWCY_XH, "
                        + "  '' as Unit_Name, '' as Department_Name, 0 as ZJXMRWCY_ZXR, '' as Person_Name, ZJXMXX_MC, '' as ZJGCLX_MC, '' as ZJGZLX_MC, "
                        + "  sum(isnull(ZJXMRW_YSJ, 0)) as ZJXMRW_YSJ, sum(isnull(ZJXMRW_SDJ, 0)) as ZJXMRW_SDJ, "
                        + "  sum(isnull(ZJXMRWCY_BGJE, 0)) as ZJXMRWCY_BGJE, '' as BGBZ "
                        + "from ZJXMRW, ZJXMXX left join Unit on Unit_ID=ZJXMXX_JSDW "
                    + "  , ZJGCLX, ZJGZLX, ZJXMRWCY, Person, Department "
                        + "where ZJXMRW_ID=ZJXMRWCY_ID and ZJXMRW_XMID=ZJXMXX_ID and ZJXMRW_GCLX=ZJGCLX_ID "
                        + "  and ZJXMRW_GZLX=ZJGZLX_ID and ZJXMRWCY_ZXR=Person_ID and Person_DepartmentID=Department_ID ";
                    sql += sCondition;
                    sql += "group by ZJXMXX_MC ";
                    sql += "union all ";
                }

                sql += "select convert(float, 1) as PX1, convert(float, 1) as PX2, convert(float, 0) as ZJXMRW_ID, convert(float, 0) as ZJXMRWCY_XH, "
                    + "  '' as Unit_Name, '' as Department_Name, 0 as ZJXMRWCY_ZXR, '合计' as Person_Name, '' as ZJXMXX_MC, '' as ZJGCLX_MC, '' as ZJGZLX_MC, "
                    + "  sum(isnull(ZJXMRW_YSJ, 0)) as ZJXMRW_YSJ, sum(isnull(ZJXMRW_SDJ, 0)) as ZJXMRW_SDJ, "
                    + "  isnull(sum(isnull(ZJXMRWCY_BGJE, 0)), 0) as ZJXMRWCY_BGJE, '' as BGBZ "
                    + "from ZJXMRW, ZJXMXX left join Unit on Unit_ID=ZJXMXX_JSDW "
                        + "  , ZJGCLX, ZJGZLX, ZJXMRWCY, Person, Department "
                    + "where ZJXMRW_ID=ZJXMRWCY_ID and ZJXMRW_XMID=ZJXMXX_ID and ZJXMRW_GCLX=ZJGCLX_ID "
                    + "  and ZJXMRW_GZLX=ZJGZLX_ID and ZJXMRWCY_ZXR=Person_ID and Person_DepartmentID=Department_ID ";
                sql += sCondition;
                if (sHZFS == "JS")
                    sql += "order by PX2, Unit_Name, PX1, ZJXMXX_MC, Person_Name ";
                else if (sHZFS == "RY")
                    sql += "order by PX2, Person_Name, PX1, ZJXMXX_MC ";
                else if (sHZFS == "XM")
                    sql += "order by PX2, ZJXMXX_MC, PX1, Person_Name ";

                using (IDataReader dr = oDBHelper.ExecuteReader(CommandType.Text, sql))
                {
                    while (dr.Read())
                    {
                        TComputeResult oResult = new TComputeResult();
                        oResult.RWID = int.Parse(dr["ZJXMRW_ID"].ToString());
                        oResult.CYXH = int.Parse(dr["ZJXMRWCY_XH"].ToString());
                        oResult.PX1 = float.Parse(dr["PX1"].ToString());
                        oResult.PX2 = float.Parse(dr["PX2"].ToString());
                        oResult.BMMC = dr["Department_Name"].ToString();
                        oResult.RYID = int.Parse(dr["ZJXMRWCY_ZXR"].ToString());
                        oResult.RYMC = dr["Person_Name"].ToString();
                        oResult.JSDW = dr["Unit_Name"].ToString();
                        oResult.GCMC = dr["ZJXMXX_MC"].ToString();
                        oResult.GCLX = dr["ZJGCLX_MC"].ToString();
                        oResult.GZLX = dr["ZJGZLX_MC"].ToString();
                        oResult.YSJ = decimal.Parse(dr["ZJXMRW_YSJ"].ToString());
                        oResult.SDJ = decimal.Parse(dr["ZJXMRW_SDJ"].ToString());
                        oResult.SR = decimal.Parse(dr["ZJXMRWCY_BGJE"].ToString());
                        oResult.BGBZ = dr["BGBZ"].ToString();
                        lstResult.Add(oResult);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDBHelper = null;
            }

            return View(TPageWizard.GetData<TComputeResult>(iPageSize, iPageNo, lstResult));
        }

        public string Compute(int iBMID, string sRYMC, string sXMMC, string sBHBG)
        {
            DBHelper oDBHelper = null;
            try
            {
                oDBHelper = new DBHelper();
                string sCondition = "";
                if (iBMID > 0)
                    sCondition += " and Person_DepartmentID=" + iBMID.ToString() + " ";
                if (!String.IsNullOrEmpty(sRYMC))
                    sCondition += " and Person_Name like '%" + sRYMC + "%' ";
                if (!String.IsNullOrEmpty(sXMMC))
                    sCondition += " and ZJXMXX_MC like '%" + sXMMC + "%' ";
                if (sBHBG.Equals("N"))
                    sCondition += " and ZJXMRWCY_BGJE=ZJXMRWCY_YSJE ";

                string sql;
                sql = "select * "
                    + "from ZJXMRW, ZJXMXX, ZJGCLX, ZJGZLX, ZJXMRWCY, Person "
                    + "where ZJXMRW_ID=ZJXMRWCY_ID and ZJXMRW_XMID=ZJXMXX_ID and ZJXMRW_GCLX=ZJGCLX_ID "
                    + "  and ZJXMRW_GZLX=ZJGZLX_ID and ZJXMRWCY_ZXR=Person_ID ";
                sql += sCondition;

                using (IDataReader dr = oDBHelper.ExecuteReader(CommandType.Text, sql))
                {
                    //循环计算查询结果的每一条数据
                    while (dr.Read())
                    {
                        //考虑预留金
                        double dYLJ = 0;
                        if (int.Parse(dr["ZJXMRW_YLJKC"].ToString()) == 1)
                            dYLJ = double.Parse(dr["ZJXMRW_YLJ"].ToString());

                        //获取结算基数的值，单位万元
                        double dJSJS = double.Parse(dr[dr["ZJGZLX_JSJS"].ToString()].ToString());
                        int iGCLX = int.Parse(dr["ZJXMRW_GCLX"].ToString());
                        int iGZLX = int.Parse(dr["ZJXMRW_GZLX"].ToString());
                        int iJSBZ = int.Parse(dr["ZJXMRW_JSBZ"].ToString());
                        double dJSBL = GetRate(iJSBZ, dJSJS, iGZLX, iGCLX);

                        int iiRWID = int.Parse(dr["ZJXMRWCY_ID"].ToString());
                        int iRWXH = int.Parse(dr["ZJXMRWCY_XH"].ToString());
                        double dJSZJE = dJSJS * dJSBL * 0.001 * 10000;//单位换算成元

                        string sSql = "update ZJXMRWCY set "
                            + " ZJXMRWCY_YSJE=(" + dJSZJE.ToString() + ") * ZJXMRWCY_BL * 0.01, "
                            + " ZJXMRWCY_BGJE=(" + dJSZJE.ToString() + ") * ZJXMRWCY_BL * 0.01 "
                            + "where ZJXMRWCY_ID=" + iiRWID.ToString() + " and ZJXMRWCY_XH=" + iRWXH.ToString();
                        oDBHelper.ExecuteNonQuery(CommandType.Text, sSql);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDBHelper = null;
            }
            return "";
        }

        public ActionResult ChangeJE(int iRWID, int iCYXH)
        {
            ViewData["RWID"] = iRWID;
            ViewData["CYXH"] = iCYXH;
            return View();
        }

        public string ChangeJESave(int iRWID, int iCYXH, decimal fBGHJE)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                var T = context.ZJXMRWCY.SingleOrDefault(p => p.ZJXMRWCY_ID == iRWID && p.ZJXMRWCY_XH == iCYXH);
                T.ZJXMRWCY_BGJE = fBGHJE;
                context.SubmitChanges();
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        #endregion

        #region 自定义方法
        /// <summary>
        /// 获取结算比例
        /// </summary>
        /// <param name="p_BZID">结算标准</param>
        /// <param name="p_JSJS">结算基数</param>
        /// <param name="p_GZLX">工作类型</param>
        /// <param name="p_GCLX">工程类型</param>
        /// <returns>结算比例</returns>
        private double GetRate(int p_BZID, double p_JSJS, int p_GZLX, int p_GCLX)
        {
            DBHelper oDBHelper = null;
            try
            {
                oDBHelper = new DBHelper();
                string sql = "select ZJJSBZMX_BL from ZJJSBZMX where ZJJSBZMX_ZJJEXX<=" + p_JSJS.ToString() + " and ZJJSBZMX_ZJJESX>="
                    + p_JSJS.ToString() + " and ZJJSBZMX_GZLXID=" + p_GZLX.ToString() + " and ZJJSBZMX_GCLXID=" + p_GCLX.ToString()
                    + " and ZJJSBZMX_ID=" + p_BZID.ToString();
                using (IDataReader dr = oDBHelper.ExecuteReader(CommandType.Text, sql))
                {
                    while (dr.Read())
                    {
                        return double.Parse(dr["ZJJSBZMX_BL"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDBHelper = null;
            }
            return 0;
        }

        #endregion
    }

    /// <summary>
    /// 内部结算计算结果类
    /// </summary>
    public class TComputeResult
    {
        public int RWID;
        public int CYXH;
        public float PX1;   //排序字段1
        public float PX2;   //排序字段2
        public string BMMC; //部门名称
        public int RYID;    //人员ID
        public string JSDW; //建设单位
        public string RYMC; //人员名称
        public string GCMC; //工程名称
        public string GCLX; //工程类型
        public string GZLX; //工作类型
        public string DWGC;//单位工程
        public decimal YSJ; //预算价
        public decimal SDJ; //审定价
        public decimal SR;  //收入
        public decimal BL;
        public string BGBZ; //变更标志
    }
}
