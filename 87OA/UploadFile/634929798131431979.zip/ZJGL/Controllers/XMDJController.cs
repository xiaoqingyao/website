﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WoExpress.DataEntity.Models;
using WoExpress.Core.Utility;
using WoExpress.Core.Page;
using WoExpress.PUBLIC.Controllers;
using System.Web.Script.Serialization;

namespace WoExpress.ZJGL.Controllers
{
    /// <summary>
    /// 项目登记控制器
    /// </summary>
    public class XMDJController : Controller
    {
        const int iPageSize = 15;

        #region 项目信息

        public ActionResult ZJXMDJ()
        {
            return View();
        }

        public ActionResult ZJXMDJList(int iPageNo, string sLb, string sKSRQS, string sJSRQE, string sXMMC, string SJ)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZJXMXX.Where(p => p.ZJXMXX_ID != 0);
            if (!String.IsNullOrEmpty(sKSRQS))
                T = T.Where(p => p.ZJXMXX_WHSJ >= DateTime.Parse(sKSRQS));
            if (!String.IsNullOrEmpty(sJSRQE))
                T = T.Where(p => p.ZJXMXX_WHSJ < DateTime.Parse(sJSRQE).AddDays(1));
            if (!String.IsNullOrEmpty(sXMMC))
                T = T.Where(p => p.ZJXMXX_MC.IndexOf(sXMMC) >= 0);
            if (!String.IsNullOrEmpty(SJ))
                T = T.Where(p => p.ZJXMXX_WHSJ.Value.Year == int.Parse(SJ));
            T = T.OrderByDescending(p => p.ZJXMXX_WHSJ);
            return View(TPageWizard.GetData<ZJXMXX>(13, iPageNo, T.ToList()));
        }




        public ActionResult ZJXMDJInfo(int id, string sOperate)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            ZJXMXX oZJXMXX = new ZJXMXX();
            switch (sOperate)
            {
                case "N":
                    oZJXMXX.ZJXMXX_ID = 0;
                    oZJXMXX.ZJXMXX_DLXMID = 0;
                    oZJXMXX.ZJXMXX_JSDW = 0;
                    oZJXMXX.ZJXMXX_SGDW = 0;
                    break;
                case "E":
                    oZJXMXX = entity.ZJXMXX.SingleOrDefault(p => p.ZJXMXX_ID == id);
                    break;
                case "V":
                    oZJXMXX = entity.ZJXMXX.SingleOrDefault(p => p.ZJXMXX_ID == id);
                    break;
                default:
                    break;
            }
            ViewData["Operate"] = sOperate;
            ViewData["AutoCompStr"] = PUBLICController.GetAllZBXMHints();
            ViewData["AutoCompStrJSDW"] = PUBLICController.GetAllUnitHints("XT03");
            ViewData["AutoCompStrSGDW"] = PUBLICController.GetAllUnitHints("XT02");
            ViewData["AutoCompStrXMJL"] = PUBLICController.GetAllPersonints();
            return View(oZJXMXX);
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZJXMDJDel(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            try
            {
                var T = entity.ZJXMXX.SingleOrDefault(p => p.ZJXMXX_ID == id);
                var TZJRW = entity.ZJXMRW.Where(p => p.ZJXMRW_XMID == id);
                if (TZJRW.Count() > 0)
                    return "已登记造价任务，不允许删除该项目。";
                entity.ZJXMXX.DeleteOnSubmit(T);
                entity.SubmitChanges();
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZJXMDJSave(int id, int iDLXMID, string sMC, int iJSDWID, int iSGDWID, string sJGXS, string sMJGM, string sJBMS, string sBZ, string XMJL, string XMJLID, string sOperate)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                ZJXMXX oZJXMXX = new ZJXMXX();
                switch (sOperate)
                {
                    case "N":
                        oZJXMXX.ZJXMXX_ID = MisproUtils.GetMaxTblID("ZJXMXX", "ZJXMXX_ID");
                        oZJXMXX.ZJXMXX_DLXMID = iDLXMID;
                        oZJXMXX.ZJXMXX_MC = sMC;
                        oZJXMXX.ZJXMXX_JSDW = iJSDWID;
                        oZJXMXX.ZJXMXX_SGDW = iSGDWID;
                        oZJXMXX.ZJXMXX_JGXS = sJGXS;
                        oZJXMXX.ZJXMXX_MJGM = sMJGM;
                        oZJXMXX.ZJXMXX_JBMS = sJBMS;
                        oZJXMXX.ZJXMXX_BZ = sBZ;
                        oZJXMXX.ZJXMXX_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oZJXMXX.ZJXMXX_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oZJXMXX.ZJXMXX_WHSJ = DateTime.Now;
                        context.ZJXMXX.InsertOnSubmit(oZJXMXX);
                        context.ZJXMXX.Context.SubmitChanges();
                        break;
                    case "E":
                        oZJXMXX = context.ZJXMXX.SingleOrDefault(p => p.ZJXMXX_ID == id);
                        oZJXMXX.ZJXMXX_DLXMID = iDLXMID;
                        oZJXMXX.ZJXMXX_MC = sMC;
                        oZJXMXX.ZJXMXX_JSDW = iJSDWID;
                        oZJXMXX.ZJXMXX_SGDW = iSGDWID;
                        oZJXMXX.ZJXMXX_JGXS = sJGXS;
                        oZJXMXX.ZJXMXX_MJGM = sMJGM;
                        oZJXMXX.ZJXMXX_JBMS = sJBMS;
                        oZJXMXX.ZJXMXX_BZ = sBZ;
                        oZJXMXX.ZJXMXX_WHRID = XMJLID;
                        oZJXMXX.ZJXMXX_WHR = XMJL;
                        oZJXMXX.ZJXMXX_WHSJ = DateTime.Now;
                        context.ZJXMXX.Context.SubmitChanges();
                        break;
                    default:
                        break;
                }
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }


        #endregion

        #region 单位工程

        public ActionResult ZJXMDWGC(int id)
        {
            ViewData["id"] = id;
            return View();
        }

        public ActionResult ZJXMDWGCInfo(int id, string sOperate)
        {
            using (DataEntityDataContext context = new DataEntityDataContext())
            {
                ZJXMDWGC oZJGCLX = new ZJXMDWGC();
                switch (sOperate)
                {
                    case "N":
                        break;
                    case "E":
                        oZJGCLX = context.ZJXMDWGC.SingleOrDefault(p => p.ZJXMDWGC_ID == id);
                        break;
                    case "V":
                        oZJGCLX = context.ZJXMDWGC.SingleOrDefault(p => p.ZJXMDWGC_ID == id);
                        break;
                }
                ViewData["sOperate"] = sOperate;
                return View(oZJGCLX);
            }
        }

        public ActionResult ZJXMDWGCList(int iPageNo, int id)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                var T = context.ZJXMDWGC.Where(p => p.ZJXMDWGC_ID > 0 && p.ZJXMDWGC_XMID == id);
                return View(TPageWizard.GetData<ZJXMDWGC>(iPageSize, iPageNo, T.ToList()));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZJXMDWGCSave(int id, string sMC, string sBZ, int XMID, string sOperate)
        {
            try
            {
                using (DataEntityDataContext context = new DataEntityDataContext())
                {
                    ZJXMDWGC oZJGCLX = new ZJXMDWGC();
                    var np = CMisproApp.GetCurrentUser();
                    switch (sOperate)
                    {
                        case "N":
                            oZJGCLX.ZJXMDWGC_BZ = sBZ;
                            oZJGCLX.ZJXMDWGC_MC = sMC;
                            oZJGCLX.ZJXMDWGC_XMID = XMID;
                            oZJGCLX.ZJXMDWGC_WHR = np.Users_Name;
                            oZJGCLX.ZJXMDWGC_WHRID = np.Users_ID;
                            oZJGCLX.ZJXMDWGC_WHSJ = DateTime.Now;
                            context.ZJXMDWGC.InsertOnSubmit(oZJGCLX);
                            context.ZJXMDWGC.Context.SubmitChanges();
                            break;
                        case "E":
                            oZJGCLX = context.ZJXMDWGC.SingleOrDefault(p => p.ZJXMDWGC_ID == id);
                            oZJGCLX.ZJXMDWGC_BZ = sBZ;
                            oZJGCLX.ZJXMDWGC_MC = sMC;
                            oZJGCLX.ZJXMDWGC_XMID = XMID;
                            oZJGCLX.ZJXMDWGC_WHR = np.Users_Name;
                            oZJGCLX.ZJXMDWGC_WHRID = np.Users_ID;
                            oZJGCLX.ZJXMDWGC_WHSJ = DateTime.Now;
                            context.ZJXMDWGC.Context.SubmitChanges();
                            break;
                    }
                    return "OK";
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZJXMDWGCDel(int id)
        {
            try
            {
                using (DataEntityDataContext context = new DataEntityDataContext())
                {
                    ZJXMDWGC oZJGCLX = context.ZJXMDWGC.SingleOrDefault(p => p.ZJXMDWGC_ID == id);
                    var T = context.ZJXMRW.Where(p => p.ZJXMRW_DWGCID == id);
                    if (T.ToList().Count > 0)
                    {
                        return "该单位列表已在任务表里使用，不能删除！";
                    }
                    context.ZJXMDWGC.DeleteOnSubmit(oZJGCLX);
                    context.ZJXMDWGC.Context.SubmitChanges();
                    return "OK";
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        #endregion
    }

    public class Product
    {



        public int id { get; set; }



        public string name { get; set; }



    }

}
