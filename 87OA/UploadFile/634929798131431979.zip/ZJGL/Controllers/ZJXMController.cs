﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WoExpress.DataEntity.Models;
using WoExpress.Core.Page;
using WoExpress.Core.Utility;
using WoExpress.Core.Data;
using System.Data;
using WoExpress.PUBLIC.Controllers;

namespace WoExpress.ZJGL.Controllers
{
    public class ZJXMController : Controller
    {
        #region 造价任务信息

        public ActionResult ZJXMMX()
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            ViewData["GZLXList"] = entity.ZJGZLX.Where(p => p.ZJGZLX_ID > 0 && p.ZJGZLX_TY == 0);
            ViewData["GCLXList"] = entity.ZJGCLX.Where(p => p.ZJGCLX_ID > 0 && p.ZJGCLX_TY == 0);
            return View();
        }

        public ActionResult ZJXMMXList(int iPageNo, string sLb, int sKSRQS, int sJSRQE, string sXMMC, string SJ, string SelZT)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            int currentid = 0;
            var T = entity.ZJXMRW.Where(p => p.ZJXMRW_ID != 0);
            if (CMisproApp.GetCurrentUser().Person != null)
            {
                currentid = CMisproApp.GetCurrentUser().Person.Person_ID;
            }
            else
            {
                T = T.Where(p => p.ZJXMRW_FZR == currentid);
            }
            if (MisproUtils.GetUserOption("UZJXM") != "Y")
            {
                T = T.Where(p => p.ZJXMRW_FZR == currentid || entity.ZJXMRWCY.Where(c => c.ZJXMRWCY_ID == p.ZJXMRW_ID).Select(c => c.ZJXMRWCY_ZXR).Contains(currentid) || entity.ZJXMXX.SingleOrDefault(d => d.ZJXMXX_ID == p.ZJXMRW_XMID).ZJXMXX_WHRID == CMisproApp.GetCurrentUser().Users_ID);
            }
            if (sKSRQS != 0)
                T = T.Where(p => p.ZJXMRW_GCLX == sKSRQS);
            if (sJSRQE != 0)
                T = T.Where(p => p.ZJXMRW_GZLX == sJSRQE);
            if (!String.IsNullOrEmpty(sXMMC))
                T = T.Where(p => p.ZJXMXX.ZJXMXX_MC.IndexOf(sXMMC) >= 0);
            if (!String.IsNullOrEmpty(SJ))
                T = T.Where(p => p.ZJXMRW_SJ.Value.Year == int.Parse(SJ));
            if (!string.IsNullOrEmpty(SelZT))
                T = T.Where(p => p.ZJXMRW_ZT == int.Parse(SelZT));
            T = T.OrderByDescending(p => p.ZJXMRW_WHSJ);
            return View(TPageWizard.GetData<ZJXMRW>(13, iPageNo, T.ToList()));
        }

        public ActionResult ZJXMMXInfo(int id, string sOperate)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            ZJXMRW oZJXMXX = new ZJXMRW();
            switch (sOperate)
            {
                case "N":
                    oZJXMXX.ZJXMRW_ID = WoExpress.Core.Utility.MisproUtils.GetNewID("ZJXMRW");
                    oZJXMXX.ZJXMRW_XMID = 0;
                    if (CMisproApp.GetCurrentUser().Person != null)
                    {
                        oZJXMXX.ZJXMRW_FZR = CMisproApp.GetCurrentUser().Person.Person_ID;
                    }
                    else
                    {
                        oZJXMXX.ZJXMRW_FZR = 0;
                    }

                    string sql = "delete  from ZJXMRWCY where ZJXMRWCY_ID not in (select ZJXMRW_ID from ZJXMRW ) and ZJXMRWCY_WHRID='" + CMisproApp.GetCurrentUser().Users_ID + "'";
                    ClearData(sql);
                    break;
                case "E":
                    oZJXMXX = entity.ZJXMRW.SingleOrDefault(p => p.ZJXMRW_ID == id);
                    break;
                case "V":
                    oZJXMXX = entity.ZJXMRW.SingleOrDefault(p => p.ZJXMRW_ID == id);
                    break;
                default:
                    break;
            }
            ViewData["Operate"] = sOperate;
            if (CMisproApp.GetCurrentUser().Person != null)
            {
                ViewData["UnitName"] = CMisproApp.GetCurrentUser().Person.Unit.Unit_Name;
            }
            ViewData["AutoCompStr"] = PUBLICController.GetAllPersonints();
            ViewData["ZJXMAutoCompStr"] = PUBLICController.GetAllZJXMHints();
            ViewData["GZLXList"] = entity.ZJGZLX.Where(p => p.ZJGZLX_ID > 0 && p.ZJGZLX_TY == 0);
            ViewData["GCLXList"] = entity.ZJGCLX.Where(p => p.ZJGCLX_ID > 0 && p.ZJGCLX_TY == 0);
            ViewData["JSBZList"] = entity.ZJJSBZ.Where(p => p.ZJJSBZ_ID > 0 && p.ZJJSBZ_TY == 0);
            ViewData["ZJXMDWGCList"] = entity.ZJXMDWGC.Where(p => p.ZJXMDWGC_ID > 0 && p.ZJXMDWGC_XMID == oZJXMXX.ZJXMRW_XMID);
            return View(oZJXMXX);
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZJXMMXDel(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZJXMRW.SingleOrDefault(p => p.ZJXMRW_ID == id);
            try
            {
                entity.ZJXMRW.DeleteOnSubmit(T);
                entity.SubmitChanges();
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public ActionResult ZJXMTH(int id)
        {
            ViewData["ID"] = id;
            return View();
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZJXMMXTJ(int id, int value)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            ZJXMRW oZJXMXX = new ZJXMRW();
            oZJXMXX = entity.ZJXMRW.SingleOrDefault(p => p.ZJXMRW_ID == id);
            try
            {
                oZJXMXX.ZJXMRW_ZT = value;
                entity.ZJXMRW.Context.SubmitChanges();
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZJXMMXTH(int id, int value, string yj)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            ZJXMRW oZJXMXX = new ZJXMRW();
            ZJXMSHRZ oZJXMRZ = new ZJXMSHRZ();
            oZJXMRZ.ZJXMSHRZ_RWID = id;
            oZJXMRZ.ZJXMSHRZ_SHNR = yj;
            oZJXMRZ.ZJXMSHRZ_SHR = CMisproApp.GetCurrentUser().Users_Name;
            oZJXMRZ.ZJXMSHRZ_SHRID = CMisproApp.GetCurrentUser().Users_ID;
            oZJXMRZ.ZJXMSHRZ_SHSH = DateTime.Now;
            entity.ZJXMSHRZ.InsertOnSubmit(oZJXMRZ);
            entity.ZJXMSHRZ.Context.SubmitChanges();
            oZJXMXX = entity.ZJXMRW.SingleOrDefault(p => p.ZJXMRW_ID == id);
            try
            {
                oZJXMXX.ZJXMRW_ZT = value;
                entity.ZJXMRW.Context.SubmitChanges();
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public ActionResult ZJXMSHRZ(int id)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                var T = context.ZJXMSHRZ.Where(p => p.ZJXMSHRZ_RWID == id);
                return View(TPageWizard.GetData<ZJXMSHRZ>(10, 1, T.ToList()));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string DWGCXX(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZJXMDWGC.Where(p => p.ZJXMDWGC_ID > 0 && p.ZJXMDWGC_XMID == id);
            string res = "";
            foreach (var item in T)
            {
                res += "<option value=\"" + item.ZJXMDWGC_ID + "\">" + item.ZJXMDWGC_MC + "</option>";
            }
            return res + "_" + GetXMFZR(id);
        }


        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string ZJXMMXSave(int id, int iDLXMID, int GZLX, int GCLX, int FZR, int JSBZ, decimal YSJ, decimal SSJ, decimal SDJ, decimal HJS, decimal YLJ, int YLJKC, decimal ZGJ, int ZGJKC, string sBZ, string SJ, int SelDWGC, string sOperate)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                ZJXMRW oZJXMXX = new ZJXMRW();
                switch (sOperate)
                {
                    case "N":
                        oZJXMXX.ZJXMRW_ID = id;
                        oZJXMXX.ZJXMRW_XMID = iDLXMID;
                        oZJXMXX.ZJXMRW_GZLX = GZLX;
                        oZJXMXX.ZJXMRW_GCLX = GCLX;
                        oZJXMXX.ZJXMRW_FZR = FZR;
                        oZJXMXX.ZJXMRW_YSJ = YSJ;
                        oZJXMXX.ZJXMRW_SSJ = SSJ;
                        oZJXMXX.ZJXMRW_SDJ = SDJ;
                        oZJXMXX.ZJXMRW_HJS = HJS;
                        oZJXMXX.ZJXMRW_YLJ = YLJ;
                        oZJXMXX.ZJXMRW_YLJKC = YLJKC;
                        oZJXMXX.ZJXMRW_ZGJ = ZGJ;
                        oZJXMXX.ZJXMRW_ZGJKC = ZGJKC;
                        oZJXMXX.ZJXMRW_JSBZ = JSBZ;
                        oZJXMXX.ZJXMRW_BZ = sBZ;
                        oZJXMXX.ZJXMRW_ZT = 0;
                        oZJXMXX.ZJXMRW_DWGCID = SelDWGC;
                        if (!String.IsNullOrEmpty(SJ))
                        {
                            oZJXMXX.ZJXMRW_SJ = DateTime.Parse(SJ);
                        }
                        oZJXMXX.ZJXMRW_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                        oZJXMXX.ZJXMRW_WHR = CMisproApp.GetCurrentUser().Users_Name;
                        oZJXMXX.ZJXMRW_WHSJ = DateTime.Now;
                        oZJXMXX.ZJXMRW_JSZJ = GetJSZJ(SSJ, HJS);
                        context.ZJXMRW.InsertOnSubmit(oZJXMXX);
                        context.ZJXMRW.Context.SubmitChanges();
                        break;
                    case "E":
                        oZJXMXX = context.ZJXMRW.SingleOrDefault(p => p.ZJXMRW_ID == id);
                        oZJXMXX.ZJXMRW_XMID = iDLXMID;
                        oZJXMXX.ZJXMRW_GZLX = GZLX;
                        oZJXMXX.ZJXMRW_GCLX = GCLX;
                        oZJXMXX.ZJXMRW_FZR = FZR;
                        oZJXMXX.ZJXMRW_YSJ = YSJ;
                        oZJXMXX.ZJXMRW_SSJ = SSJ;
                        oZJXMXX.ZJXMRW_SDJ = SDJ;
                        oZJXMXX.ZJXMRW_HJS = HJS;
                        oZJXMXX.ZJXMRW_YLJ = YLJ;
                        oZJXMXX.ZJXMRW_JSBZ = JSBZ;
                        oZJXMXX.ZJXMRW_YLJKC = YLJKC;
                        oZJXMXX.ZJXMRW_ZGJ = ZGJ;
                        oZJXMXX.ZJXMRW_ZGJKC = ZGJKC;
                        oZJXMXX.ZJXMRW_BZ = sBZ;
                        oZJXMXX.ZJXMRW_DWGCID = SelDWGC;
                        if (!String.IsNullOrEmpty(SJ))
                        {
                            oZJXMXX.ZJXMRW_SJ = DateTime.Parse(SJ);
                        }
                        oZJXMXX.ZJXMRW_JSZJ = GetJSZJ(SSJ, HJS);
                        context.ZJXMRW.Context.SubmitChanges();
                        break;
                    default:
                        break;
                }
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public void ClearData(string sql)
        {
            DBHelper db = new DBHelper();
            try
            {
                db.ExecuteNonQuery(CommandType.Text, sql);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                db = null;
            }
        }

        public static string GetGCLX(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZJGCLX.SingleOrDefault(p => p.ZJGCLX_ID == id);
            if (null == T)
            {
                return "";
            }
            return T.ZJGCLX_MC;
        }

        public static string GetDWGC(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZJXMDWGC.SingleOrDefault(p => p.ZJXMDWGC_ID == id);
            if (null == T)
            {
                return "";
            }
            return T.ZJXMDWGC_MC;
        }


        public static string GetFZRID(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZJXMXX.SingleOrDefault(p => p.ZJXMXX_ID == id);
            if (null == T)
            {
                return "";
            }
            return T.ZJXMXX_WHRID;
        }

        public static string GetXMFZR(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZJXMXX.SingleOrDefault(p => p.ZJXMXX_ID == id);
            if (null == T)
            {
                return "";
            }
            return T.ZJXMXX_WHR;
        }


        public static string GetGZLX(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.ZJGZLX.SingleOrDefault(p => p.ZJGZLX_ID == id);
            if (null == T)
            {
                return "";
            }
            return T.ZJGZLX_MC;
        }

        public static string GetFZR(int id)
        {
            DataEntityDataContext entity = new DataEntityDataContext();
            var T = entity.Person.SingleOrDefault(p => p.Person_ID == id);
            if (null == T)
            {
                return "";
            }
            return T.Person_Name;
        }


        public ActionResult GetZJRYList(int id)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.ZJXMRWCY.Where(p => p.ZJXMRWCY_ID == id);
            return View(T);
        }

        public string ExistRY(int id, int uid)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.ZJXMRWCY.Where(p => p.ZJXMRWCY_ID == id && p.ZJXMRWCY_ZXR == uid);
            if (T.ToList().Count > 0)
            {
                return "ok";
            }
            return "";
        }

        public ActionResult ShowRYXX(int id)
        {
            ViewData["id"] = id;
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.Department.Where(p => p.Department_UnitID == id);
            List<SelectListItem> Mylist = new List<SelectListItem>();
            for (int i = 0; i < T.ToList().Count; i++)
            {
                Mylist.Add(new SelectListItem { Text = T.ToList()[i].Department_Name, Value = T.ToList()[i].Department_ID.ToString() });
            }
            ViewData["Departlist"] = Mylist;
            return View();
        }

        public ActionResult ShowRYXXList(int iPageNo, int iUnitID, int iDepart)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.Person.Where(p => p.Person_UnitID == iUnitID);
            if (iDepart != 0)
            {
                T = T.Where(p => p.Person_DepartmentID == iDepart);
            }
            return View(TPageWizard.GetData<Person>(12, iPageNo, T.ToList()));
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string InsertZJRY(int id, string sRYXX)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                string[] arrRY = sRYXX.Split(',');
                foreach (var t in arrRY)
                {
                    if (!String.IsNullOrEmpty(t))
                    {
                        if (context.ZJXMRWCY.Where(p => p.ZJXMRWCY_ID == id && p.ZJXMRWCY_ZXR == int.Parse(t)).Count() == 0)
                        {
                            ZJXMRWCY oZTBDLRYBA = new ZJXMRWCY();
                            oZTBDLRYBA.ZJXMRWCY_ID = id;
                            if (context.ZJXMRWCY.Where(p => p.ZJXMRWCY_ID == id).Count() > 0)
                                oZTBDLRYBA.ZJXMRWCY_XH = context.ZJXMRWCY.Where(p => p.ZJXMRWCY_ID == id).Max(p => p.ZJXMRWCY_XH) + 1;
                            else
                                oZTBDLRYBA.ZJXMRWCY_XH = 1;
                            oZTBDLRYBA.ZJXMRWCY_ZXR = int.Parse(t);
                            oZTBDLRYBA.ZJXMRWCY_BL = 100;
                            oZTBDLRYBA.ZJXMRWCY_YSJE = 0;
                            oZTBDLRYBA.ZJXMRWCY_BGJE = 0;
                            oZTBDLRYBA.ZJXMRWCY_WHR = CMisproApp.GetCurrentUser().Users_Name;
                            oZTBDLRYBA.ZJXMRWCY_WHRID = CMisproApp.GetCurrentUser().Users_ID;
                            oZTBDLRYBA.ZJXMRWCY_WHSJ = DateTime.Now;
                            context.ZJXMRWCY.InsertOnSubmit(oZTBDLRYBA);
                            context.SubmitChanges();
                        }
                    }
                }
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string DeleteZJRY(int iXH, int iJDCJID)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                var T = context.ZJXMRWCY.SingleOrDefault(p => p.ZJXMRWCY_ID == iJDCJID && p.ZJXMRWCY_XH == iXH);
                context.ZJXMRWCY.DeleteOnSubmit(T);
                context.SubmitChanges();
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public string UpdateYSJ(int id, int xh, string ysj)
        {
            try
            {
                DataEntityDataContext context = new DataEntityDataContext();
                ZJXMRWCY oZTBDLRYBA = new ZJXMRWCY();
                oZTBDLRYBA = context.ZJXMRWCY.SingleOrDefault(p => p.ZJXMRWCY_ID == id && p.ZJXMRWCY_XH == xh);
                if (!string.IsNullOrEmpty(ysj))
                {
                    oZTBDLRYBA.ZJXMRWCY_BL = decimal.Parse(ysj);
                }
                context.ZJXMRWCY.Context.SubmitChanges();
                return Compute(id, xh);

            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public string Compute(int id, int xh)
        {
            DBHelper oDBHelper = null;
            DataEntityDataContext context = new DataEntityDataContext();
            try
            {
                oDBHelper = new DBHelper();
                string sCondition = "";
                if (id > 0)
                    sCondition += " and ZJXMRWCY_ID=" + id.ToString() + " ";
                if (xh > 0)
                    sCondition += " and ZJXMRWCY_XH=" + xh.ToString() + " ";

                string sql;
                sql = "select * "
                    + "from ZJXMRW, ZJXMXX, ZJGCLX, ZJGZLX, ZJXMRWCY, Person "
                    + "where ZJXMRW_ID=ZJXMRWCY_ID and ZJXMRW_XMID=ZJXMXX_ID and ZJXMRW_GCLX=ZJGCLX_ID "
                    + "  and ZJXMRW_GZLX=ZJGZLX_ID and ZJXMRWCY_ZXR=Person_ID ";
                sql += sCondition;

                using (IDataReader dr = oDBHelper.ExecuteReader(CommandType.Text, sql))
                {
                    //循环计算查询结果的每一条数据
                    while (dr.Read())
                    {
                        //考虑预留金
                        double dYLJ = 0;
                        if (int.Parse(dr["ZJXMRW_YLJKC"].ToString()) == 1)
                            dYLJ = double.Parse(dr["ZJXMRW_YLJ"].ToString());

                        //获取结算基数的值，单位万元
                        double dJSJS = double.Parse(dr[dr["ZJGZLX_JSJS"].ToString()].ToString());
                        int iGCLX = int.Parse(dr["ZJXMRW_GCLX"].ToString());
                        int iGZLX = int.Parse(dr["ZJXMRW_GZLX"].ToString());
                        int iJSBZ = int.Parse(dr["ZJXMRW_JSBZ"].ToString());
                        double dJSBL = GetRate(iJSBZ, dJSJS, iGZLX, iGCLX);

                        int iiRWID = int.Parse(dr["ZJXMRWCY_ID"].ToString());
                        int iRWXH = int.Parse(dr["ZJXMRWCY_XH"].ToString());
                        double dJSZJE = dJSJS * dJSBL * 0.001 * 10000;//单位换算成元

                        dJSZJE = GetZJYWF(dJSJS, iJSBZ, iGZLX, iGCLX);

                        string sSql = "update ZJXMRWCY set "
                            + " ZJXMRWCY_YSJE=(" + dJSZJE.ToString() + ") * ZJXMRWCY_BL * 0.01, "
                            + " ZJXMRWCY_BGJE=(" + dJSZJE.ToString() + ") * ZJXMRWCY_BL * 0.01 "
                            + "where ZJXMRWCY_ID=" + iiRWID.ToString() + " and ZJXMRWCY_XH=" + iRWXH.ToString();
                        oDBHelper.ExecuteNonQuery(CommandType.Text, sSql);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDBHelper = null;
            }
            return context.ZJXMRWCY.SingleOrDefault(p => p.ZJXMRWCY_ID == id && p.ZJXMRWCY_XH == xh).ZJXMRWCY_YSJE.ToString(); ;
        }

        public double GetZJYWF(double dJSJS, int pBZID, int pGZLX, int pGCLX)
        {
            using (DataEntityDataContext context = new DataEntityDataContext())
            {
                double f = GetZJJEXX(dJSJS, pBZID, pGZLX, pGCLX);
                double r = GetRate(pBZID, dJSJS, pGZLX, pGCLX);
                if (f == 0)
                    return dJSJS * r * 0.001 * 10000;
                else
                {
                    return (dJSJS - f) * r * 0.001 * 10000 + GetZJYWF(f, pBZID, pGZLX, pGCLX);
                }
            }
        }

        public double GetZJJEXX(double dJSJS, int pBZID, int pGZLX, int pGCLX)
        {
            using (DataEntityDataContext context = new DataEntityDataContext())
            {
                var T = context.ZJJSBZMX.Where(p => p.ZJJSBZMX_ID == pBZID && p.ZJJSBZMX_GZLXID == pGZLX && p.ZJJSBZMX_GCLXID == pGCLX);
                T = T.Where(p => p.ZJJSBZMX_ZJJEXX < dJSJS && (p.ZJJSBZMX_ZJJESX >= dJSJS || p.ZJJSBZMX_ZJJESX == 0)).OrderByDescending(p => p.ZJJSBZMX_ZJJEXX);
                if (T.Count() > 0)
                    return T.First().ZJJSBZMX_ZJJEXX.Value;
                else
                    return 0;
            }
        }

        #region 自定义方法
        /// <summary>
        /// 获取结算比例
        /// </summary>
        /// <param name="p_BZID">结算标准</param>
        /// <param name="p_JSJS">结算基数</param>
        /// <param name="p_GZLX">工作类型</param>
        /// <param name="p_GCLX">工程类型</param>
        /// <returns>结算比例</returns>
        private double GetRate(int p_BZID, double p_JSJS, int p_GZLX, int p_GCLX)
        {
            DBHelper oDBHelper = null;
            try
            {
                oDBHelper = new DBHelper();
                string sql = "select ZJJSBZMX_BL from ZJJSBZMX where ZJJSBZMX_ZJJEXX<" + p_JSJS.ToString() + " and ZJJSBZMX_ZJJESX>="
                    + p_JSJS.ToString() + " and ZJJSBZMX_GZLXID=" + p_GZLX.ToString() + " and ZJJSBZMX_GCLXID=" + p_GCLX.ToString()
                    + " and ZJJSBZMX_ID=" + p_BZID.ToString();
                using (IDataReader dr = oDBHelper.ExecuteReader(CommandType.Text, sql))
                {
                    while (dr.Read())
                    {
                        return double.Parse(dr["ZJJSBZMX_BL"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDBHelper = null;
            }
            return 0;
        }

        #endregion

        public ActionResult ShowSingleXM()
        {
            return View();
        }

        public ActionResult ShowSingleXMList(int iPageNo, string sXMMC)
        {
            DataEntityDataContext context = new DataEntityDataContext();
            var T = context.ZJXMXX.Where(p => p.ZJXMXX_ID > 0);
            if (!String.IsNullOrEmpty(sXMMC.Trim()))
                T = T.Where(p => p.ZJXMXX_MC.Contains(sXMMC.Trim()));
            return View(TPageWizard.GetData<ZJXMXX>(10, iPageNo, T.ToList()));
        }

        #endregion

        #region 自定义方法
        /// <summary>
        /// 计算结算总价
        /// </summary>
        /// <param name="p_SSJ"></param>
        /// <param name="p_SJE"></param>
        /// <returns></returns>
        private double GetJSZJ(decimal p_SSJ, decimal p_SJE)
        {
            decimal dMin = p_SSJ * 0.1m;
            decimal dMax = p_SSJ * 0.2m;
            if (p_SJE < dMin)
                return (double)dMin * 0.035;
            else if (p_SJE > dMax)
                return (double)dMax * 0.035;
            else
                return (double)p_SJE * 0.035;
        }
        #endregion
    }
}
