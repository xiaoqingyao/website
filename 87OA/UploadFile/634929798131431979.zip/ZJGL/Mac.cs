﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WoExpress.Core.System;

namespace WoExpress.ZJGL
{
    public class Mac : WoExpress.Core.System.Mac
    {
        public Mac()
        {
            //以下设置部件信息
            ID = "ZJGL";
            Name = "造价管理";
            Supplier = "南京沃叶软件有限公司";
            Version = 2;

            //以下设置各模块的信息（630000-639999）
            AddModuleInfo(630000, 0, "造价管理", "C", "");
            
            AddModuleInfo(631000, 630000, "内部结算", "C", "");
            AddModuleInfo(631010, 631000, "工作类型", "F", "/ZJGL/GZLX/ZJGZLX");
            AddModuleInfo(631020, 631000, "工程类型", "F", "/ZJGL/GCLX/ZJGCLX");
            AddModuleInfo(631030, 631000, "结算标准", "F", "/ZJGL/JSBZ/ZJJSBZ");
            AddModuleInfo(631040, 631000, "造价项目", "F", "/ZJGL/XMDJ/ZJXMDJ");
            AddModuleInfo(631050, 631000, "造价任务", "F", "/ZJGL/ZJXM/ZJXMMX");
            AddModuleInfo(631060, 631000, "内部结算", "F", "/ZJGL/NBJS/ZJNBJS");
            AddModuleInfo(631070, 631000, "结算查询", "F", "/ZJGL/JSCX/ZJJSCX");
            
        }
    }
}
